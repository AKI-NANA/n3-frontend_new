<?php
/**
 * データフロー追跡・価格検証システム
 * スクレイピング→保存→表示の各段階でデータを詳細確認
 */

echo "<h1>🔍 データフロー追跡・価格検証システム</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. データベース内の実際のデータ確認
    echo "<h2>1. データベース内の実際のデータ（最新5件）</h2>";
    $sql = "SELECT id, source_item_id, active_title, price_jpy, active_price_usd, 
                   scraped_yahoo_data, active_image_url, status, created_at, updated_at
            FROM yahoo_scraped_products 
            ORDER BY created_at DESC 
            LIMIT 5";
    
    $stmt = $pdo->query($sql);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($products)) {
        foreach ($products as $index => $product) {
            echo "<div style='border: 1px solid #ddd; margin: 10px 0; padding: 15px; background: #f9f9f9;'>";
            echo "<h3>商品 " . ($index + 1) . "</h3>";
            
            // 基本情報
            echo "<div style='display: grid; grid-template-columns: 1fr 1fr; gap: 20px;'>";
            echo "<div>";
            echo "<p><strong>ID:</strong> {$product['id']}</p>";
            echo "<p><strong>source_item_id:</strong> {$product['source_item_id']}</p>";
            echo "<p><strong>タイトル:</strong> " . htmlspecialchars(substr($product['active_title'], 0, 50)) . "...</p>";
            echo "<p><strong>🔴 価格（円）:</strong> <span style='color: red; font-weight: bold; font-size: 1.2em;'>¥" . number_format($product['price_jpy']) . "</span></p>";
            echo "<p><strong>価格（ドル）:</strong> $" . ($product['active_price_usd'] ?: 'N/A') . "</p>";
            echo "<p><strong>ステータス:</strong> {$product['status']}</p>";
            echo "</div>";
            
            echo "<div>";
            echo "<p><strong>画像URL:</strong> <a href='{$product['active_image_url']}' target='_blank'>確認</a></p>";
            echo "<p><strong>作成日時:</strong> {$product['created_at']}</p>";
            echo "<p><strong>更新日時:</strong> {$product['updated_at']}</p>";
            if ($product['created_at'] !== $product['updated_at']) {
                echo "<p style='color: blue;'><strong>⚠️ データ更新済み</strong></p>";
            } else {
                echo "<p style='color: green;'><strong>✅ 新規データ</strong></p>";
            }
            echo "</div>";
            echo "</div>";
            
            // スクレイピング詳細データの解析
            if ($product['scraped_yahoo_data']) {
                $scraped_data = json_decode($product['scraped_yahoo_data'], true);
                if ($scraped_data) {
                    echo "<h4>📊 スクレイピング詳細データ:</h4>";
                    echo "<div style='background: #f0f8ff; padding: 10px; border-radius: 5px;'>";
                    
                    // 価格関連データの詳細確認
                    echo "<div style='background: #ffe6e6; padding: 10px; margin: 5px 0; border-radius: 3px;'>";
                    echo "<h5 style='color: red;'>🔴 価格関連データ検証:</h5>";
                    echo "<p><strong>スクレイピング元URL:</strong> " . ($scraped_data['url'] ?: 'N/A') . "</p>";
                    echo "<p><strong>カテゴリ:</strong> " . ($scraped_data['category'] ?: 'N/A') . "</p>";
                    echo "<p><strong>状態:</strong> " . ($scraped_data['condition'] ?: 'N/A') . "</p>";
                    echo "<p><strong>出品者:</strong> " . ($scraped_data['seller_name'] ?: 'N/A') . "</p>";
                    echo "<p><strong>入札数:</strong> " . ($scraped_data['bid_count'] ?: '0') . "件</p>";
                    echo "<p><strong>終了時間:</strong> " . ($scraped_data['end_time'] ?: 'N/A') . "</p>";
                    echo "<p><strong>スクレイピング方法:</strong> " . ($scraped_data['scraping_method'] ?: 'N/A') . "</p>";
                    
                    // 価格変換チェック
                    $expected_usd = $product['price_jpy'] > 0 ? round($product['price_jpy'] / 150, 2) : null;
                    $actual_usd = $product['active_price_usd'];
                    
                    echo "<div style='background: #fff3cd; padding: 8px; margin: 5px 0; border-radius: 3px;'>";
                    echo "<h6>💱 価格変換検証:</h6>";
                    echo "<p><strong>円価格:</strong> ¥" . number_format($product['price_jpy']) . "</p>";
                    echo "<p><strong>期待されるドル価格:</strong> $" . $expected_usd . " (¥{$product['price_jpy']} ÷ 150)</p>";
                    echo "<p><strong>実際のドル価格:</strong> $" . $actual_usd . "</p>";
                    
                    if ($expected_usd != $actual_usd) {
                        echo "<p style='color: red; font-weight: bold;'>❌ 価格変換エラー: 期待値と実際値が異なります</p>";
                    } else {
                        echo "<p style='color: green; font-weight: bold;'>✅ 価格変換正常</p>";
                    }
                    echo "</div>";
                    
                    echo "</div>";
                    
                    // その他のメタデータ
                    if (isset($scraped_data['data_quality'])) {
                        echo "<p><strong>データ品質:</strong> {$scraped_data['data_quality']}%</p>";
                    }
                    if (isset($scraped_data['extraction_success'])) {
                        echo "<p><strong>抽出成功率:</strong> {$scraped_data['extraction_success']}</p>";
                    }
                    
                    echo "</div>";
                } else {
                    echo "<div style='color: red; padding: 10px;'>❌ スクレイピングデータのJSON解析に失敗</div>";
                }
            }
            
            echo "</div>";
        }
    } else {
        echo "<div style='color: orange; padding: 10px;'>📊 データが見つかりませんでした</div>";
    }
    
    // 2. 価格異常データの検出
    echo "<h2>2. 価格異常データの検出</h2>";
    
    // 異常に低い価格（100円未満）
    $lowPriceSql = "SELECT COUNT(*) as count FROM yahoo_scraped_products WHERE price_jpy < 100 AND price_jpy > 0";
    $lowPriceStmt = $pdo->query($lowPriceSql);
    $lowPriceCount = $lowPriceStmt->fetch();
    
    // 異常に高い価格（1000万円以上）
    $highPriceSql = "SELECT COUNT(*) as count FROM yahoo_scraped_products WHERE price_jpy > 10000000";
    $highPriceStmt = $pdo->query($highPriceSql);
    $highPriceCount = $highPriceStmt->fetch();
    
    // 価格が0円のデータ
    $zeroPriceSql = "SELECT COUNT(*) as count FROM yahoo_scraped_products WHERE price_jpy = 0";
    $zeroPriceStmt = $pdo->query($zeroPriceSql);
    $zeroPriceCount = $zeroPriceStmt->fetch();
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
    echo "<h3>価格異常統計:</h3>";
    echo "<p><strong>100円未満の商品:</strong> {$lowPriceCount['count']}件 " . ($lowPriceCount['count'] > 0 ? "⚠️" : "✅") . "</p>";
    echo "<p><strong>1000万円以上の商品:</strong> {$highPriceCount['count']}件 " . ($highPriceCount['count'] > 0 ? "⚠️" : "✅") . "</p>";
    echo "<p><strong>0円の商品:</strong> {$zeroPriceCount['count']}件 " . ($zeroPriceCount['count'] > 0 ? "⚠️" : "✅") . "</p>";
    echo "</div>";
    
    // 異常価格の具体例表示
    if ($lowPriceCount['count'] > 0 || $highPriceCount['count'] > 0 || $zeroPriceCount['count'] > 0) {
        echo "<h3>価格異常データの詳細:</h3>";
        
        $anomalySql = "SELECT source_item_id, active_title, price_jpy, scraped_yahoo_data 
                       FROM yahoo_scraped_products 
                       WHERE price_jpy < 100 OR price_jpy > 10000000 OR price_jpy = 0
                       ORDER BY price_jpy ASC 
                       LIMIT 10";
        
        $anomalyStmt = $pdo->query($anomalySql);
        $anomalies = $anomalyStmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($anomalies as $anomaly) {
            echo "<div style='border: 2px solid red; margin: 10px 0; padding: 10px; background: #ffe6e6;'>";
            echo "<h4 style='color: red;'>🚨 価格異常データ</h4>";
            echo "<p><strong>source_item_id:</strong> {$anomaly['source_item_id']}</p>";
            echo "<p><strong>タイトル:</strong> " . htmlspecialchars(substr($anomaly['active_title'], 0, 100)) . "</p>";
            echo "<p><strong>異常価格:</strong> <span style='color: red; font-weight: bold; font-size: 1.2em;'>¥" . number_format($anomaly['price_jpy']) . "</span></p>";
            
            // スクレイピング元データ確認
            if ($anomaly['scraped_yahoo_data']) {
                $scraped_data = json_decode($anomaly['scraped_yahoo_data'], true);
                if ($scraped_data && isset($scraped_data['url'])) {
                    echo "<p><strong>元URL:</strong> <a href='{$scraped_data['url']}' target='_blank'>{$scraped_data['url']}</a></p>";
                }
            }
            echo "</div>";
        }
    }
    
    // 3. 画像データの検証
    echo "<h2>3. 画像データの検証</h2>";
    
    $imageSql = "SELECT COUNT(*) as total_count,
                        COUNT(CASE WHEN active_image_url LIKE 'https://placehold.co%' THEN 1 END) as placeholder_count,
                        COUNT(CASE WHEN active_image_url IS NULL OR active_image_url = '' THEN 1 END) as null_count
                 FROM yahoo_scraped_products";
    
    $imageStmt = $pdo->query($imageSql);
    $imageStats = $imageStmt->fetch();
    
    echo "<div style='background: #e3f2fd; padding: 15px; border-radius: 5px;'>";
    echo "<h3>画像統計:</h3>";
    echo "<p><strong>総商品数:</strong> {$imageStats['total_count']}件</p>";
    echo "<p><strong>プレースホルダー画像:</strong> {$imageStats['placeholder_count']}件 " . ($imageStats['placeholder_count'] > 0 ? "⚠️" : "✅") . "</p>";
    echo "<p><strong>画像URL なし:</strong> {$imageStats['null_count']}件 " . ($imageStats['null_count'] > 0 ? "⚠️" : "✅") . "</p>";
    
    $valid_images = $imageStats['total_count'] - $imageStats['placeholder_count'] - $imageStats['null_count'];
    echo "<p><strong>有効な画像:</strong> {$valid_images}件</p>";
    echo "</div>";
    
    // 4. ソース表示の検証
    echo "<h2>4. ソース表示の検証</h2>";
    
    // editing.phpでの表示ロジックをシミュレート
    $editingSimulationSql = "SELECT id, source_item_id, active_title, price_jpy, active_image_url, scraped_yahoo_data, status, created_at, updated_at
                             FROM yahoo_scraped_products 
                             WHERE status IN ('scraped', 'pending') 
                             ORDER BY created_at DESC 
                             LIMIT 3";
    
    $editingStmt = $pdo->query($editingSimulationSql);
    $editingProducts = $editingStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 5px;'>";
    echo "<h3>editing.php 表示シミュレーション:</h3>";
    
    foreach ($editingProducts as $product) {
        $scraped_data = json_decode($product['scraped_yahoo_data'], true);
        $source = $scraped_data['url'] ?? '';
        
        // ソースの判定ロジック
        $source_display = 'Unknown';
        if (strpos($source, 'auctions.yahoo.co.jp') !== false) {
            $source_display = 'ヤフオク';
        } elseif (strpos($source, 'yahoo.co.jp') !== false) {
            $source_display = 'Yahoo';
        }
        
        echo "<div style='border: 1px solid #ddd; margin: 5px 0; padding: 10px;'>";
        echo "<p><strong>Item ID:</strong> {$product['source_item_id']}</p>";
        echo "<p><strong>タイトル:</strong> " . htmlspecialchars(substr($product['active_title'], 0, 50)) . "</p>";
        echo "<p><strong>価格:</strong> ¥" . number_format($product['price_jpy']) . "</p>";
        echo "<p><strong>ソース:</strong> {$source_display} " . ($source_display === 'ヤフオク' ? '✅' : '❌') . "</p>";
        echo "<p><strong>元URL:</strong> {$source}</p>";
        echo "</div>";
    }
    echo "</div>";
    
    echo "<h2>5. 推奨対応</h2>";
    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
    echo "<ol>";
    echo "<li><strong>価格検証強化:</strong> スクレイピング時に価格範囲チェック追加</li>";
    echo "<li><strong>ソース表示修正:</strong> editing.phpでのソース判定ロジック修正</li>";
    echo "<li><strong>画像取得改善:</strong> 複数画像の適切な保存・表示</li>";
    echo "<li><strong>データ更新確認:</strong> 同一商品の上書き動作確認</li>";
    echo "<li><strong>アラート機能:</strong> 異常価格データの即座検出・通知</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='scraping.php'>← スクレイピングに戻る</a> | <a href='../05_editing/editing.php'>データ編集へ →</a></p>";
?>
