<?php
/**
 * データベース緊急診断・修正ツール
 * 現在のデータと構造を詳細に確認し、問題を特定・修正
 */

echo "<h1>🚨 データベース緊急診断・修正ツール</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. テーブル構造詳細確認
    echo "<h2>1. yahoo_scraped_products テーブル構造詳細確認</h2>";
    
    $columnSql = "SELECT column_name, data_type, is_nullable, column_default, character_maximum_length
                  FROM information_schema.columns 
                  WHERE table_name = 'yahoo_scraped_products' 
                  ORDER BY ordinal_position";
    
    $columnStmt = $pdo->query($columnSql);
    $columns = $columnStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
    echo "<tr><th>カラム名</th><th>データ型</th><th>NULL許可</th><th>デフォルト値</th><th>文字長</th></tr>";
    
    $existing_columns = [];
    $hybrid_columns = ['cached_price_usd', 'cache_rate', 'cache_updated_at'];
    $missing_columns = [];
    
    foreach ($columns as $column) {
        $existing_columns[] = $column['column_name'];
        echo "<tr>";
        echo "<td><strong>{$column['column_name']}</strong></td>";
        echo "<td>{$column['data_type']}</td>";
        echo "<td>{$column['is_nullable']}</td>";
        echo "<td>" . ($column['column_default'] ?: 'なし') . "</td>";
        echo "<td>" . ($column['character_maximum_length'] ?: 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 不足カラム確認
    $missing_columns = array_diff($hybrid_columns, $existing_columns);
    
    if (!empty($missing_columns)) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
        echo "❌ <strong>重大問題発見:</strong> ハイブリッド価格管理カラムが不足<br>";
        echo "不足カラム: " . implode(', ', $missing_columns);
        echo "</div>";
        
        // 不足カラムを自動追加
        echo "<h3>🔧 不足カラム自動追加</h3>";
        foreach ($missing_columns as $column) {
            $alterSql = '';
            switch ($column) {
                case 'cached_price_usd':
                    $alterSql = "ALTER TABLE yahoo_scraped_products ADD COLUMN cached_price_usd DECIMAL(10, 2)";
                    break;
                case 'cache_rate':
                    $alterSql = "ALTER TABLE yahoo_scraped_products ADD COLUMN cache_rate DECIMAL(10, 4)";
                    break;
                case 'cache_updated_at':
                    $alterSql = "ALTER TABLE yahoo_scraped_products ADD COLUMN cache_updated_at TIMESTAMP";
                    break;
            }
            
            if ($alterSql) {
                try {
                    $pdo->exec($alterSql);
                    echo "<div style='color: green; padding: 5px;'>✅ {$column} カラム追加完了</div>";
                } catch (PDOException $e) {
                    echo "<div style='color: red; padding: 5px;'>❌ {$column} 追加エラー: " . $e->getMessage() . "</div>";
                }
            }
        }
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ ハイブリッド価格管理カラムは存在します</div>";
    }
    
    // 2. 実際のデータサンプル確認
    echo "<h2>2. 実際のデータサンプル確認（最新5件）</h2>";
    
    $sampleSql = "SELECT id, source_item_id, active_title, price_jpy, active_price_usd, cached_price_usd, cache_rate, updated_at,
                         (scraped_yahoo_data->>'url')::text as source_url
                  FROM yahoo_scraped_products 
                  ORDER BY updated_at DESC 
                  LIMIT 5";
    
    $sampleStmt = $pdo->query($sampleSql);
    $sampleData = $sampleStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($sampleData)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
        echo "<tr><th>ID</th><th>source_item_id</th><th>タイトル</th><th>円価格</th><th>USD価格</th><th>キャッシュUSD</th><th>レート</th><th>問題診断</th></tr>";
        
        foreach ($sampleData as $row) {
            echo "<tr>";
            echo "<td>{$row['id']}</td>";
            echo "<td>" . substr($row['source_item_id'], 0, 15) . "...</td>";
            echo "<td>" . substr($row['active_title'], 0, 30) . "...</td>";
            echo "<td style='font-weight: bold; color: #2e8b57;'>¥" . number_format($row['price_jpy'] ?: 0) . "</td>";
            echo "<td style='color: #dc143c;'>$" . number_format($row['active_price_usd'] ?: 0, 2) . "</td>";
            echo "<td style='color: #4682b4;'>$" . number_format($row['cached_price_usd'] ?: 0, 2) . "</td>";
            echo "<td>{$row['cache_rate']}</td>";
            
            // 問題診断
            $problems = [];
            if ($row['price_jpy'] == 0) {
                $problems[] = "円価格0";
            }
            if ($row['cached_price_usd'] === null && $row['price_jpy'] > 0) {
                $problems[] = "キャッシュなし";
            }
            if (strpos($row['source_url'], 'auctions.yahoo.co.jp') === false) {
                $problems[] = "ヤフオク以外";
            }
            
            echo "<td>" . (empty($problems) ? "✅ 正常" : "❌ " . implode(", ", $problems)) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ データが存在しません</div>";
    }
    
    // 3. データ統計詳細
    echo "<h2>3. データ統計詳細</h2>";
    
    $statsSql = "SELECT 
                    COUNT(*) as total_count,
                    COUNT(CASE WHEN price_jpy > 0 THEN 1 END) as valid_jpy_count,
                    COUNT(CASE WHEN cached_price_usd IS NOT NULL THEN 1 END) as cached_usd_count,
                    COUNT(CASE WHEN active_price_usd IS NOT NULL THEN 1 END) as active_usd_count,
                    COUNT(CASE WHEN (scraped_yahoo_data->>'url')::text LIKE '%auctions.yahoo.co.jp%' THEN 1 END) as yahoo_auction_count,
                    AVG(price_jpy) as avg_jpy,
                    AVG(cached_price_usd) as avg_cached_usd,
                    AVG(active_price_usd) as avg_active_usd,
                    MIN(price_jpy) as min_jpy,
                    MAX(price_jpy) as max_jpy
                 FROM yahoo_scraped_products";
    
    $statsStmt = $pdo->query($statsSql);
    $stats = $statsStmt->fetch();
    
    echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 5px;'>";
    echo "<h4>📊 データ統計:</h4>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>項目</th><th>値</th><th>状態</th></tr>";
    echo "<tr><td>総データ数</td><td>{$stats['total_count']}件</td><td>" . ($stats['total_count'] > 0 ? "✅" : "❌") . "</td></tr>";
    echo "<tr><td>有効な円価格</td><td>{$stats['valid_jpy_count']}件</td><td>" . ($stats['valid_jpy_count'] > 0 ? "✅" : "❌") . "</td></tr>";
    echo "<tr><td>キャッシュUSD価格</td><td>{$stats['cached_usd_count']}件</td><td>" . ($stats['cached_usd_count'] > 0 ? "✅" : "❌") . "</td></tr>";
    echo "<tr><td>アクティブUSD価格</td><td>{$stats['active_usd_count']}件</td><td>" . ($stats['active_usd_count'] > 0 ? "✅" : "❌") . "</td></tr>";
    echo "<tr><td>ヤフオクデータ</td><td>{$stats['yahoo_auction_count']}件</td><td>" . ($stats['yahoo_auction_count'] > 0 ? "✅" : "❌") . "</td></tr>";
    echo "<tr><td>平均円価格</td><td>¥" . number_format($stats['avg_jpy'] ?: 0) . "</td><td>-</td></tr>";
    echo "<tr><td>価格範囲</td><td>¥" . number_format($stats['min_jpy'] ?: 0) . " - ¥" . number_format($stats['max_jpy'] ?: 0) . "</td><td>-</td></tr>";
    echo "</table>";
    echo "</div>";
    
    // 4. 緊急修正実行
    echo "<h2>4. 🚨 緊急修正実行</h2>";
    
    // 4-1. キャッシュ価格一括更新
    echo "<h3>4-1. キャッシュ価格一括更新</h3>";
    $updateCacheSql = "UPDATE yahoo_scraped_products 
                       SET cached_price_usd = ROUND(price_jpy / 150.0, 2),
                           cache_rate = 150.0,
                           cache_updated_at = CURRENT_TIMESTAMP
                       WHERE price_jpy > 0 AND (cached_price_usd IS NULL OR cache_updated_at IS NULL)";
    
    $updateResult = $pdo->exec($updateCacheSql);
    echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>🔄 {$updateResult}件のキャッシュ価格を更新しました</div>";
    
    // 4-2. 0円データの修正
    echo "<h3>4-2. 0円データの確認・修正</h3>";
    $zeroSql = "SELECT COUNT(*) as zero_count FROM yahoo_scraped_products WHERE price_jpy = 0 OR price_jpy IS NULL";
    $zeroStmt = $pdo->query($zeroSql);
    $zeroCount = $zeroStmt->fetch()['zero_count'];
    
    if ($zeroCount > 0) {
        echo "<div style='color: orange; padding: 10px; background: #fff3cd;'>⚠️ 価格が0円またはNULLのデータが{$zeroCount}件存在します</div>";
        
        // 0円データのサンプル表示
        $zeroSampleSql = "SELECT id, source_item_id, active_title, price_jpy, active_price_usd 
                          FROM yahoo_scraped_products 
                          WHERE price_jpy = 0 OR price_jpy IS NULL 
                          LIMIT 3";
        $zeroSampleStmt = $pdo->query($zeroSampleSql);
        $zeroSamples = $zeroSampleStmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>0円データサンプル:</h4>";
        echo "<table border='1' style='border-collapse: collapse; font-size: 0.8em;'>";
        echo "<tr><th>ID</th><th>source_item_id</th><th>タイトル</th><th>円価格</th><th>USD価格</th></tr>";
        foreach ($zeroSamples as $sample) {
            echo "<tr>";
            echo "<td>{$sample['id']}</td>";
            echo "<td>" . substr($sample['source_item_id'], 0, 20) . "</td>";
            echo "<td>" . substr($sample['active_title'], 0, 30) . "</td>";
            echo "<td style='color: red;'>{$sample['price_jpy']}</td>";
            echo "<td>{$sample['active_price_usd']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ 0円データは存在しません</div>";
    }
    
    // 5. 修正後のデータ確認
    echo "<h2>5. 修正後のデータ確認</h2>";
    
    $verifyStmt = $pdo->query($sampleSql);
    $verifyData = $verifyStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
    echo "<tr><th>ID</th><th>円価格</th><th>キャッシュUSD</th><th>レート</th><th>プラットフォーム</th><th>状態</th></tr>";
    
    foreach ($verifyData as $row) {
        $platform = strpos($row['source_url'], 'auctions.yahoo.co.jp') !== false ? 'ヤフオク' : 'その他';
        
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td style='font-weight: bold; color: #2e8b57;'>¥" . number_format($row['price_jpy']) . "</td>";
        echo "<td style='color: #4682b4;'>$" . number_format($row['cached_price_usd'] ?: 0, 2) . "</td>";
        echo "<td>{$row['cache_rate']}</td>";
        echo "<td style='font-weight: bold;'>{$platform}</td>";
        echo "<td>" . ($row['cached_price_usd'] ? "✅ 修正済み" : "❌ 要再修正") . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 6. editing.php テスト用SQL生成
    echo "<h2>6. editing.php テスト用SQL</h2>";
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>";
    echo "<h4>editing.phpで使用されるべきSQL:</h4>";
    echo "<pre style='background: #e9ecef; padding: 10px; border-radius: 3px; overflow-x: auto;'>";
    
    $testSql = "SELECT 
                    id,
                    source_item_id as item_id,
                    COALESCE(active_title, 'タイトルなし') as title,
                    price_jpy as price,
                    COALESCE(cached_price_usd, ROUND(price_jpy / 150.0, 2)) as current_price,
                    COALESCE((scraped_yahoo_data->>'category')::text, 'N/A') as category_name,
                    COALESCE((scraped_yahoo_data->>'condition')::text, 'N/A') as condition_name,
                    COALESCE(active_image_url, 'https://placehold.co/150x150/725CAD/FFFFFF/png?text=No+Image') as picture_url,
                    (scraped_yahoo_data->>'url')::text as source_url,
                    updated_at,
                    CASE 
                        WHEN (scraped_yahoo_data->>'url')::text LIKE '%auctions.yahoo.co.jp%' THEN 'ヤフオク'
                        WHEN (scraped_yahoo_data->>'url')::text LIKE '%yahoo.co.jp%' THEN 'Yahoo'
                        ELSE 'Unknown'
                    END as platform,
                    cache_rate,
                    cache_updated_at
                FROM yahoo_scraped_products 
                WHERE 1=1 
                ORDER BY updated_at DESC 
                LIMIT 5";
    
    echo htmlspecialchars($testSql);
    echo "</pre>";
    
    // 実際にテストSQLを実行
    echo "<h4>テストSQL実行結果:</h4>";
    $testStmt = $pdo->query($testSql);
    $testResults = $testStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($testResults)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
        echo "<tr><th>ID</th><th>タイトル</th><th>円価格</th><th>USD価格</th><th>プラットフォーム</th></tr>";
        
        foreach ($testResults as $result) {
            echo "<tr>";
            echo "<td>{$result['id']}</td>";
            echo "<td>" . substr($result['title'], 0, 30) . "...</td>";
            echo "<td style='font-weight: bold; color: #2e8b57;'>¥" . number_format($result['price']) . "</td>";
            echo "<td style='color: #4682b4;'>$" . number_format($result['current_price'], 2) . "</td>";
            echo "<td><strong>{$result['platform']}</strong></td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    echo "</div>";
    
    // 7. 次のアクション
    echo "<h2>7. 次のアクション</h2>";
    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
    echo "<h4>✅ 修正完了項目:</h4>";
    echo "<ul>";
    echo "<li>ハイブリッド価格管理カラム確認・追加</li>";
    echo "<li>キャッシュ価格の一括更新</li>";
    echo "<li>データ整合性確認</li>";
    echo "<li>テストSQL動作確認</li>";
    echo "</ul>";
    
    echo "<h4>🔧 次に実行すべき操作:</h4>";
    echo "<ol>";
    echo "<li><strong>editing.phpの強制リロード</strong> (Ctrl+F5)</li>";
    echo "<li><strong>「未出品データ表示」ボタンクリック</strong></li>";
    echo "<li><strong>表示確認</strong> - 円価格とプラットフォーム名</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p style='text-align: center;'>";
echo "<a href='../05_editing/editing.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>📝 editing.phpで確認</a>";
echo "<a href='scraping.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>🕷️ スクレイピング実行</a>";
echo "</p>";
?>
