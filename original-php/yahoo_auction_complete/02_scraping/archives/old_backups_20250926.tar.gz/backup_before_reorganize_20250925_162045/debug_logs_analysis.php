<?php
/**
 * スクレイピングログ解析・エラー抽出ツール
 */

echo "<h1>📊 スクレイピングログ解析</h1>";

$log_file = __DIR__ . '/scraping_logs.txt';

if (!file_exists($log_file)) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ ログファイルが見つかりません: {$log_file}</div>";
    exit;
}

echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ ログファイル発見: " . filesize($log_file) . " bytes</div>";

// ログを読み込み
$logs = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$logs = array_reverse($logs); // 新しい順

echo "<h2>最新ログ（直近50件）</h2>";

$error_count = 0;
$db_errors = [];
$recent_logs = array_slice($logs, 0, 50);

echo "<div style='background: #1a1a1a; color: #00ff00; padding: 15px; border-radius: 8px; font-family: monospace; max-height: 400px; overflow-y: auto;'>";

foreach ($recent_logs as $index => $log) {
    $color = '#00ff00'; // デフォルト緑
    
    if (strpos($log, '[ERROR]') !== false) {
        $color = '#ff4444';
        $error_count++;
        
        // データベース関連エラーを抽出
        if (strpos($log, 'DB') !== false || strpos($log, 'PDO') !== false || strpos($log, 'データベース') !== false) {
            $db_errors[] = $log;
        }
    } elseif (strpos($log, '[WARNING]') !== false) {
        $color = '#ffaa44';
    } elseif (strpos($log, '[SUCCESS]') !== false) {
        $color = '#44ff44';
    }
    
    echo "<div style='color: {$color}; margin-bottom: 2px;'>{$log}</div>";
}

echo "</div>";

echo "<h2>📈 ログ統計</h2>";
echo "<ul>";
echo "<li><strong>総ログ数:</strong> " . count($logs) . "件</li>";
echo "<li><strong>エラー数（直近50件）:</strong> {$error_count}件</li>";
echo "<li><strong>DBエラー数:</strong> " . count($db_errors) . "件</li>";
echo "<li><strong>ファイルサイズ:</strong> " . number_format(filesize($log_file)) . " bytes</li>";
echo "</ul>";

if (!empty($db_errors)) {
    echo "<h2>🚨 データベース関連エラー詳細</h2>";
    echo "<div style='background: #2a1f1f; color: #ff6b6b; padding: 15px; border-radius: 8px; font-family: monospace;'>";
    
    foreach ($db_errors as $db_error) {
        echo "<div style='margin-bottom: 10px; padding: 8px; background: #3a2525; border-left: 4px solid #ff4444;'>";
        echo htmlspecialchars($db_error);
        echo "</div>";
    }
    
    echo "</div>";
}

// 最新のスクレイピング試行を分析
echo "<h2>🔍 最新スクレイピング試行分析</h2>";

$scraping_sessions = [];
$current_session = [];

foreach ($logs as $log) {
    if (strpos($log, 'スクレイピング開始') !== false) {
        if (!empty($current_session)) {
            $scraping_sessions[] = $current_session;
        }
        $current_session = [$log];
    } elseif (!empty($current_session)) {
        $current_session[] = $log;
    }
}

if (!empty($current_session)) {
    $scraping_sessions[] = $current_session;
}

if (!empty($scraping_sessions)) {
    $latest_session = $scraping_sessions[0];
    
    echo "<h3>最新スクレイピングセッション（" . count($latest_session) . "行）</h3>";
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px; max-height: 300px; overflow-y: auto;'>";
    
    foreach ($latest_session as $session_log) {
        $style = '';
        if (strpos($session_log, '[ERROR]') !== false) {
            $style = 'color: #dc3545; font-weight: bold;';
        } elseif (strpos($session_log, '[SUCCESS]') !== false) {
            $style = 'color: #28a745; font-weight: bold;';
        } elseif (strpos($session_log, '[WARNING]') !== false) {
            $style = 'color: #ffc107; font-weight: bold;';
        }
        
        echo "<div style='{$style}; font-family: monospace; margin-bottom: 3px;'>";
        echo htmlspecialchars($session_log);
        echo "</div>";
    }
    
    echo "</div>";
    
    // セッション内の問題分析
    $session_errors = array_filter($latest_session, function($log) {
        return strpos($log, '[ERROR]') !== false;
    });
    
    if (!empty($session_errors)) {
        echo "<h4>🔥 このセッションのエラー</h4>";
        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 5px;'>";
        foreach ($session_errors as $error) {
            echo "<div style='color: #721c24; margin-bottom: 5px;'>" . htmlspecialchars($error) . "</div>";
        }
        echo "</div>";
    }
}

echo "<h2>🛠️ 推奨対処法</h2>";
echo "<div style='background: #d1ecf1; padding: 15px; border-radius: 8px;'>";
echo "<ol>";
echo "<li><strong>データベーステストを実行:</strong><br>";
echo "   <a href='debug_database_save.php' target='_blank'>debug_database_save.php</a> でテーブル構造とデータ挿入をテスト</li>";
echo "<li><strong>Emergency Parser確認:</strong><br>";
echo "   yahoo_parser_emergency.php が正常に動作しているか確認</li>";
echo "<li><strong>スクレイピング再実行:</strong><br>";
echo "   <a href='scraping.php' target='_blank'>scraping.php</a> で詳細ログ付きで再実行</li>";
echo "<li><strong>手動デバッグ:</strong><br>";
echo "   PostgreSQL クライアントで直接テーブル確認</li>";
echo "</ol>";
echo "</div>";

echo "<hr>";
echo "<p>📝 <strong>次のステップ:</strong></p>";
echo "<p>1. <a href='debug_database_save.php'>データベーステスト実行</a></p>";
echo "<p>2. <a href='scraping.php'>スクレイピング再実行</a></p>";
echo "<p>3. <a href='../05_editing/editing.php'>editing.php で結果確認</a></p>";
?>
