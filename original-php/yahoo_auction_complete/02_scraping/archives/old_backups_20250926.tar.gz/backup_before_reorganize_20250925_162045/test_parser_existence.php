<?php
/**
 * パーサーファイル存在確認スクリプト
 */

header('Content-Type: application/json; charset=utf-8');

$parserFiles = [
    'yahoo_parser_fixed_v2.php' => 'ジェミナイ分析対応修正版パーサー',
    'yahoo_parser_gemini_advised.php' => 'Geminiアドバイス実装版パーサー', 
    'yahoo_parser_v2025.php' => '2025年版構造ベースパーサー',
    'yahoo_parser_enhanced.php' => '強化版パーサー',
    'yahoo_parser_realhtml.php' => '実HTML構造対応パーサー'
];

$results = [];
$existingFiles = 0;

foreach ($parserFiles as $filename => $description) {
    $filepath = __DIR__ . '/' . $filename;
    $exists = file_exists($filepath);
    
    if ($exists) {
        $filesize = filesize($filepath);
        $existingFiles++;
        
        // 関数存在確認
        $functions = [];
        if ($filename === 'yahoo_parser_fixed_v2.php') {
            include_once $filepath;
            $functions = [
                'parseYahooAuctionHTML_Fixed' => function_exists('parseYahooAuctionHTML_Fixed'),
                'parseYahooAuctionHTML_GeminiFixed' => function_exists('parseYahooAuctionHTML_GeminiFixed'),
                'extractFromJSON' => function_exists('extractFromJSON'),
                'extractFromHTML' => function_exists('extractFromHTML'),
                'validateDataQuality' => function_exists('validateDataQuality')
            ];
        }
        
        $results[] = [
            'filename' => $filename,
            'description' => $description,
            'exists' => true,
            'filesize' => $filesize,
            'functions' => $functions,
            'last_modified' => date('Y-m-d H:i:s', filemtime($filepath))
        ];
    } else {
        $results[] = [
            'filename' => $filename,
            'description' => $description,
            'exists' => false,
            'error' => 'ファイルが存在しません'
        ];
    }
}

// データベース接続テスト
$dbTest = [];
try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // テーブル存在確認
    $stmt = $pdo->prepare("SELECT table_name FROM information_schema.tables WHERE table_name = 'yahoo_scraped_products'");
    $stmt->execute();
    $tableExists = $stmt->fetch();
    
    $dbTest = [
        'connection' => 'success',
        'database' => 'nagano3_db',
        'table_exists' => $tableExists ? 'yahoo_scraped_products テーブル存在' : 'yahoo_scraped_products テーブルなし'
    ];
    
} catch (Exception $e) {
    $dbTest = [
        'connection' => 'failed',
        'error' => $e->getMessage()
    ];
}

$response = [
    'success' => true,
    'data' => [
        'parser_files' => $results,
        'existing_files_count' => $existingFiles,
        'total_files_count' => count($parserFiles),
        'database_test' => $dbTest,
        'test_timestamp' => date('Y-m-d H:i:s')
    ]
];

echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
