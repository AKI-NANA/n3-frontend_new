<?php
/**
 * Yahoo オークション 高精度スクレイピング（2025年版）
 * Geminiのアドバイスに基づいた改善実装
 */

/**
 * 改善されたYahoo オークション HTML解析
 */
function parseYahooAuctionHTML_V2025_Enhanced($html, $url, $item_id) {
    try {
        writeLog("🚀 [高精度解析開始] Enhanced parsing for: {$item_id}", 'INFO');
        
        // HTMLエンティティのデコード
        $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
        
        // 初期化
        $errors = [];
        $warnings = [];
        
        // 1. タイトル抽出（複数パターン対応）
        $title = extractTitleWithValidation($html, $errors);
        
        // 2. 価格抽出（現在価格・即決価格の区別）
        $price_data = extractPriceWithValidation($html, $errors);
        
        // 3. 画像抽出（メイン画像優先）
        $images = extractImagesWithValidation($html, $errors);
        
        // 4. カテゴリ抽出（パンくずリスト）
        $category = extractCategoryWithValidation($html, $errors);
        
        // 5. 商品状態抽出
        $condition = extractConditionWithValidation($html, $errors);
        
        // 6. 出品者情報抽出
        $seller_info = extractSellerWithValidation($html, $errors);
        
        // 7. オークション情報抽出
        $auction_info = extractAuctionInfoWithValidation($html, $errors);
        
        // データ検証
        $validation_result = validateScrapedData([
            'title' => $title,
            'price_data' => $price_data,
            'images' => $images,
            'category' => $category,
            'condition' => $condition
        ], $errors, $warnings);
        
        if (!$validation_result['is_valid']) {
            writeLog("❌ [データ検証失敗] " . implode(', ', $validation_result['critical_errors']), 'ERROR');
            
            // クリティカルエラーがある場合は false を返す
            if (!empty($validation_result['critical_errors'])) {
                return false;
            }
        }
        
        $product_data = [
            'item_id' => $item_id,
            'title' => $title,
            'description' => mb_substr($title, 0, 200, 'UTF-8'),
            'current_price' => $price_data['current_price'],
            'immediate_price' => $price_data['immediate_price'] ?? null,
            'condition' => $condition,
            'category' => $category,
            'images' => $images,
            'main_image' => $images[0] ?? null,
            'seller_info' => $seller_info,
            'auction_info' => $auction_info,
            'scraped_at' => date('Y-m-d H:i:s'),
            'source_url' => $url,
            'scraping_method' => 'enhanced_v2025',
            'data_quality' => $validation_result['quality_score'],
            'errors' => $errors,
            'warnings' => $warnings,
            'validation_status' => $validation_result['is_valid'] ? 'valid' : 'warning'
        ];
        
        writeLog("✅ [高精度解析完了] Quality: {$validation_result['quality_score']}%, Errors: " . count($errors) . ", Warnings: " . count($warnings), 'SUCCESS');
        
        return $product_data;
        
    } catch (Exception $e) {
        writeLog("❌ [高精度解析例外] " . $e->getMessage(), 'ERROR');
        return false;
    }
}

/**
 * タイトル抽出（検証付き）
 */
function extractTitleWithValidation($html, &$errors) {
    $title_patterns = [
        // 優先度順に試行
        '/<h1[^>]*class="[^"]*ProductTitle[^"]*"[^>]*>([^<]+)<\/h1>/i',
        '/<h1[^>]*class="[^"]*ProductName[^"]*"[^>]*>([^<]+)<\/h1>/i',
        '/<title[^>]*>([^<]+?) - Yahoo!\u30aa\u30fc\u30af\u30b7\u30e7\u30f3<\/title>/i',
        '/<h1[^>]*>([^<]+)<\/h1>/i'
    ];
    
    foreach ($title_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $title = trim(strip_tags($matches[1]));
            
            // タイトル検証
            if (strlen($title) > 5 && strlen($title) < 200) {
                writeLog("✅ [タイトル取得成功] " . substr($title, 0, 50) . "...", 'SUCCESS');
                return $title;
            }
        }
    }
    
    $errors[] = 'タイトルの取得に失敗しました';
    writeLog("❌ [タイトル取得失敗] 有効なタイトルが見つかりません", 'ERROR');
    return null;
}

/**
 * 価格抽出（現在価格・即決価格の区別、検証付き）
 */
function extractPriceWithValidation($html, &$errors) {
    $price_data = [
        'current_price' => null,
        'immediate_price' => null,
        'start_price' => null,
        'tax_included' => false,
        'shipping_free' => false
    ];
    
    // 現在価格の抽出パターン
    $current_price_patterns = [
        '/現在価格[^0-9]*([0-9,]+)[^0-9]*円/u',
        '/class="[^"]*current[^"]*price[^"]*"[^>]*>[\s\S]*?([0-9,]+)[\s\S]*?円/u',
        '/class="[^"]*PriceBox__price--current[^"]*"[^>]*>[\s\S]*?([0-9,]+)/u'
    ];
    
    // 即決価格の抽出パターン
    $immediate_price_patterns = [
        '/即決価格[^0-9]*([0-9,]+)[^0-9]*円/u',
        '/class="[^"]*immediate[^"]*price[^"]*"[^>]*>[\s\S]*?([0-9,]+)[\s\S]*?円/u',
        '/class="[^"]*PriceBox__price--immediate[^"]*"[^>]*>[\s\S]*?([0-9,]+)/u'
    ];
    
    // 現在価格を抽出
    foreach ($current_price_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $price = (int)str_replace(',', '', $matches[1]);
            if ($price > 0 && $price < 100000000) { // 妥当性チェック
                $price_data['current_price'] = $price;
                writeLog("✅ [現在価格取得] ¥{$price}", 'SUCCESS');
                break;
            }
        }
    }
    
    // 即決価格を抽出
    foreach ($immediate_price_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $price = (int)str_replace(',', '', $matches[1]);
            if ($price > 0 && $price < 100000000) {
                $price_data['immediate_price'] = $price;
                writeLog("✅ [即決価格取得] ¥{$price}", 'SUCCESS');
                break;
            }
        }
    }
    
    // 税込み・送料情報の確認
    if (preg_match('/税込|税込み/u', $html)) {
        $price_data['tax_included'] = true;
    }
    
    if (preg_match('/送料無料|送料込/u', $html)) {
        $price_data['shipping_free'] = true;
    }
    
    // 価格検証
    if (is_null($price_data['current_price']) && is_null($price_data['immediate_price'])) {
        $errors[] = '有効な価格情報が取得できませんでした';
        writeLog("❌ [価格取得失敗] 現在価格・即決価格ともに取得できません", 'ERROR');
    }
    
    return $price_data;
}

/**
 * 画像抽取（メイン画像優先、高解像度対応、検証付き）
 */
function extractImagesWithValidation($html, &$errors) {
    $images = [];
    
    // メイン画像の抽出パターン（優先度順）
    $main_image_patterns = [
        '/class="[^"]*ProductImage__item[^"]*"[^>]*>[\s\S]*?<img[^>]*src="([^"]+)"/i',
        '/class="[^"]*main-image[^"]*"[^>]*>[\s\S]*?<img[^>]*src="([^"]+)"/i',
        '/data-index="0"[^>]*>[\s\S]*?<img[^>]*src="([^"]+)"/i',
        '/<img[^>]*class="[^"]*ProductImage__image[^"]*"[^>]*src="([^"]+)"/i'
    ];
    
    // 追加画像の抽出パターン
    $additional_image_patterns = [
        '/<img[^>]*src="(https:\/\/auctions\.c\.yimg\.jp[^"]+)"/gi',
        '/<img[^>]*src="(https:\/\/[^"]*yimg\.jp[^"]*auctions[^"]+)"/gi'
    ];
    
    // メイン画像を最優先で抽出
    foreach ($main_image_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $image_url = enhanceImageResolution($matches[1]);
            if (isValidImageUrl($image_url)) {
                array_unshift($images, $image_url); // 配列の先頭に追加
                writeLog("✅ [メイン画像取得] {$image_url}", 'SUCCESS');
                break;
            }
        }
    }
    
    // 追加画像を抽出
    foreach ($additional_image_patterns as $pattern) {
        if (preg_match_all($pattern, $html, $matches)) {
            foreach ($matches[1] as $img_url) {
                $enhanced_url = enhanceImageResolution($img_url);
                if (isValidImageUrl($enhanced_url) && !in_array($enhanced_url, $images)) {
                    $images[] = $enhanced_url;
                    if (count($images) >= 5) break 2; // 最大5枚まで
                }
            }
        }
    }
    
    // 画像検証
    if (empty($images)) {
        $errors[] = '商品画像が取得できませんでした';
        writeLog("❌ [画像取得失敗] 有効な画像URLが見つかりません", 'ERROR');
    } else {
        writeLog("✅ [画像取得完了] " . count($images) . "枚の画像を取得", 'SUCCESS');
    }
    
    return array_values(array_unique($images)); // 重複削除
}

/**
 * 画像解像度の向上
 */
function enhanceImageResolution($image_url) {
    // サムネイル接尾辞を削除
    $enhanced_url = preg_replace('/(_s|_t|_m)\.jpg$/i', '.jpg', $image_url);
    
    // サイズ指定を大きなサイズに変更
    $enhanced_url = preg_replace('/\/\d{3,4}\//', '/1000/', $enhanced_url);
    
    return $enhanced_url;
}

/**
 * 画像URL の有効性チェック
 */
function isValidImageUrl($url) {
    // 基本的なURL形式チェック
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    
    // Yahoo画像サーバーかチェック
    if (!preg_match('/yimg\.jp/i', $url)) {
        return false;
    }
    
    // 不要な画像を除外
    $excluded_patterns = [
        '/placeholder/i',
        '/loading/i',
        '/na_170x170/i',
        '/noimage/i'
    ];
    
    foreach ($excluded_patterns as $pattern) {
        if (preg_match($pattern, $url)) {
            return false;
        }
    }
    
    return true;
}

/**
 * カテゴリ抽出（パンくずリスト対応、検証付き）
 */
function extractCategoryWithValidation($html, &$errors) {
    // パンくずリストからカテゴリを抽出
    $breadcrumb_patterns = [
        '/<nav[^>]*class="[^"]*breadcrumb[^"]*"[^>]*>([\s\S]*?)<\/nav>/i',
        '/<ol[^>]*class="[^"]*breadcrumb[^"]*"[^>]*>([\s\S]*?)<\/ol>/i',
        '/<div[^>]*class="[^"]*breadcrumb[^"]*"[^>]*>([\s\S]*?)<\/div>/i'
    ];
    
    foreach ($breadcrumb_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $breadcrumb_html = $matches[1];
            
            // リンクテキストを抽出
            if (preg_match_all('/<a[^>]*>([^<]+)<\/a>/i', $breadcrumb_html, $link_matches)) {
                $categories = array_map('trim', $link_matches[1]);
                
                // 不要なカテゴリを除外
                $filtered_categories = array_filter($categories, function($cat) {
                    return !in_array($cat, ['ホーム', 'トップ', 'Yahoo!オークション', '']);
                });
                
                if (!empty($filtered_categories)) {
                    $category = end($filtered_categories); // 最後のカテゴリを使用
                    writeLog("✅ [カテゴリ取得] {$category}", 'SUCCESS');
                    return $category;
                }
            }
        }
    }
    
    // フォールバック: タイトルからカテゴリを推測
    $fallback_category = inferCategoryFromTitle($html);
    if ($fallback_category) {
        writeLog("⚠️ [カテゴリ推測] {$fallback_category}", 'WARNING');
        return $fallback_category;
    }
    
    $errors[] = 'カテゴリ情報が取得できませんでした';
    writeLog("❌ [カテゴリ取得失敗] 有効なカテゴリが見つかりません", 'ERROR');
    return null;
}

/**
 * タイトルからカテゴリを推測
 */
function inferCategoryFromTitle($html) {
    // タイトルを取得
    if (preg_match('/<title[^>]*>([^<]+)<\/title>/i', $html, $matches)) {
        $title = $matches[1];
        
        // カテゴリキーワードマッピング
        $category_keywords = [
            'ポケモンカード' => ['ポケモン', 'ポケカ', 'Pokemon'],
            'トレーディングカード' => ['カード', 'TCG', 'トレカ'],
            'フィギュア' => ['フィギュア', 'figure', 'ねんどろいど'],
            'アンティーク' => ['アンティーク', 'ヴィンテージ', 'vintage'],
            '時計' => ['時計', 'watch', '腕時計'],
            'アクセサリー' => ['ネックレス', 'リング', 'ピアス', 'ブレスレット']
        ];
        
        foreach ($category_keywords as $category => $keywords) {
            foreach ($keywords as $keyword) {
                if (stripos($title, $keyword) !== false) {
                    return $category;
                }
            }
        }
    }
    
    return null;
}

/**
 * 商品状態抽出（検証付き）
 */
function extractConditionWithValidation($html, &$errors) {
    $condition_patterns = [
        '/商品の状態[\s\S]*?(新品|未使用|未開封|目立った傷や汚れなし|やや傷や汚れあり|傷や汚れあり|全体的に状態が悪い|ジャンク)/u',
        '/状態[\s\S]*?(新品|未使用|未開封|良好|普通|やや難あり|難あり|ジャンク)/u'
    ];
    
    foreach ($condition_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $condition_text = $matches[1];
            
            // 標準化されたコンディション
            $condition_mapping = [
                '新品' => 'New',
                '未使用' => 'New',
                '未開封' => 'New',
                '目立った傷や汚れなし' => 'Excellent',
                'やや傷や汚れあり' => 'Good',
                '傷や汚れあり' => 'Fair',
                '全体的に状態が悪い' => 'Poor',
                'ジャンク' => 'For Parts',
                '良好' => 'Good',
                '普通' => 'Fair',
                'やや難あり' => 'Fair',
                '難あり' => 'Poor'
            ];
            
            $condition = $condition_mapping[$condition_text] ?? 'Used';
            writeLog("✅ [商品状態取得] {$condition_text} -> {$condition}", 'SUCCESS');
            return $condition;
        }
    }
    
    writeLog("⚠️ [商品状態デフォルト] Used", 'WARNING');
    return 'Used';
}

/**
 * 出品者情報抽出（検証付き）
 */
function extractSellerWithValidation($html, &$errors) {
    $seller_patterns = [
        '/出品者[\s\S]*?<a[^>]*>([^<]+)<\/a>/u',
        '/seller[^>]*>[\s\S]*?<a[^>]*>([^<]+)<\/a>/i',
        '/>([^<]+)さん</u'
    ];
    
    foreach ($seller_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $seller_name = trim($matches[1]);
            if (strlen($seller_name) > 0 && strlen($seller_name) < 50) {
                writeLog("✅ [出品者取得] {$seller_name}", 'SUCCESS');
                return [
                    'name' => $seller_name,
                    'rating' => 'N/A'
                ];
            }
        }
    }
    
    writeLog("⚠️ [出品者デフォルト] Unknown", 'WARNING');
    return [
        'name' => 'Unknown',
        'rating' => 'N/A'
    ];
}

/**
 * オークション情報抽出（検証付き）
 */
function extractAuctionInfoWithValidation($html, &$errors) {
    // 入札数抽出
    $bid_count = 0;
    $bid_patterns = [
        '/入札[\s\S]*?(\d+)[\s\S]*?件/u',
        '/(\d+)[\s\S]*?入札/u'
    ];
    
    foreach ($bid_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $bid_count = (int)$matches[1];
            if ($bid_count >= 0 && $bid_count < 10000) {
                writeLog("✅ [入札数取得] {$bid_count}件", 'SUCCESS');
                break;
            }
        }
    }
    
    // 終了時間抽出
    $end_time = date('Y-m-d H:i:s', strtotime('+7 days'));
    $end_time_patterns = [
        '/(\d{1,2})月(\d{1,2})日[^0-9]*(\d{1,2})時(\d{1,2})分[^0-9]*終了/u',
        '/終了時間[\s\S]*?(\d{4})年(\d{1,2})月(\d{1,2})日\s*(\d{1,2})時(\d{1,2})分/u'
    ];
    
    foreach ($end_time_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            if (count($matches) >= 5) {
                $year = isset($matches[5]) ? $matches[1] : date('Y');
                $month = isset($matches[5]) ? $matches[2] : $matches[1];
                $day = isset($matches[5]) ? $matches[3] : $matches[2];
                $hour = isset($matches[5]) ? $matches[4] : $matches[3];
                $minute = isset($matches[5]) ? $matches[5] : $matches[4];
                
                $end_time = sprintf('%04d-%02d-%02d %02d:%02d:00', 
                    $year, $month, $day, $hour, $minute);
                writeLog("✅ [終了時間取得] {$end_time}", 'SUCCESS');
                break;
            }
        }
    }
    
    return [
        'end_time' => $end_time,
        'bid_count' => $bid_count
    ];
}

/**
 * スクレイピングデータの検証
 */
function validateScrapedData($data, $errors, &$warnings) {
    $critical_errors = [];
    $quality_score = 100;
    
    // タイトル検証
    if (empty($data['title'])) {
        $critical_errors[] = 'タイトルが取得できていません';
        $quality_score -= 30;
    }
    
    // 価格検証
    if (empty($data['price_data']['current_price']) && empty($data['price_data']['immediate_price'])) {
        $critical_errors[] = '価格情報が取得できていません';
        $quality_score -= 40;
    }
    
    // 画像検証
    if (empty($data['images'])) {
        $warnings[] = '商品画像が取得できていません';
        $quality_score -= 20;
    }
    
    // カテゴリ検証
    if (empty($data['category'])) {
        $warnings[] = 'カテゴリ情報が取得できていません';
        $quality_score -= 10;
    }
    
    $is_valid = empty($critical_errors);
    
    return [
        'is_valid' => $is_valid,
        'quality_score' => max(0, $quality_score),
        'critical_errors' => $critical_errors,
        'warnings' => $warnings
    ];
}

echo "✅ Enhanced Yahoo Auction Parser V2025 読み込み完了\n";
?>
