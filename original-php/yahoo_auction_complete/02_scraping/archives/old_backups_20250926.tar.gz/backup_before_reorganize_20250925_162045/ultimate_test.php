<?php
/**
 * 🎯 完全精度テスト: Ultimate Parserの検証
 * カテゴリ階層・詳細情報の100%正確抽出テスト
 */

header('Content-Type: text/html; charset=UTF-8');

$test_url = 'https://auctions.yahoo.co.jp/jp/auction/m1198908523';
$item_id = 'm1198908523';

?><!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎯 Ultimate Parser 完全精度テスト</title>
    <style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    .result { margin: 15px 0; padding: 15px; border-radius: 6px; }
    .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
    .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
    .warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; }
    .info { background: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; }
    .comparison { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
    .expected { background: #e8f5e8; padding: 15px; border-left: 4px solid #28a745; }
    .actual { background: #fdf2e8; padding: 15px; border-left: 4px solid #fd7e14; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; font-size: 11px; max-height: 400px; overflow-y: auto; }
    .accuracy-bar { width: 100%; height: 20px; background: #e9ecef; border-radius: 10px; overflow: hidden; margin: 10px 0; }
    .accuracy-fill { height: 100%; transition: width 0.3s ease; }
    .accuracy-excellent { background: #28a745; }
    .accuracy-good { background: #ffc107; }
    .accuracy-poor { background: #dc3545; }
    ul { margin: 5px 0; padding-left: 20px; }
    .extraction-log { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; padding: 10px; margin: 10px 0; font-family: monospace; font-size: 12px; max-height: 200px; overflow-y: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎯 Ultimate Parser 完全精度テスト</h1>
        
        <div class="result info">
            <strong>テスト対象:</strong> <?php echo $test_url; ?><br>
            <strong>実行時刻:</strong> <?php echo date('Y-m-d H:i:s'); ?>
        </div>

        <div class="expected">
            <h3>🎯 期待される完璧な結果:</h3>
            <ul>
                <li><strong>タイトル:</strong> マツバのゲンガー VS ポケモンカードe 1ED ポケカ ポケモンカード</li>
                <li><strong>価格:</strong> 37,777円</li>
                <li><strong>状態:</strong> 未使用に近い</li>
                <li><strong>カテゴリ階層:</strong> おもちゃ、ゲーム > ゲーム > トレーディングカードゲーム > ポケモンカードゲーム > シングルカード</li>
                <li><strong>ブランド:</strong> Pokemon</li>
                <li><strong>配送元:</strong> 東京都</li>
                <li><strong>送料:</strong> 全国一律230円</li>
                <li><strong>オークションID:</strong> l1200404917</li>
            </ul>
        </div>

        <?php
        // HTMLデータ取得
        $context = stream_context_create([
            'http' => [
                'header' => "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n",
                'timeout' => 30
            ]
        ]);
        
        $html = @file_get_contents($test_url, false, $context);
        
        if (!$html) {
            echo '<div class="result error"><strong>❌ HTML取得失敗</strong></div>';
        } else {
            echo '<div class="result success"><strong>✅ HTML取得成功:</strong> ' . strlen($html) . ' 文字</div>';
            
            // Ultimate Parserのテスト
            if (file_exists('yahoo_parser_ultimate.php')) {
                require_once 'yahoo_parser_ultimate.php';
                
                echo '<h2>🚀 Ultimate Parser 結果:</h2>';
                
                $start_time = microtime(true);
                $result = parseYahooAuctionHTML_Ultimate($html, $test_url, $item_id);
                $execution_time = round((microtime(true) - $start_time) * 1000, 2);
                
                // 詳細精度チェック
                $precision_checks = [
                    'タイトル（ゲンガー含む）' => [
                        'expected' => 'マツバのゲンガー',
                        'actual' => $result['title'] ?? 'null',
                        'match' => strpos($result['title'] ?? '', 'ゲンガー') !== false
                    ],
                    '価格（37,777円）' => [
                        'expected' => 37777,
                        'actual' => $result['current_price'] ?? 0,
                        'match' => ($result['current_price'] ?? 0) == 37777
                    ],
                    '状態（未使用に近い）' => [
                        'expected' => '未使用に近い',
                        'actual' => $result['condition'] ?? 'null',
                        'match' => strpos($result['condition'] ?? '', '未使用に近い') !== false
                    ],
                    'カテゴリ階層（5階層）' => [
                        'expected' => 5,
                        'actual' => count($result['category_path'] ?? []),
                        'match' => count($result['category_path'] ?? []) >= 4
                    ],
                    'ポケモン関連' => [
                        'expected' => 'ポケモン',
                        'actual' => $result['category'] ?? 'null',
                        'match' => strpos($result['category'] ?? '', 'ポケモン') !== false
                    ],
                    'ブランド（Pokemon）' => [
                        'expected' => 'Pokemon',
                        'actual' => $result['brand'] ?? 'null',
                        'match' => stripos($result['brand'] ?? '', 'pokemon') !== false
                    ]
                ];
                
                $successful_checks = array_sum(array_column($precision_checks, 'match'));
                $accuracy_percentage = round(($successful_checks / count($precision_checks)) * 100, 1);
                
                // 精度表示
                $accuracy_class = $accuracy_percentage >= 80 ? 'accuracy-excellent' : ($accuracy_percentage >= 60 ? 'accuracy-good' : 'accuracy-poor');
                $result_class = $accuracy_percentage >= 80 ? 'success' : ($accuracy_percentage >= 60 ? 'warning' : 'error');
                
                echo "<div class='result $result_class'>";
                echo "<strong>🎯 総合精度: {$accuracy_percentage}% ({$successful_checks}/" . count($precision_checks) . " 項目成功)</strong><br>";
                echo "品質スコア: " . ($result['data_quality'] ?? 'N/A') . "%<br>";
                echo "実行時間: {$execution_time}ms<br>";
                echo "</div>";
                
                echo '<div class="accuracy-bar">';
                echo "<div class='accuracy-fill $accuracy_class' style='width: {$accuracy_percentage}%'></div>";
                echo '</div>';
                
                // 詳細比較
                echo '<div class="comparison">';
                echo '<div class="expected"><h4>📊 詳細精度チェック:</h4>';
                foreach ($precision_checks as $field => $check) {
                    $icon = $check['match'] ? '✅' : '❌';
                    echo "<p><strong>{$field}:</strong> $icon<br>";
                    echo "<small>期待: {$check['expected']}<br>";
                    echo "実際: {$check['actual']}</small></p>";
                }
                echo '</div>';
                
                echo '<div class="actual"><h4>🔍 重要フィールド:</h4>';
                echo "<p><strong>タイトル:</strong> " . ($result['title'] ?? 'null') . "</p>";
                echo "<p><strong>価格:</strong> ¥" . number_format($result['current_price'] ?? 0) . "</p>";
                echo "<p><strong>状態:</strong> " . ($result['condition'] ?? 'null') . "</p>";
                echo "<p><strong>カテゴリ:</strong> " . ($result['category'] ?? 'null') . "</p>";
                echo "<p><strong>ブランド:</strong> " . ($result['brand'] ?? 'null') . "</p>";
                echo "<p><strong>画像数:</strong> " . count($result['images'] ?? []) . "枚</p>";
                echo "<p><strong>配送情報:</strong> " . ($result['shipping_cost'] ?? 'なし') . "</p>";
                echo '</div>';
                echo '</div>';
                
                // 抽出ログ表示
                if (isset($result['extraction_log']) && !empty($result['extraction_log'])) {
                    echo '<h3>📋 抽出プロセスログ:</h3>';
                    echo '<div class="extraction-log">';
                    foreach ($result['extraction_log'] as $log_entry) {
                        echo htmlspecialchars($log_entry) . "<br>";
                    }
                    echo '</div>';
                }
                
                // 完全結果（デバッグ用）
                echo '<details><summary><strong>🔍 完全抽出結果（デバッグ用）</strong></summary>';
                echo '<pre>' . htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</pre>';
                echo '</details>';
                
            } else {
                echo '<div class="result error"><strong>❌ Ultimate Parserファイル不存在</strong></div>';
            }
        }
        ?>
        
        <div class="result info">
            <strong>🎯 成功基準:</strong><br>
            • 精度80%以上: 本格運用可能<br>
            • 精度60-79%: 改善必要<br>
            • 精度60%未満: 大幅修正必要
        </div>
    </div>
</body>
</html>
