<?php
/**
 * 画像データ流失問題調査ツール
 * スクレイピング→データベース保存の全プロセスを追跡
 */

echo "<h1>🔍 画像データ流失問題調査ツール</h1>";
echo "<p style='color: #e74c3c; font-weight: bold;'>問題: 15枚取得 → 1枚しか保存されない原因を特定</p>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. 最新スクレイピングデータの完全解析
    echo "<h2>1. 🕷️ 最新スクレイピングデータの完全解析</h2>";
    
    $latestSql = "SELECT id, source_item_id, active_title, active_image_url, scraped_yahoo_data, created_at, updated_at
                  FROM yahoo_scraped_products 
                  ORDER BY updated_at DESC 
                  LIMIT 1";
    
    $latestStmt = $pdo->query($latestSql);
    $latestData = $latestStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($latestData) {
        echo "<div style='border: 2px solid #007bff; padding: 20px; border-radius: 8px; background: #f8f9fa;'>";
        echo "<h3 style='color: #007bff;'>📊 最新レコード詳細分析</h3>";
        echo "<p><strong>ID:</strong> {$latestData['id']}</p>";
        echo "<p><strong>source_item_id:</strong> {$latestData['source_item_id']}</p>";
        echo "<p><strong>タイトル:</strong> " . htmlspecialchars($latestData['active_title']) . "</p>";
        echo "<p><strong>作成:</strong> {$latestData['created_at']}</p>";
        echo "<p><strong>更新:</strong> {$latestData['updated_at']}</p>";
        
        // active_image_url 分析
        echo "<h4 style='color: #e74c3c;'>📸 active_image_url 分析:</h4>";
        if ($latestData['active_image_url']) {
            echo "<div style='background: #e8f5e8; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
            echo "<p style='color: green;'><strong>✅ active_image_url あり:</strong></p>";
            echo "<p style='word-break: break-all; font-size: 0.9em;'>" . htmlspecialchars($latestData['active_image_url']) . "</p>";
            echo "<img src='{$latestData['active_image_url']}' style='max-width: 200px; max-height: 150px; border: 1px solid #ddd; border-radius: 4px; margin: 10px 0;' alt='active_image' loading='lazy'>";
            echo "</div>";
        } else {
            echo "<div style='background: #ffe6e6; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
            echo "<p style='color: red;'><strong>❌ active_image_url なし（NULL）</strong></p>";
            echo "</div>";
        }
        
        // scraped_yahoo_data 詳細分析
        echo "<h4 style='color: #9b59b6;'>📊 scraped_yahoo_data 詳細分析:</h4>";
        if ($latestData['scraped_yahoo_data']) {
            try {
                $scrapedData = json_decode($latestData['scraped_yahoo_data'], true);
                if ($scrapedData) {
                    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 4px; margin: 10px 0;'>";
                    echo "<p style='color: green; font-weight: bold;'>✅ scraped_yahoo_data あり (" . strlen($latestData['scraped_yahoo_data']) . " 文字)</p>";
                    
                    // 画像関連データの詳細確認
                    $imageDataFound = false;
                    
                    // all_images チェック
                    if (isset($scrapedData['all_images'])) {
                        $imageDataFound = true;
                        echo "<h5 style='color: #28a745; margin: 15px 0 10px 0;'>🖼️ all_images 分析:</h5>";
                        
                        if (is_array($scrapedData['all_images'])) {
                            $imageCount = count($scrapedData['all_images']);
                            echo "<p><strong>画像数:</strong> <span style='color: " . ($imageCount >= 10 ? 'green' : ($imageCount >= 5 ? 'orange' : 'red')) . "; font-weight: bold; font-size: 1.2em;'>{$imageCount}枚</span></p>";
                            
                            if ($imageCount > 0) {
                                echo "<div style='margin: 15px 0;'>";
                                echo "<h6 style='margin: 10px 0;'>📋 全画像URL一覧:</h6>";
                                echo "<div style='max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 4px; background: white;'>";
                                
                                foreach ($scrapedData['all_images'] as $index => $imgUrl) {
                                    $urlLength = strlen($imgUrl);
                                    $isValidUrl = filter_var($imgUrl, FILTER_VALIDATE_URL);
                                    $statusColor = $isValidUrl ? 'green' : 'red';
                                    $statusIcon = $isValidUrl ? '✅' : '❌';
                                    
                                    echo "<div style='margin: 8px 0; padding: 8px; border: 1px solid #eee; border-radius: 3px; background: #f9f9f9;'>";
                                    echo "<p style='margin: 0; font-size: 0.9em;'>";
                                    echo "<strong>画像" . ($index + 1) . ":</strong> ";
                                    echo "<span style='color: {$statusColor};'>{$statusIcon}</span> ";
                                    echo "<span style='color: #666; font-size: 0.8em;'>({$urlLength}文字)</span>";
                                    echo "</p>";
                                    echo "<p style='margin: 5px 0 0 0; word-break: break-all; font-size: 0.8em; color: #333;'>";
                                    echo htmlspecialchars(substr($imgUrl, 0, 100));
                                    if (strlen($imgUrl) > 100) echo "...";
                                    echo "</p>";
                                    
                                    if ($isValidUrl) {
                                        echo "<img src='{$imgUrl}' style='max-width: 80px; max-height: 60px; border: 1px solid #ddd; border-radius: 3px; margin: 5px 0;' alt='画像" . ($index + 1) . "' loading='lazy' onerror='this.style.display=\"none\"'>";
                                    }
                                    echo "</div>";
                                }
                                echo "</div>";
                                
                                // 画像データの統計
                                $validImages = array_filter($scrapedData['all_images'], function($img) {
                                    return filter_var($img, FILTER_VALIDATE_URL);
                                });
                                
                                echo "<div style='background: #f0f8ff; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
                                echo "<h6 style='margin: 0 0 5px 0; color: #007bff;'>📊 画像データ統計:</h6>";
                                echo "<p style='margin: 2px 0;'>総画像数: {$imageCount}枚</p>";
                                echo "<p style='margin: 2px 0;'>有効URL: " . count($validImages) . "枚</p>";
                                echo "<p style='margin: 2px 0;'>無効URL: " . ($imageCount - count($validImages)) . "枚</p>";
                                echo "</div>";
                                
                            } else {
                                echo "<p style='color: red;'>❌ all_images は空の配列です</p>";
                            }
                        } else {
                            echo "<p style='color: orange;'>⚠️ all_images は配列ではありません: " . gettype($scrapedData['all_images']) . "</p>";
                            echo "<pre style='background: #fff3cd; padding: 10px; border-radius: 4px; font-size: 0.8em;'>";
                            echo htmlspecialchars(print_r($scrapedData['all_images'], true));
                            echo "</pre>";
                        }
                    }
                    
                    // images チェック
                    if (isset($scrapedData['images'])) {
                        $imageDataFound = true;
                        echo "<h5 style='color: #28a745; margin: 15px 0 10px 0;'>🖼️ images 分析:</h5>";
                        
                        if (is_array($scrapedData['images'])) {
                            echo "<p><strong>images 配列:</strong> " . count($scrapedData['images']) . "枚</p>";
                        } else {
                            echo "<p style='color: orange;'>⚠️ images は配列ではありません: " . gettype($scrapedData['images']) . "</p>";
                        }
                    }
                    
                    // validation_info.image チェック
                    if (isset($scrapedData['validation_info']['image'])) {
                        $imageDataFound = true;
                        echo "<h5 style='color: #28a745; margin: 15px 0 10px 0;'>🖼️ validation_info.image 分析:</h5>";
                        $imageValidation = $scrapedData['validation_info']['image'];
                        
                        if (isset($imageValidation['all_images'])) {
                            echo "<p><strong>validation all_images:</strong> " . (is_array($imageValidation['all_images']) ? count($imageValidation['all_images']) . "枚" : gettype($imageValidation['all_images'])) . "</p>";
                        }
                        
                        echo "<p><strong>画像検証結果:</strong></p>";
                        echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 0.8em;'>";
                        echo htmlspecialchars(json_encode($imageValidation, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                        echo "</pre>";
                    }
                    
                    if (!$imageDataFound) {
                        echo "<div style='background: #ffe6e6; padding: 15px; border-radius: 4px; margin: 15px 0;'>";
                        echo "<h5 style='color: #dc3545; margin: 0 0 10px 0;'>🚨 重大問題発見</h5>";
                        echo "<p style='color: #dc3545; font-weight: bold;'>scraped_yahoo_data 内に画像関連データが一切見つかりません！</p>";
                        echo "<p>これは以下のいずれかを意味します：</p>";
                        echo "<ul>";
                        echo "<li>スクレイピング時に画像データが取得されていない</li>";
                        echo "<li>データベース保存時に画像データが除外されている</li>";
                        echo "<li>保存プロセスでJSONエンコード時に画像データが失われている</li>";
                        echo "</ul>";
                        echo "</div>";
                        
                        // JSON構造の全体表示
                        echo "<h6 style='color: #dc3545;'>🔍 実際のJSON構造（画像データなし）:</h6>";
                        echo "<details>";
                        echo "<summary style='cursor: pointer; color: #666;'>JSON全体を表示（クリックで展開）</summary>";
                        echo "<pre style='background: #f8f9fa; padding: 15px; border-radius: 4px; font-size: 10px; max-height: 400px; overflow-y: auto; margin: 10px 0;'>";
                        echo htmlspecialchars(json_encode($scrapedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                        echo "</pre>";
                        echo "</details>";
                    }
                    
                    echo "</div>";
                } else {
                    echo "<div style='background: #ffe6e6; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
                    echo "<p style='color: red;'><strong>❌ JSON解析失敗</strong></p>";
                    echo "<p>JSON Error: " . json_last_error_msg() . "</p>";
                    echo "</div>";
                }
            } catch (Exception $e) {
                echo "<div style='background: #ffe6e6; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
                echo "<p style='color: red;'><strong>❌ JSON解析例外:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
                echo "</div>";
            }
        } else {
            echo "<div style='background: #ffe6e6; padding: 15px; border-radius: 4px; margin: 10px 0;'>";
            echo "<h5 style='color: #dc3545; margin: 0 0 10px 0;'>🚨 致命的問題発見</h5>";
            echo "<p style='color: red; font-weight: bold;'>scraped_yahoo_data が完全にNULLです！</p>";
            echo "<p>これは以下を意味します：</p>";
            echo "<ul>";
            echo "<li>スクレイピング処理が完全に失敗している</li>";
            echo "<li>または、データベース保存処理で致命的エラーが発生している</li>";
            echo "<li>15枚の画像データは一切データベースに到達していない</li>";
            echo "</ul>";
            echo "</div>";
        }
        
        echo "</div>";
    } else {
        echo "<div style='color: red; padding: 15px; background: #ffe6e6; border-radius: 4px;'>";
        echo "❌ データベースにデータが見つかりません";
        echo "</div>";
    }
    
    // 2. スクレイピング処理の検証
    echo "<h2>2. 🕷️ スクレイピング処理の検証</h2>";
    
    echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 4px; margin: 15px 0;'>";
    echo "<h4>🔍 画像データ流失箇所の特定:</h4>";
    echo "<p>以下の箇所で画像データが失われている可能性があります：</p>";
    
    echo "<div style='margin: 15px 0;'>";
    echo "<h5 style='color: #dc3545;'>❌ 可能性1: スクレイピング段階での失敗</h5>";
    echo "<ul>";
    echo "<li>Yahoo Parser が15枚の画像を正しく抽出できていない</li>";
    echo "<li>パーサー関数の戻り値で images 配列が空になっている</li>";
    echo "<li>HTML解析の段階で画像URLが見つからない</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='margin: 15px 0;'>";
    echo "<h5 style='color: #dc3545;'>❌ 可能性2: データベース保存段階での失敗</h5>";
    echo "<ul>";
    echo "<li>database_save_hybrid.php で \$product_data['images'] が空</li>";
    echo "<li>validateAndProcessImages() で画像データが除外されている</li>";
    echo "<li>JSONエンコード時に画像データが失われている</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<div style='margin: 15px 0;'>";
    echo "<h5 style='color: #dc3545;'>❌ 可能性3: データ受け渡し段階での失敗</h5>";
    echo "<ul>";
    echo "<li>scraping.php から database_save_hybrid.php への受け渡し時に画像データが欠落</li>";
    echo "<li>パーサー関数の戻り値形式と保存関数の期待形式の不一致</li>";
    echo "</ul>";
    echo "</div>";
    echo "</div>";
    
    // 3. 緊急検証テスト
    echo "<h2>3. 🧪 緊急検証テスト</h2>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 4px; margin: 15px 0;'>";
    echo "<h4>🔧 次の調査アクション:</h4>";
    echo "<ol>";
    echo "<li><strong>パーサー出力の直接確認</strong> - Emergency Parser が実際に15枚の画像を返しているか</li>";
    echo "<li><strong>保存関数入力の確認</strong> - database_save_hybrid.php に渡される \$product_data['images'] の内容</li>";
    echo "<li><strong>JSON保存の確認</strong> - all_images がJSONに正しく含まれているか</li>";
    echo "<li><strong>再スクレイピングでのリアルタイム追跡</strong> - 各段階でのデータ流失箇所の特定</li>";
    echo "</ol>";
    echo "</div>";
    
    // 4. 手動検証用URL
    echo "<h2>4. 🔗 手動検証リンク</h2>";
    
    echo "<div style='text-align: center; margin: 20px 0;'>";
    echo "<a href='../02_scraping/scraping.php' style='background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 10px; display: inline-block; font-weight: bold;'>🕷️ 再スクレイピング実行</a>";
    echo "<a href='yahoo_parser_emergency.php' style='background: #dc3545; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 10px; display: inline-block; font-weight: bold;'>🚨 Emergency Parser 直接テスト</a>";
    echo "<a href='database_save_hybrid.php' style='background: #007bff; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 10px; display: inline-block; font-weight: bold;'>🏦 保存関数テスト</a>";
    echo "</div>";
    
    // 5. ログ確認
    echo "<h2>5. 📋 スクレイピングログ確認</h2>";
    
    $logFile = __DIR__ . '/scraping_logs.txt';
    if (file_exists($logFile)) {
        $logs = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $recentLogs = array_slice(array_reverse($logs), 0, 20); // 最新20件
        
        echo "<div style='background: #1a1a1a; color: #e5e7eb; padding: 15px; border-radius: 4px; font-family: monospace; font-size: 0.8em; max-height: 400px; overflow-y: auto;'>";
        echo "<h5 style='color: #ffffff; margin: 0 0 10px 0;'>📋 最新スクレイピングログ:</h5>";
        
        foreach ($recentLogs as $log) {
            $logColor = '#e5e7eb';
            if (strpos($log, 'ERROR') !== false) $logColor = '#ef4444';
            elseif (strpos($log, 'SUCCESS') !== false) $logColor = '#22c55e';
            elseif (strpos($log, 'WARNING') !== false) $logColor = '#f59e0b';
            elseif (strpos($log, 'INFO') !== false) $logColor = '#3b82f6';
            
            echo "<div style='color: {$logColor}; margin: 2px 0;'>" . htmlspecialchars($log) . "</div>";
        }
        echo "</div>";
    } else {
        echo "<div style='color: orange; padding: 10px; background: #fff3cd; border-radius: 4px;'>";
        echo "⚠️ スクレイピングログファイルが見つかりません: {$logFile}";
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo "<hr>";
echo "<div style='background: #e8f5e8; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<h3 style='color: #28a745; margin: 0 0 15px 0;'>🎯 結論と次のアクション</h3>";
echo "<div style='font-size: 1.1em; line-height: 1.6;'>";
echo "<p><strong>問題:</strong> スクレイピングで15枚取得 → データベースに1枚しか保存されない</p>";
echo "<p><strong>原因:</strong> 上記の調査結果に基づいて特定してください</p>";
echo "<p><strong>解決:</strong> 原因箇所を修正後、再スクレイピングで確認</p>";
echo "</div>";
echo "</div>";
?>
