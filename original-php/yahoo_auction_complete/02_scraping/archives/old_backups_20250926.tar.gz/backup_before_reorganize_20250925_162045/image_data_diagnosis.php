<?php
/**
 * 画像データ詳細診断ツール
 * データベース内の画像データ状況を完全調査
 */

echo "<h1>🖼️ 画像データ詳細診断ツール</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. 最新5件のデータを詳細調査
    echo "<h2>1. 🔍 最新5件の画像データ詳細調査</h2>";
    
    $detailSql = "SELECT id, source_item_id, active_title, 
                         active_image_url,
                         picture_url,
                         (scraped_yahoo_data)::text as scraped_data_text,
                         LENGTH((scraped_yahoo_data)::text) as data_length,
                         created_at, updated_at
                  FROM yahoo_scraped_products 
                  ORDER BY updated_at DESC 
                  LIMIT 5";
    
    $detailStmt = $pdo->query($detailSql);
    $detailData = $detailStmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($detailData as $row) {
        echo "<div style='border: 1px solid #ddd; margin: 15px 0; padding: 15px; border-radius: 8px; background: #f9f9f9;'>";
        echo "<h3 style='color: #2c3e50; margin: 0 0 10px 0;'>商品ID: {$row['source_item_id']}</h3>";
        echo "<p><strong>タイトル:</strong> " . substr($row['active_title'], 0, 60) . "...</p>";
        
        // active_image_url チェック
        echo "<h4 style='color: #e74c3c;'>📸 active_image_url:</h4>";
        if ($row['active_image_url']) {
            echo "<p style='color: green;'>✅ データあり: " . substr($row['active_image_url'], 0, 80) . "...</p>";
            echo "<img src='{$row['active_image_url']}' style='max-width: 150px; max-height: 100px; border: 1px solid #ddd; margin: 5px;' alt='active_image' loading='lazy'>";
        } else {
            echo "<p style='color: red;'>❌ active_image_url がNULL</p>";
        }
        
        // picture_url チェック
        echo "<h4 style='color: #3498db;'>📷 picture_url:</h4>";
        if ($row['picture_url']) {
            echo "<p style='color: green;'>✅ データあり: " . substr($row['picture_url'], 0, 80) . "...</p>";
            echo "<img src='{$row['picture_url']}' style='max-width: 150px; max-height: 100px; border: 1px solid #ddd; margin: 5px;' alt='picture_url' loading='lazy'>";
        } else {
            echo "<p style='color: red;'>❌ picture_url がNULL</p>";
        }
        
        // scraped_yahoo_data 詳細解析
        echo "<h4 style='color: #9b59b6;'>📊 scraped_yahoo_data 解析:</h4>";
        echo "<p><strong>データサイズ:</strong> {$row['data_length']} 文字</p>";
        
        if ($row['scraped_data_text']) {
            try {
                $scrapedData = json_decode($row['scraped_data_text'], true);
                
                // 画像関連データを探索
                $imageFields = [];
                
                if (isset($scrapedData['all_images'])) {
                    $imageFields['all_images'] = $scrapedData['all_images'];
                }
                
                if (isset($scrapedData['images'])) {
                    $imageFields['images'] = $scrapedData['images'];
                }
                
                if (isset($scrapedData['extraction_results']['images'])) {
                    $imageFields['extraction_results.images'] = $scrapedData['extraction_results']['images'];
                }
                
                if (isset($scrapedData['validation_info']['image']['all_images'])) {
                    $imageFields['validation_info.image.all_images'] = $scrapedData['validation_info']['image']['all_images'];
                }
                
                // 画像データの表示
                if (!empty($imageFields)) {
                    echo "<div style='background: #e8f5e8; padding: 10px; border-radius: 4px;'>";
                    echo "<p style='color: green; font-weight: bold;'>✅ 画像データ発見:</p>";
                    
                    foreach ($imageFields as $fieldName => $images) {
                        echo "<h5 style='color: #27ae60;'>{$fieldName}:</h5>";
                        
                        if (is_array($images)) {
                            echo "<p>配列 - {count($images)}件</p>";
                            echo "<div style='display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 5px; margin: 10px 0;'>";
                            
                            foreach (array_slice($images, 0, 10) as $index => $img) {
                                if (is_string($img) && strlen($img) > 10) {
                                    echo "<div style='text-align: center;'>";
                                    echo "<img src='{$img}' style='max-width: 80px; max-height: 60px; border: 1px solid #ddd; border-radius: 3px;' alt='画像{$index}' loading='lazy' onerror='this.style.display=\"none\"'>";
                                    echo "<div style='font-size: 8px; color: #666;'>画像" . ($index + 1) . "</div>";
                                    echo "</div>";
                                }
                            }
                            
                            if (count($images) > 10) {
                                echo "<div style='text-align: center; color: #666; font-size: 10px;'>+". (count($images) - 10) ."件</div>";
                            }
                            
                            echo "</div>";
                            
                        } else {
                            echo "<p>非配列データ: " . gettype($images) . " - " . substr(print_r($images, true), 0, 100) . "</p>";
                        }
                    }
                    echo "</div>";
                    
                } else {
                    echo "<p style='color: red;'>❌ scraped_yahoo_data内に画像データなし</p>";
                    
                    // データ構造を表示（デバッグ用）
                    echo "<details style='margin: 10px 0;'>";
                    echo "<summary style='cursor: pointer; color: #666;'>📋 データ構造確認（クリックで展開）</summary>";
                    echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 10px; max-height: 200px; overflow-y: auto;'>";
                    echo htmlspecialchars(json_encode($scrapedData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    echo "</pre>";
                    echo "</details>";
                }
                
            } catch (Exception $e) {
                echo "<p style='color: red;'>❌ JSON解析エラー: " . $e->getMessage() . "</p>";
            }
        } else {
            echo "<p style='color: red;'>❌ scraped_yahoo_data がNULL</p>";
        }
        
        echo "<hr style='margin: 15px 0;'>";
        echo "<p style='font-size: 0.8em; color: #666;'><strong>作成:</strong> {$row['created_at']} | <strong>更新:</strong> {$row['updated_at']}</p>";
        echo "</div>";
    }
    
    // 2. 統計情報
    echo "<h2>2. 📊 画像データ統計情報</h2>";
    
    $statsSql = "SELECT 
                    COUNT(*) as total_records,
                    COUNT(active_image_url) as has_active_image,
                    COUNT(picture_url) as has_picture_url,
                    COUNT(CASE WHEN scraped_yahoo_data IS NOT NULL THEN 1 END) as has_scraped_data,
                    COUNT(CASE WHEN LENGTH((scraped_yahoo_data)::text) > 100 THEN 1 END) as has_substantial_data
                 FROM yahoo_scraped_products";
    
    $statsStmt = $pdo->query($statsSql);
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>項目</th><th>件数</th><th>割合</th></tr>";
    echo "<tr><td>総レコード数</td><td>{$stats['total_records']}</td><td>100%</td></tr>";
    echo "<tr><td>active_image_url あり</td><td>{$stats['has_active_image']}</td><td>" . round($stats['has_active_image'] / $stats['total_records'] * 100, 1) . "%</td></tr>";
    echo "<tr><td>picture_url あり</td><td>{$stats['has_picture_url']}</td><td>" . round($stats['has_picture_url'] / $stats['total_records'] * 100, 1) . "%</td></tr>";
    echo "<tr><td>scraped_yahoo_data あり</td><td>{$stats['has_scraped_data']}</td><td>" . round($stats['has_scraped_data'] / $stats['total_records'] * 100, 1) . "%</td></tr>";
    echo "<tr><td>実質的なデータあり</td><td>{$stats['has_substantial_data']}</td><td>" . round($stats['has_substantial_data'] / $stats['total_records'] * 100, 1) . "%</td></tr>";
    echo "</table>";
    
    // 3. 画像表示テスト用JavaScript生成
    echo "<h2>3. 🧪 画像表示テスト用JavaScript</h2>";
    
    $testProductSql = "SELECT id, source_item_id, active_title, active_image_url, picture_url, scraped_yahoo_data
                       FROM yahoo_scraped_products 
                       ORDER BY updated_at DESC 
                       LIMIT 1";
    
    $testStmt = $pdo->query($testProductSql);
    $testProduct = $testStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($testProduct) {
        echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 8px;'>";
        echo "<h4>テスト対象商品: {$testProduct['active_title']}</h4>";
        echo "<button onclick='testImageExtraction()' style='background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;'>画像抽出テスト実行</button>";
        echo "<div id='testResult' style='margin-top: 15px; border: 1px solid #ddd; padding: 10px; border-radius: 4px; background: white;'></div>";
        
        echo "<script>";
        echo "const testProduct = " . json_encode($testProduct) . ";";
        echo "
        function testImageExtraction() {
            const resultDiv = document.getElementById('testResult');
            resultDiv.innerHTML = '<p>🔄 画像抽出テスト実行中...</p>';
            
            let images = [];
            let debugInfo = [];
            
            try {
                // 1. active_image_url
                if (testProduct.active_image_url && !testProduct.active_image_url.includes('placehold')) {
                    images.push(testProduct.active_image_url);
                    debugInfo.push('✅ active_image_url: ' + testProduct.active_image_url.substring(0, 50) + '...');
                } else {
                    debugInfo.push('❌ active_image_url: なし または placeholder');
                }
                
                // 2. picture_url
                if (testProduct.picture_url && !testProduct.picture_url.includes('placehold')) {
                    images.push(testProduct.picture_url);
                    debugInfo.push('✅ picture_url: ' + testProduct.picture_url.substring(0, 50) + '...');
                } else {
                    debugInfo.push('❌ picture_url: なし または placeholder');
                }
                
                // 3. scraped_yahoo_data
                if (testProduct.scraped_yahoo_data) {
                    const scrapedData = typeof testProduct.scraped_yahoo_data === 'string' 
                        ? JSON.parse(testProduct.scraped_yahoo_data) 
                        : testProduct.scraped_yahoo_data;
                    
                    debugInfo.push('📊 scraped_yahoo_data 解析:');
                    
                    // all_images
                    if (scrapedData.all_images && Array.isArray(scrapedData.all_images)) {
                        images = images.concat(scrapedData.all_images);
                        debugInfo.push('  ✅ all_images: ' + scrapedData.all_images.length + '件');
                    } else {
                        debugInfo.push('  ❌ all_images: なし');
                    }
                    
                    // images
                    if (scrapedData.images && Array.isArray(scrapedData.images)) {
                        images = images.concat(scrapedData.images);
                        debugInfo.push('  ✅ images: ' + scrapedData.images.length + '件');
                    } else {
                        debugInfo.push('  ❌ images: なし');
                    }
                    
                    // extraction_results.images
                    if (scrapedData.extraction_results && scrapedData.extraction_results.images) {
                        if (Array.isArray(scrapedData.extraction_results.images)) {
                            images = images.concat(scrapedData.extraction_results.images);
                            debugInfo.push('  ✅ extraction_results.images: ' + scrapedData.extraction_results.images.length + '件');
                        }
                    } else {
                        debugInfo.push('  ❌ extraction_results.images: なし');
                    }
                    
                } else {
                    debugInfo.push('❌ scraped_yahoo_data: なし');
                }
                
                // 重複除去
                images = [...new Set(images)].filter(img => 
                    img && 
                    typeof img === 'string' && 
                    img.length > 10 && 
                    !img.includes('placehold') &&
                    (img.startsWith('http') || img.startsWith('//'))
                );
                
                // 結果表示
                let resultHtml = '<div>';
                resultHtml += '<h4>🔍 画像抽出結果: ' + images.length + '枚発見</h4>';
                
                // デバッグ情報
                resultHtml += '<div style=\"background: #f8f9fa; padding: 10px; border-radius: 4px; margin: 10px 0;\">';
                resultHtml += '<h5>📋 抽出ログ:</h5>';
                resultHtml += '<ul style=\"margin: 0; padding-left: 20px;\">';
                debugInfo.forEach(info => {
                    resultHtml += '<li style=\"font-size: 0.9em; margin: 2px 0;\">' + info + '</li>';
                });
                resultHtml += '</ul>';
                resultHtml += '</div>';
                
                // 画像プレビュー
                if (images.length > 0) {
                    resultHtml += '<h5>🖼️ 画像プレビュー:</h5>';
                    resultHtml += '<div style=\"display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 8px;\">';
                    
                    images.forEach((img, index) => {
                        resultHtml += '<div style=\"border: 1px solid #ddd; padding: 3px; border-radius: 4px; text-align: center;\">';
                        resultHtml += '<img src=\"' + img + '\" style=\"max-width: 100%; height: 80px; object-fit: cover; border-radius: 3px;\" alt=\"画像' + (index + 1) + '\" loading=\"lazy\" onerror=\"this.style.display=\\'none\\'\">';
                        resultHtml += '<div style=\"font-size: 8px; color: #666; margin-top: 2px;\">画像' + (index + 1) + '</div>';
                        resultHtml += '</div>';
                    });
                    
                    resultHtml += '</div>';
                } else {
                    resultHtml += '<p style=\"color: red;\">❌ 有効な画像が見つかりませんでした</p>';
                }
                
                resultHtml += '</div>';
                
                resultDiv.innerHTML = resultHtml;
                
            } catch (error) {
                resultDiv.innerHTML = '<p style=\"color: red;\">❌ エラー: ' + error.message + '</p>';
            }
        }
        ";
        echo "</script>";
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p style='text-align: center;'>";
echo "<a href='../05_editing/editing.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>📝 editing.phpで確認</a>";
echo "<a href='duplicate_image_fix.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>🔧 重複修正ツール</a>";
echo "</p>";
?>
