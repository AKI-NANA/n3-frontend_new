<?php
/**
 * オークション形式判定のデバッグ専用関数
 */

/**
 * オークション形式判定の詳細デバッグ
 */
function debugAuctionTypeDetection($html, $url) {
    try {
        writeLog("🐛 [DEBUG] オークション形式判定の詳細デバッグを開始", 'DEBUG');
        
        // DOMDocument初期化
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_use_internal_errors(false);
        
        $xpath = new DOMXPath($dom);
        
        // === デバッグ情報収集 ===
        
        // 1. 価格関連要素の詳細チェック
        writeLog("💰 [DEBUG] 価格関連要素の詳細チェック", 'DEBUG');
        
        $priceElements = $xpath->query('//dt[contains(text(), "現在")] | //dt[contains(text(), "即決")] | //dt[contains(text(), "価格")]');
        foreach ($priceElements as $element) {
            $text = trim($element->textContent);
            $nextElement = $xpath->query('following-sibling::dd', $element);
            $nextText = $nextElement->length > 0 ? trim($nextElement->item(0)->textContent) : '要素なし';
            writeLog("  📋 価格要素: '{$text}' -> '{$nextText}'", 'DEBUG');
        }
        
        // 2. 入札関連要素の詳細チェック
        writeLog("🎯 [DEBUG] 入札関連要素の詳細チェック", 'DEBUG');
        
        $bidElements = $xpath->query('//*[contains(text(), "入札")]');
        foreach ($bidElements as $element) {
            $text = trim($element->textContent);
            $tagName = $element->tagName;
            writeLog("  🎯 入札要素: <{$tagName}> '{$text}'", 'DEBUG');
            
            // 隣接要素をチェック
            $siblings = $xpath->query('following-sibling::* | ../td[position() > 1]', $element);
            foreach ($siblings as $sibling) {
                $siblingText = trim($sibling->textContent);
                if (!empty($siblingText) && strlen($siblingText) < 50) {
                    writeLog("    -> 隣接要素: '{$siblingText}'", 'DEBUG');
                    break;
                }
            }
        }
        
        // 3. オークション詳細テーブルの解析
        writeLog("📊 [DEBUG] オークション詳細テーブルの解析", 'DEBUG');
        
        $tableElements = $xpath->query('//table//th');
        foreach ($tableElements as $th) {
            $thText = trim($th->textContent);
            $tdElement = $xpath->query('following-sibling::td', $th);
            $tdText = $tdElement->length > 0 ? trim($tdElement->item(0)->textContent) : 'N/A';
            
            if (preg_match('/(入札|終了|延長|開始|価格)/', $thText)) {
                writeLog("  📊 テーブル: '{$thText}' = '{$tdText}'", 'DEBUG');
            }
        }
        
        // 4. 「即決」関連テキストの検索
        writeLog("💎 [DEBUG] 即決関連テキストの詳細検索", 'DEBUG');
        
        $buyNowElements = $xpath->query('//*[contains(text(), "即決")]');
        foreach ($buyNowElements as $element) {
            $text = trim($element->textContent);
            $tagName = $element->tagName;
            writeLog("  💎 即決テキスト: <{$tagName}> '{$text}'", 'DEBUG');
        }
        
        // 5. 時間関連の要素検索
        writeLog("⏰ [DEBUG] 時間関連要素の詳細検索", 'DEBUG');
        
        $timeElements = $xpath->query('//*[contains(text(), "時間") or contains(text(), "終了") or contains(text(), "日時")]');
        foreach ($timeElements as $element) {
            $text = trim($element->textContent);
            $tagName = $element->tagName;
            if (strlen($text) < 100) { // 長すぎるテキストは除外
                writeLog("  ⏰ 時間要素: <{$tagName}> '{$text}'", 'DEBUG');
            }
        }
        
        // 6. 全体的なページ構造の分析
        writeLog("🏗️ [DEBUG] ページ構造の概要分析", 'DEBUG');
        
        // オークションIDの確認
        $auctionIdElements = $xpath->query('//*[contains(text(), "オークションID") or contains(text(), "auction")]');
        foreach ($auctionIdElements as $element) {
            $text = trim($element->textContent);
            if (strlen($text) < 50) {
                writeLog("  🆔 オークションID関連: '{$text}'", 'DEBUG');
            }
        }
        
        // ページタイトルの確認
        $titleElements = $xpath->query('//title | //h1');
        foreach ($titleElements as $element) {
            $text = trim($element->textContent);
            if (!empty($text)) {
                writeLog("  📰 タイトル要素: '{$text}'", 'DEBUG');
                break;
            }
        }
        
        writeLog("🐛 [DEBUG] オークション形式判定デバッグ完了", 'DEBUG');
        
        return true;
        
    } catch (Exception $e) {
        writeLog("❌ [DEBUG ERROR] デバッグ中にエラー: " . $e->getMessage(), 'ERROR');
        return false;
    }
}

/**
 * 特定の要素のXPathと値をリスト表示
 */
function debugElementsByXPath($xpath, $xpathQuery, $description) {
    try {
        writeLog("🔍 [DEBUG] {$description} の検索: {$xpathQuery}", 'DEBUG');
        
        $elements = $xpath->query($xpathQuery);
        
        if ($elements->length > 0) {
            for ($i = 0; $i < min($elements->length, 5); $i++) { // 最大5個まで表示
                $element = $elements->item($i);
                $text = trim($element->textContent);
                $tagName = $element->tagName;
                $truncatedText = mb_substr($text, 0, 100, 'UTF-8');
                writeLog("  [{$i}] <{$tagName}>: '{$truncatedText}'", 'DEBUG');
            }
            
            if ($elements->length > 5) {
                writeLog("  ... さらに" . ($elements->length - 5) . "個の要素があります", 'DEBUG');
            }
        } else {
            writeLog("  要素が見つかりませんでした", 'DEBUG');
        }
        
        return $elements->length;
        
    } catch (Exception $e) {
        writeLog("❌ [DEBUG ERROR] XPath検索エラー: " . $e->getMessage(), 'ERROR');
        return 0;
    }
}

echo "✅ Auction Type Debug Functions 読み込み完了\n";
?>
