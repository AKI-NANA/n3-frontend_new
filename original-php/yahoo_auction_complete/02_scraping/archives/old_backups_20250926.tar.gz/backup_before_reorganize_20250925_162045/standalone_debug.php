<?php
/**
 * Yahoo オークション スタンドアロン診断ツール
 * Geminiに渡すための詳細診断データを生成
 */

header('Content-Type: text/html; charset=UTF-8');
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h1>🔍 Yahoo オークション スタンドアロン診断ツール</h1>\n";
echo "<pre>\n";

$test_url = "https://auctions.yahoo.co.jp/jp/auction/l1200404917";
$item_id = "l1200404917";

echo "📋 [診断開始] URL: {$test_url}\n";
echo "================================================================================\n\n";

try {
    // 1. HTML取得
    echo "📡 [1. HTML取得テスト]\n";
    echo "----------------------------------------\n";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $test_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language: ja,en-US;q=0.7,en;q=0.3',
        'Connection: keep-alive',
        'Upgrade-Insecure-Requests: 1',
    ]);
    curl_setopt($ch, CURLOPT_ENCODING, ''); // 自動でgzip/deflateを処理
    
    $html_content = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    if ($curl_error) {
        echo "❌ CURL エラー: {$curl_error}\n";
        exit;
    }
    
    if ($http_code !== 200) {
        echo "❌ HTTP エラー: {$http_code}\n";
        exit;
    }
    
    if (!$html_content) {
        echo "❌ HTML取得失敗\n";
        exit;
    }
    
    echo "✅ HTML取得成功: " . strlen($html_content) . "文字\n";
    echo "   HTTP Code: {$http_code}\n\n";
    
    // 2. DOM解析
    echo "🏗️ [2. DOM解析テスト]\n";
    echo "----------------------------------------\n";
    
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $success = $dom->loadHTML('<?xml encoding="UTF-8">' . $html_content);
    libxml_use_internal_errors(false);
    
    if (!$success) {
        echo "❌ DOM解析失敗\n";
        exit;
    }
    
    $xpath = new DOMXPath($dom);
    echo "✅ DOM解析成功\n\n";
    
    // 3. JSON抽出テスト
    echo "📊 [3. JSON抽出テスト]\n";
    echo "----------------------------------------\n";
    
    // 方法1: __NEXT_DATA__を含むscriptタグ
    $script_nodes = $xpath->query('//script[contains(text(), "__NEXT_DATA__")]');
    echo "方法1 (__NEXT_DATA__): スクリプトタグ数 = {$script_nodes->length}\n";
    
    $json_data_method1 = null;
    if ($script_nodes->length > 0) {
        $script_content = $script_nodes->item(0)->nodeValue;
        if (preg_match('/__NEXT_DATA__"\s*=\s*({.*?})(?:\s*<\/script>|$)/s', $script_content, $matches)) {
            $data_json = $matches[1];
            $json_data_method1 = json_decode($data_json, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                echo "✅ 方法1成功: " . strlen($data_json) . "文字のJSONデータ\n";
            } else {
                echo "❌ 方法1 JSONデコード失敗: " . json_last_error_msg() . "\n";
            }
        } else {
            echo "❌ 方法1 正規表現マッチ失敗\n";
        }
    } else {
        echo "❌ 方法1 __NEXT_DATA__を含むscriptタグが見つかりません\n";
    }
    
    // 方法2: initialStateを含むscriptタグ
    $script_nodes = $xpath->query('//script[contains(text(), "initialState")]');
    echo "方法2 (initialState): スクリプトタグ数 = {$script_nodes->length}\n";
    
    $json_data_method2 = null;
    if ($script_nodes->length > 0) {
        $script_content = $script_nodes->item(0)->nodeValue;
        if (preg_match('/"initialState":\s*({.*?})/', $script_content, $matches)) {
            $data_json = $matches[1];
            $json_data_method2 = json_decode($data_json, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                echo "✅ 方法2成功: " . strlen($data_json) . "文字のJSONデータ\n";
            } else {
                echo "❌ 方法2 JSONデコード失敗: " . json_last_error_msg() . "\n";
            }
        } else {
            echo "❌ 方法2 正規表現マッチ失敗\n";
        }
    } else {
        echo "❌ 方法2 initialStateを含むscriptタグが見つかりません\n";
    }
    
    // 最適なJSONデータを選択
    $json_data = $json_data_method1 ?: $json_data_method2;
    echo "\n";
    
    // 4. HTML要素検査
    echo "🎯 [4. HTML要素検査]\n";
    echo "----------------------------------------\n";
    
    // タイトル検査
    $title_node = $xpath->query('//div[@id="itemTitle"]//h1')->item(0);
    $title = $title_node ? trim($title_node->nodeValue) : null;
    echo "タイトル: " . ($title ? "✅ '{$title}'" : "❌ 取得失敗") . "\n";
    
    // 価格検査
    $price_node = $xpath->query('//dt[text()="即決"]/following-sibling::dd[1]//span')->item(0);
    $price_text = $price_node ? trim($price_node->nodeValue) : null;
    $price = $price_text ? (int)str_replace(['円', ',', ' '], '', $price_text) : null;
    echo "価格: " . ($price ? "✅ ¥{$price}" : "❌ 取得失敗") . "\n";
    
    // 商品状態検査
    $condition_node = $xpath->query('//li[svg[@aria-label="状態"]]//span')->item(0);
    $condition_japanese = $condition_node ? trim($condition_node->nodeValue) : null;
    echo "商品状態: " . ($condition_japanese ? "✅ '{$condition_japanese}'" : "❌ 取得失敗") . "\n";
    
    // カテゴリ検査
    $category_nodes = $xpath->query('//dt[text()="カテゴリ"]/following-sibling::dd[1]//a');
    $category_path = [];
    foreach ($category_nodes as $node) {
        $category_path[] = trim($node->nodeValue);
    }
    $category = end($category_path);
    echo "カテゴリ: " . ($category ? "✅ '{$category}'" : "❌ 取得失敗") . "\n";
    
    // オークション判定
    $current_price_dt = $xpath->query('//dt[text()="現在"]');
    $immediate_price_dt = $xpath->query('//dt[text()="即決"]');
    $buy_now_button = $xpath->query('//button[contains(text(), "今すぐ落札")]');
    
    echo "\nオークション判定:\n";
    echo "  現在価格dt: {$current_price_dt->length}個\n";
    echo "  即決価格dt: {$immediate_price_dt->length}個\n"; 
    echo "  今すぐ落札ボタン: {$buy_now_button->length}個\n";
    
    $is_auction = !($current_price_dt->length === 0 && $immediate_price_dt->length > 0 && $buy_now_button->length > 0);
    echo "  判定結果: " . ($is_auction ? "❌ オークション" : "✅ 定額出品") . "\n";
    
    // 5. JSONデータ詳細検査
    if ($json_data) {
        echo "\n📋 [5. JSONデータ詳細]\n";
        echo "----------------------------------------\n";
        
        if (isset($json_data['item']['detail']['item'])) {
            $item = $json_data['item']['detail']['item'];
            
            echo "JSON内のデータ:\n";
            echo "  title: " . (isset($item['title']) ? "✅ '{$item['title']}'" : "❌ なし") . "\n";
            echo "  bidorbuy: " . (isset($item['bidorbuy']) ? "✅ {$item['bidorbuy']}" : "❌ なし") . "\n";
            echo "  price: " . (isset($item['price']) ? "✅ {$item['price']}" : "❌ なし") . "\n";
            echo "  conditionName: " . (isset($item['conditionName']) ? "✅ '{$item['conditionName']}'" : "❌ なし") . "\n";
            echo "  category.path: " . (isset($item['category']['path']) ? "✅ あり" : "❌ なし") . "\n";
        } else {
            echo "❌ JSONデータ内にitem.detail.itemが見つかりません\n";
        }
    } else {
        echo "\n📋 [5. JSONデータなし]\n";
        echo "----------------------------------------\n";
        echo "❌ JSONデータの抽出に完全に失敗しました\n";
    }
    
    // 6. HTMLサンプル出力
    echo "\n📝 [6. HTMLサンプル（最初の1000文字）]\n";
    echo "----------------------------------------\n";
    echo substr($html_content, 0, 1000) . "...\n";
    
    // 7. 診断結果サマリー
    echo "\n📊 [7. 診断結果サマリー]\n";
    echo "----------------------------------------\n";
    
    $extracted_fields = [
        'title' => $title,
        'price' => $price,
        'condition' => $condition_japanese,
        'category' => $category
    ];
    
    $success_count = 0;
    foreach ($extracted_fields as $field => $value) {
        $status = $value ? '✅ 成功' : '❌ 失敗';
        echo "{$field}: {$status}\n";
        if ($value) $success_count++;
    }
    
    echo "\n成功率: {$success_count}/4 フィールド (" . round(($success_count/4)*100) . "%)\n";
    echo "JSON抽出: " . ($json_data ? '✅ 成功' : '❌ 失敗') . "\n";
    echo "オークション判定: " . ($is_auction ? '❌ オークション（処理中断）' : '✅ 定額出品（処理継続）') . "\n";
    
} catch (Exception $e) {
    echo "❌ [例外発生] " . $e->getMessage() . "\n";
    echo "   ファイル: " . $e->getFile() . "\n";
    echo "   行番号: " . $e->getLine() . "\n";
}

echo "\n================================================================================\n";
echo "📋 [診断完了] 上記の詳細データをGeminiに送信して分析を依頼してください\n";
echo "</pre>\n";
?>
