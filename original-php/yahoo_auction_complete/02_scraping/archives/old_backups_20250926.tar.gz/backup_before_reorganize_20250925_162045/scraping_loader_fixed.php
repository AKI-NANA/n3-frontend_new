
// ジェミナイ分析対応修正版パーサーを読み込み
if (file_exists(__DIR__ . '/yahoo_parser_fixed_v2.php')) {
    require_once __DIR__ . '/yahoo_parser_fixed_v2.php';
}

// 修正版統合システムを読み込み
if (file_exists(__DIR__ . '/scraping_integration_fixed.php')) {
    require_once __DIR__ . '/scraping_integration_fixed.php';
}
