<?php
/**
 * ジェミナイ分析対応修正版パーサーのテストスクリプト
 * 実際のYahoo!オークションURLでテスト実行
 */

// 修正版パーサーを読み込み
require_once 'yahoo_parser_fixed_v2.php';

// テスト用URL（ジェミナイ分析で検証済みURL）
$test_urls = [
    'https://auctions.yahoo.co.jp/jp/auction/m1198908523', // ポケモンカード
    'https://auctions.yahoo.co.jp/jp/auction/j1200085520', // 別のテスト商品
];

echo "🚀 ジェミナイ分析対応修正版パーサー テスト開始\n";
echo "==========================================\n\n";

foreach ($test_urls as $index => $url) {
    echo "📝 テスト " . ($index + 1) . ": $url\n";
    echo "----------------------------------------\n";
    
    // HTMLを取得
    $context = stream_context_create([
        'http' => [
            'header' => "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n",
            'timeout' => 30
        ]
    ]);
    
    $html = @file_get_contents($url, false, $context);
    
    if (!$html) {
        echo "❌ HTML取得失敗\n\n";
        continue;
    }
    
    // 商品IDを抽出
    preg_match('/auction\/([^\/\?]+)/', $url, $matches);
    $item_id = $matches[1] ?? 'unknown';
    
    // パーサー実行
    $start_time = microtime(true);
    $result = parseYahooAuctionHTML_Fixed($html, $url, $item_id);
    $execution_time = round((microtime(true) - $start_time) * 1000, 2);
    
    if ($result) {
        echo "✅ 解析成功 (実行時間: {$execution_time}ms)\n";
        echo "📊 データ品質スコア: {$result['data_quality']}%\n";
        echo "🏷️  タイトル: " . substr($result['title'] ?? 'N/A', 0, 50) . "\n";
        echo "💰 価格: " . number_format($result['current_price']) . "円\n";
        echo "📦 状態: " . ($result['condition'] ?? 'N/A') . "\n";
        echo "📂 カテゴリ: " . substr($result['category'] ?? 'N/A', 0, 40) . "\n";
        echo "🖼️  画像数: " . count($result['images']) . "枚\n";
        echo "👤 出品者: " . ($result['seller_info']['name'] ?? 'N/A') . "\n";
        echo "🔨 入札数: " . ($result['auction_info']['bid_count'] ?? 0) . "件\n";
        echo "⚙️  抽出方法: " . ($result['scraping_method'] ?? 'N/A') . "\n";
        
        // 詳細データ表示（デバッグ用）
        if (isset($_GET['debug'])) {
            echo "\n🔍 詳細データ:\n";
            echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        }
        
    } else {
        echo "❌ 解析失敗\n";
    }
    
    echo "\n";
}

// ログファイル内容表示
echo "📋 解析ログ (最新10行):\n";
echo "==========================================\n";
$log_file = __DIR__ . '/scraping_logs.txt';
if (file_exists($log_file)) {
    $logs = file($log_file);
    $recent_logs = array_slice($logs, -10);
    echo implode('', $recent_logs);
} else {
    echo "ログファイルが見つかりません。\n";
}

echo "\n🎯 テスト完了！\n";
echo "詳細ログを確認するには: tail -f scraping_logs.txt\n";
echo "詳細データを表示するには: ?debug=1 を付けてアクセス\n";
?>
