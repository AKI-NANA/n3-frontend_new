<?php
/**
 * Emergency Parser 出力確認ツール
 * 15枚画像取得 → 1枚保存の問題を追跡
 */

// Emergency Parser を読み込み
if (file_exists(__DIR__ . '/yahoo_parser_emergency.php')) {
    require_once __DIR__ . '/yahoo_parser_emergency.php';
} else {
    die("❌ Emergency Parser が見つかりません");
}

// データベース保存関数を読み込み
if (file_exists(__DIR__ . '/database_save_hybrid.php')) {
    require_once __DIR__ . '/database_save_hybrid.php';
} else {
    die("❌ データベース保存関数が見つかりません");
}

// ログ関数
function writeLog($message, $type = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    echo "<div style='font-family: monospace; font-size: 0.8em; margin: 2px 0; color: " . 
         ($type === 'ERROR' ? '#dc3545' : ($type === 'SUCCESS' ? '#28a745' : '#6c757d')) . 
         ";'>[{$timestamp}] [{$type}] {$message}</div>";
}

echo "<h1>🚨 Emergency Parser 出力確認ツール</h1>";
echo "<p style='color: #e74c3c; font-weight: bold;'>目的: 15枚画像取得 → 1枚保存の問題原因を特定</p>";

// テスト対象URL（ゲンガー）
$test_url = "https://auctions.yahoo.co.jp/jp/auction/l1200404917";
$item_id = "l1200404917";

echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 15px 0;'>";
echo "<h3>🎯 テスト対象</h3>";
echo "<p><strong>URL:</strong> <a href='{$test_url}' target='_blank'>{$test_url}</a></p>";
echo "<p><strong>Item ID:</strong> {$item_id}</p>";
echo "<p><strong>商品:</strong> マツバのゲンガー VS ポケモンカード</p>";
echo "</div>";

// HTMLを取得
echo "<h2>📥 ステップ1: HTML取得</h2>";
$html_content = null;

try {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $test_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);
    
    $html_content = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($html_content && $http_code === 200) {
        $html_size = strlen($html_content);
        echo "<div style='color: green; padding: 10px; background: #e8f5e8; border-radius: 4px;'>";
        echo "✅ HTML取得成功: " . number_format($html_size) . " 文字";
        echo "</div>";
        writeLog("HTML取得成功: {$html_size} 文字", 'SUCCESS');
    } else {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
        echo "❌ HTML取得失敗: HTTP Code {$http_code}";
        echo "</div>";
        die("HTML取得に失敗しました");
    }
} catch (Exception $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
    echo "❌ HTML取得例外: " . $e->getMessage();
    echo "</div>";
    die("HTML取得でエラーが発生しました");
}

// Emergency Parser で解析
echo "<h2>🚨 ステップ2: Emergency Parser 解析</h2>";

if (function_exists('parseYahooAuctionHTML_Fixed_Emergency')) {
    writeLog("Emergency Parser 関数発見", 'SUCCESS');
    
    echo "<div style='background: #fff3cd; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
    echo "⚠️ Emergency Parser 解析開始...";
    echo "</div>";
    
    try {
        $start_time = microtime(true);
        $parser_result = parseYahooAuctionHTML_Fixed_Emergency($html_content, $test_url, $item_id);
        $parse_time = round((microtime(true) - $start_time) * 1000, 2);
        
        writeLog("Emergency Parser 解析完了: {$parse_time}ms", 'SUCCESS');
        
        if ($parser_result && is_array($parser_result)) {
            echo "<div style='color: green; padding: 10px; background: #e8f5e8; border-radius: 4px;'>";
            echo "✅ Emergency Parser 解析成功";
            echo "</div>";
            
            // パーサー結果の詳細分析
            echo "<h3>📊 パーサー結果詳細分析</h3>";
            
            echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 15px 0;'>";
            echo "<h4>🔍 基本情報:</h4>";
            echo "<p><strong>タイトル:</strong> " . htmlspecialchars($parser_result['title'] ?? 'N/A') . "</p>";
            echo "<p><strong>価格:</strong> ¥" . number_format($parser_result['current_price'] ?? 0) . "</p>";
            echo "<p><strong>状態:</strong> " . htmlspecialchars($parser_result['condition'] ?? 'N/A') . "</p>";
            echo "<p><strong>品質スコア:</strong> " . ($parser_result['data_quality'] ?? 'N/A') . "%</p>";
            echo "</div>";
            
            // 🖼️ 画像データの詳細分析
            echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 8px; margin: 15px 0; border: 2px solid #28a745;'>";
            echo "<h4 style='color: #28a745;'>🖼️ 重要: 画像データ詳細分析</h4>";
            
            if (isset($parser_result['images'])) {
                if (is_array($parser_result['images'])) {
                    $image_count = count($parser_result['images']);
                    echo "<div style='background: white; padding: 15px; border-radius: 4px; margin: 10px 0;'>";
                    echo "<h5 style='color: " . ($image_count >= 10 ? '#28a745' : ($image_count >= 5 ? '#f59e0b' : '#dc3545')) . "; margin: 0 0 10px 0;'>";
                    echo "📊 パーサー出力画像数: <span style='font-size: 1.5em;'>{$image_count}枚</span>";
                    echo "</h5>";
                    
                    if ($image_count > 0) {
                        echo "<h6>📋 取得された画像URL一覧:</h6>";
                        echo "<div style='max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 4px;'>";
                        
                        foreach ($parser_result['images'] as $index => $img_url) {
                            $is_valid = filter_var($img_url, FILTER_VALIDATE_URL);
                            $status_icon = $is_valid ? '✅' : '❌';
                            $status_color = $is_valid ? 'green' : 'red';
                            
                            echo "<div style='margin: 8px 0; padding: 8px; border: 1px solid #eee; border-radius: 3px;'>";
                            echo "<p style='margin: 0; font-size: 0.9em;'>";
                            echo "<strong>画像" . ($index + 1) . ":</strong> ";
                            echo "<span style='color: {$status_color};'>{$status_icon}</span>";
                            echo "</p>";
                            echo "<p style='margin: 5px 0 0 0; word-break: break-all; font-size: 0.8em; color: #666;'>";
                            echo htmlspecialchars($img_url);
                            echo "</p>";
                            
                            if ($is_valid) {
                                echo "<img src='{$img_url}' style='max-width: 100px; max-height: 80px; border: 1px solid #ddd; border-radius: 3px; margin: 5px 0;' alt='画像" . ($index + 1) . "' loading='lazy' onerror='this.style.display=\"none\"'>";
                            }
                            echo "</div>";
                        }
                        echo "</div>";
                        
                        // 画像データ統計
                        $valid_images = array_filter($parser_result['images'], function($img) {
                            return filter_var($img, FILTER_VALIDATE_URL);
                        });
                        
                        echo "<div style='background: #f0f8ff; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
                        echo "<h6 style='margin: 0 0 5px 0;'>📊 画像統計:</h6>";
                        echo "<p style='margin: 2px 0;'>総数: {$image_count}枚</p>";
                        echo "<p style='margin: 2px 0;'>有効: " . count($valid_images) . "枚</p>";
                        echo "<p style='margin: 2px 0;'>無効: " . ($image_count - count($valid_images)) . "枚</p>";
                        echo "</div>";
                        
                        if ($image_count >= 10) {
                            echo "<div style='background: #d4edda; padding: 10px; border-radius: 4px; color: #155724;'>";
                            echo "🎉 <strong>Emergency Parser は15枚の画像を正常に取得しています！</strong>";
                            echo "</div>";
                        } else {
                            echo "<div style='background: #f8d7da; padding: 10px; border-radius: 4px; color: #721c24;'>";
                            echo "⚠️ <strong>Emergency Parser の画像取得数が少ないです。HTML解析に問題がある可能性があります。</strong>";
                            echo "</div>";
                        }
                        
                    } else {
                        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 4px; color: #721c24;'>";
                        echo "❌ <strong>Emergency Parser が画像を1枚も取得していません</strong>";
                        echo "</div>";
                    }
                    echo "</div>";
                } else {
                    echo "<div style='background: #f8d7da; padding: 10px; border-radius: 4px; color: #721c24;'>";
                    echo "❌ images フィールドが配列ではありません: " . gettype($parser_result['images']);
                    echo "</div>";
                }
            } else {
                echo "<div style='background: #f8d7da; padding: 10px; border-radius: 4px; color: #721c24;'>";
                echo "❌ <strong>Emergency Parser の出力に images フィールドがありません</strong>";
                echo "</div>";
            }
            echo "</div>";
            
            // パーサー出力の完全ダンプ
            echo "<details style='margin: 20px 0;'>";
            echo "<summary style='cursor: pointer; padding: 10px; background: #f8f9fa; border-radius: 4px; font-weight: bold;'>🔍 Emergency Parser 完全出力（クリックで展開）</summary>";
            echo "<pre style='background: #1a1a1a; color: #e5e7eb; padding: 15px; border-radius: 4px; overflow-x: auto; font-size: 0.8em; max-height: 500px; overflow-y: auto; margin: 10px 0;'>";
            echo htmlspecialchars(json_encode($parser_result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            echo "</pre>";
            echo "</details>";
            
        } else {
            echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
            echo "❌ Emergency Parser 解析失敗";
            echo "</div>";
            writeLog("Emergency Parser 解析失敗", 'ERROR');
        }
        
    } catch (Exception $e) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
        echo "❌ Emergency Parser 例外: " . $e->getMessage();
        echo "</div>";
        writeLog("Emergency Parser 例外: " . $e->getMessage(), 'ERROR');
    }
} else {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
    echo "❌ Emergency Parser 関数が見つかりません";
    echo "</div>";
    die("Emergency Parser が利用できません");
}

// データベース保存テスト
if (isset($parser_result) && $parser_result) {
    echo "<h2>🏦 ステップ3: データベース保存テスト</h2>";
    
    echo "<div style='background: #fff3cd; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
    echo "⚠️ データベース保存開始...";
    echo "</div>";
    
    try {
        writeLog("データベース保存関数呼び出し開始", 'INFO');
        $save_result = saveProductToDatabaseHybrid($parser_result);
        
        if ($save_result && isset($save_result['success']) && $save_result['success']) {
            echo "<div style='color: green; padding: 10px; background: #e8f5e8; border-radius: 4px;'>";
            echo "✅ データベース保存成功";
            echo "</div>";
            writeLog("データベース保存成功", 'SUCCESS');
            
            // 保存結果の確認
            echo "<h3>💾 保存確認</h3>";
            echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 8px;'>";
            echo "<p><strong>保存ID:</strong> " . ($save_result['id'] ?? 'N/A') . "</p>";
            echo "<p><strong>アクション:</strong> " . ($save_result['action'] ?? 'N/A') . "</p>";
            echo "<p><strong>価格:</strong> ¥" . number_format($save_result['price_jpy'] ?? 0) . "</p>";
            echo "</div>";
            
        } else {
            echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
            echo "❌ データベース保存失敗: " . ($save_result['error'] ?? 'Unknown error');
            echo "</div>";
            writeLog("データベース保存失敗: " . ($save_result['error'] ?? 'Unknown error'), 'ERROR');
        }
        
    } catch (Exception $e) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
        echo "❌ データベース保存例外: " . $e->getMessage();
        echo "</div>";
        writeLog("データベース保存例外: " . $e->getMessage(), 'ERROR');
    }
}

// 結論
echo "<h2>🎯 結論と診断</h2>";

echo "<div style='background: #e8f5e8; padding: 20px; border-radius: 8px; margin: 20px 0; border: 2px solid #28a745;'>";
echo "<h3 style='color: #28a745; margin: 0 0 15px 0;'>📋 診断結果</h3>";

if (isset($parser_result) && isset($parser_result['images']) && is_array($parser_result['images'])) {
    $parser_image_count = count($parser_result['images']);
    
    echo "<div style='margin: 15px 0;'>";
    echo "<h4 style='color: #dc3545;'>🔍 画像データ流失追跡結果:</h4>";
    echo "<p><strong>Emergency Parser 出力:</strong> {$parser_image_count}枚</p>";
    echo "<p><strong>データベース保存済み:</strong> 1枚（実際の確認が必要）</p>";
    
    if ($parser_image_count >= 10) {
        echo "<div style='background: #d4edda; padding: 10px; border-radius: 4px; color: #155724; margin: 10px 0;'>";
        echo "✅ <strong>Emergency Parser は正常に画像を取得しています</strong>";
        echo "<p>問題は Emergency Parser → データベース保存 の間で発生しています。</p>";
        echo "</div>";
        
        echo "<h4 style='color: #dc3545;'>🚨 推定原因:</h4>";
        echo "<ul>";
        echo "<li><strong>データベース保存関数</strong>での画像データ処理エラー</li>";
        echo "<li><strong>validateAndProcessImages()</strong> で画像が除外されている</li>";
        echo "<li><strong>JSONエンコード</strong>時の画像データ損失</li>";
        echo "<li><strong>database_save_hybrid.php</strong> の \$product_data['images'] 受け渡しエラー</li>";
        echo "</ul>";
        
    } else {
        echo "<div style='background: #f8d7da; padding: 10px; border-radius: 4px; color: #721c24; margin: 10px 0;'>";
        echo "❌ <strong>Emergency Parser の画像取得が不完全です</strong>";
        echo "<p>問題は Emergency Parser の HTML解析段階で発生しています。</p>";
        echo "</div>";
        
        echo "<h4 style='color: #dc3545;'>🚨 推定原因:</h4>";
        echo "<ul>";
        echo "<li><strong>Yahoo の HTML構造変更</strong>で画像セレクターが無効化</li>";
        echo "<li><strong>Emergency Parser</strong> の画像抽出ロジックの不具合</li>";
        echo "<li><strong>JavaScript動的読み込み</strong>で画像URLが取得できない</li>";
        echo "</ul>";
    }
} else {
    echo "<div style='background: #f8d7da; padding: 10px; border-radius: 4px; color: #721c24;'>";
    echo "❌ <strong>Emergency Parser が完全に失敗しています</strong>";
    echo "</div>";
}

echo "</div>";

echo "<div style='text-align: center; margin: 30px 0;'>";
echo "<a href='image_loss_investigation.php' style='background: #007bff; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 10px; display: inline-block; font-weight: bold;'>🔍 詳細調査ツール</a>";
echo "<a href='../05_editing/editing.php' style='background: #28a745; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; margin: 10px; display: inline-block; font-weight: bold;'>📝 editing.php確認</a>";
echo "</div>";
?>
