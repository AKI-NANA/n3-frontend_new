<?php
/**
 * 画像データ保存状況詳細調査ツール
 * スクレイピング→データベース保存の流れを完全検証
 */

echo "<h1>🔍 画像データ保存状況詳細調査ツール</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. テーブル構造の正確な確認
    echo "<h2>1. 📊 正確なテーブル構造</h2>";
    
    $schemaSql = "SELECT column_name, data_type, is_nullable 
                  FROM information_schema.columns 
                  WHERE table_name = 'yahoo_scraped_products' 
                  AND table_schema = 'public'
                  ORDER BY ordinal_position";
    
    $schemaStmt = $pdo->query($schemaSql);
    $columns = $schemaStmt->fetchAll(PDO::FETCH_ASSOC);
    
    $imageColumns = [];
    echo "<div style='background: #f8f9fa; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
    echo "<h4>📋 全カラム一覧:</h4>";
    echo "<div style='columns: 3; font-family: monospace; font-size: 0.8em;'>";
    
    foreach ($columns as $column) {
        $colName = $column['column_name'];
        $isImageRelated = (strpos($colName, 'image') !== false || 
                          strpos($colName, 'picture') !== false ||
                          $colName === 'scraped_yahoo_data');
        
        if ($isImageRelated) {
            echo "<div style='color: red; font-weight: bold;'>🖼️ {$colName}</div>";
            $imageColumns[] = $colName;
        } else {
            echo "<div>{$colName}</div>";
        }
    }
    echo "</div>";
    echo "<div style='margin-top: 10px; padding: 5px; background: #fff3cd; border-radius: 3px;'>";
    echo "<strong>🖼️ 画像関連カラム:</strong> " . implode(', ', $imageColumns);
    echo "</div>";
    echo "</div>";
    
    // 2. 最新レコードの詳細データ解析
    echo "<h2>2. 🔬 最新レコードの詳細データ解析</h2>";
    
    // 画像カラムのみを選択
    $imageColsStr = implode(', ', $imageColumns);
    
    $detailSql = "SELECT id, source_item_id, active_title, created_at, updated_at, {$imageColsStr}
                  FROM yahoo_scraped_products 
                  ORDER BY updated_at DESC 
                  LIMIT 3";
    
    $detailStmt = $pdo->query($detailSql);
    $detailData = $detailStmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($detailData as $index => $row) {
        echo "<div style='border: 2px solid #007bff; margin: 20px 0; padding: 20px; border-radius: 8px; background: #f9f9f9;'>";
        echo "<h3 style='color: #007bff; margin: 0 0 15px 0;'>📊 レコード " . ($index + 1) . ": {$row['source_item_id']}</h3>";
        echo "<p><strong>タイトル:</strong> " . htmlspecialchars($row['active_title']) . "</p>";
        echo "<p><strong>作成:</strong> {$row['created_at']} | <strong>更新:</strong> {$row['updated_at']}</p>";
        
        foreach ($imageColumns as $imageCol) {
            echo "<div style='margin: 15px 0; padding: 10px; border: 1px solid #ddd; border-radius: 4px; background: white;'>";
            echo "<h4 style='color: #e74c3c; margin: 0 0 10px 0;'>📸 {$imageCol}</h4>";
            
            if ($imageCol === 'scraped_yahoo_data') {
                // scraped_yahoo_dataの詳細解析
                if ($row[$imageCol]) {
                    $dataLength = strlen($row[$imageCol]);
                    echo "<p style='color: green;'><strong>✅ データあり:</strong> {$dataLength} 文字</p>";
                    
                    try {
                        $jsonData = json_decode($row[$imageCol], true);
                        if ($jsonData) {
                            echo "<div style='background: #e8f5e8; padding: 10px; border-radius: 4px; margin: 10px 0;'>";
                            echo "<h5 style='margin: 0 0 10px 0; color: #28a745;'>📋 JSON構造解析:</h5>";
                            
                            // 画像関連フィールドを探索
                            $foundImageData = false;
                            
                            // all_images チェック
                            if (isset($jsonData['all_images'])) {
                                $foundImageData = true;
                                if (is_array($jsonData['all_images'])) {
                                    $imageCount = count($jsonData['all_images']);
                                    echo "<p style='margin: 5px 0;'><strong>🖼️ all_images:</strong> 配列 - {$imageCount}件</p>";
                                    
                                    if ($imageCount > 0) {
                                        echo "<div style='margin: 10px 0;'>";
                                        echo "<strong>画像URL一覧:</strong>";
                                        echo "<div style='display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 5px; margin: 5px 0;'>";
                                        
                                        foreach (array_slice($jsonData['all_images'], 0, 6) as $imgIndex => $imgUrl) {
                                            if (is_string($imgUrl) && strlen($imgUrl) > 10) {
                                                echo "<div style='text-align: center; font-size: 8px;'>";
                                                echo "<img src='{$imgUrl}' style='max-width: 100px; max-height: 80px; border: 1px solid #ddd; border-radius: 3px;' alt='画像" . ($imgIndex + 1) . "' loading='lazy' onerror='this.style.display=\"none\"'>";
                                                echo "<div style='color: #666; margin-top: 2px;'>" . ($imgIndex + 1) . "</div>";
                                                echo "</div>";
                                            }
                                        }
                                        
                                        if ($imageCount > 6) {
                                            echo "<div style='text-align: center; color: #666; font-size: 10px; display: flex; align-items: center; justify-content: center;'>+". ($imageCount - 6) ."枚</div>";
                                        }
                                        
                                        echo "</div>";
                                        echo "</div>";
                                    }
                                } else {
                                    echo "<p style='margin: 5px 0; color: orange;'><strong>⚠️ all_images:</strong> 配列ではない - " . gettype($jsonData['all_images']) . "</p>";
                                }
                            }
                            
                            // images チェック
                            if (isset($jsonData['images'])) {
                                $foundImageData = true;
                                if (is_array($jsonData['images'])) {
                                    $imageCount = count($jsonData['images']);
                                    echo "<p style='margin: 5px 0;'><strong>🖼️ images:</strong> 配列 - {$imageCount}件</p>";
                                } else {
                                    echo "<p style='margin: 5px 0; color: orange;'><strong>⚠️ images:</strong> 配列ではない - " . gettype($jsonData['images']) . "</p>";
                                }
                            }
                            
                            // extraction_results.images チェック
                            if (isset($jsonData['extraction_results']['images'])) {
                                $foundImageData = true;
                                if (is_array($jsonData['extraction_results']['images'])) {
                                    $imageCount = count($jsonData['extraction_results']['images']);
                                    echo "<p style='margin: 5px 0;'><strong>🖼️ extraction_results.images:</strong> 配列 - {$imageCount}件</p>";
                                } else {
                                    echo "<p style='margin: 5px 0; color: orange;'><strong>⚠️ extraction_results.images:</strong> 配列ではない</p>";
                                }
                            }
                            
                            // その他の可能な画像フィールド
                            $otherImageFields = [];
                            foreach ($jsonData as $key => $value) {
                                if (strpos(strtolower($key), 'image') !== false && $key !== 'all_images' && $key !== 'images') {
                                    $otherImageFields[] = $key;
                                }
                            }
                            
                            if (!empty($otherImageFields)) {
                                echo "<p style='margin: 5px 0;'><strong>🔍 その他の画像関連フィールド:</strong> " . implode(', ', $otherImageFields) . "</p>";
                            }
                            
                            // 利用可能なトップレベルキー
                            echo "<p style='margin: 5px 0;'><strong>📋 利用可能なキー:</strong> " . implode(', ', array_keys($jsonData)) . "</p>";
                            
                            if (!$foundImageData) {
                                echo "<p style='color: red; font-weight: bold;'>❌ 画像関連データが見つかりません</p>";
                                
                                // データ構造を詳細表示
                                echo "<details style='margin: 10px 0;'>";
                                echo "<summary style='cursor: pointer; color: #666;'>🔍 JSON構造詳細（クリックで展開）</summary>";
                                echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 10px; max-height: 300px; overflow-y: auto; margin: 5px 0;'>";
                                echo htmlspecialchars(json_encode($jsonData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                                echo "</pre>";
                                echo "</details>";
                            }
                            
                            echo "</div>";
                        } else {
                            echo "<p style='color: red;'>❌ JSON解析失敗</p>";
                        }
                    } catch (Exception $e) {
                        echo "<p style='color: red;'>❌ JSON解析エラー: " . htmlspecialchars($e->getMessage()) . "</p>";
                    }
                } else {
                    echo "<p style='color: red; font-weight: bold;'>❌ データなし（NULL）</p>";
                }
            } else {
                // その他の画像カラム
                if ($row[$imageCol]) {
                    echo "<p style='color: green;'><strong>✅ データあり:</strong> " . htmlspecialchars(substr($row[$imageCol], 0, 80)) . "...</p>";
                    
                    if (filter_var($row[$imageCol], FILTER_VALIDATE_URL)) {
                        echo "<div style='margin: 10px 0;'>";
                        echo "<img src='{$row[$imageCol]}' style='max-width: 200px; max-height: 150px; border: 1px solid #ddd; border-radius: 4px;' alt='{$imageCol}' loading='lazy'>";
                        echo "</div>";
                    }
                } else {
                    echo "<p style='color: red; font-weight: bold;'>❌ データなし（NULL）</p>";
                }
            }
            echo "</div>";
        }
        echo "</div>";
    }
    
    // 3. 統計情報
    echo "<h2>3. 📊 画像データ保存統計</h2>";
    
    $statsSql = "SELECT COUNT(*) as total_records";
    foreach ($imageColumns as $imageCol) {
        $statsSql .= ", COUNT({$imageCol}) as has_{$imageCol}";
        $statsSql .= ", COUNT(CASE WHEN {$imageCol} IS NOT NULL AND {$imageCol} != '' THEN 1 END) as non_empty_{$imageCol}";
    }
    $statsSql .= " FROM yahoo_scraped_products";
    
    $statsStmt = $pdo->query($statsSql);
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.9em;'>";
    echo "<tr><th>カラム</th><th>NULL以外</th><th>空でない</th><th>割合</th></tr>";
    echo "<tr><td><strong>総レコード数</strong></td><td colspan='3'>{$stats['total_records']}</td></tr>";
    
    foreach ($imageColumns as $imageCol) {
        $hasCount = $stats["has_{$imageCol}"];
        $nonEmptyCount = $stats["non_empty_{$imageCol}"];
        $percentage = $stats['total_records'] > 0 ? round($nonEmptyCount / $stats['total_records'] * 100, 1) : 0;
        
        $rowColor = '';
        if ($percentage < 50) {
            $rowColor = 'background: #ffe6e6;'; // 赤背景
        } elseif ($percentage < 80) {
            $rowColor = 'background: #fff3cd;'; // 黄背景
        } else {
            $rowColor = 'background: #e8f5e8;'; // 緑背景
        }
        
        echo "<tr style='{$rowColor}'>";
        echo "<td><strong>{$imageCol}</strong></td>";
        echo "<td>{$hasCount}</td>";
        echo "<td>{$nonEmptyCount}</td>";
        echo "<td>{$percentage}%</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 4. スクレイピング実行状況確認
    echo "<h2>4. 🕷️ スクレイピング実行状況確認</h2>";
    
    $recentSql = "SELECT id, source_item_id, active_title, created_at, updated_at,
                         CASE WHEN scraped_yahoo_data IS NOT NULL THEN 'あり' ELSE 'なし' END as has_scraped_data
                  FROM yahoo_scraped_products 
                  ORDER BY updated_at DESC 
                  LIMIT 10";
    
    $recentStmt = $pdo->query($recentSql);
    $recentData = $recentStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
    echo "<tr><th>ID</th><th>source_item_id</th><th>タイトル</th><th>scraped_data</th><th>作成日時</th><th>更新日時</th><th>状況</th></tr>";
    
    foreach ($recentData as $recent) {
        $statusColor = $recent['has_scraped_data'] === 'あり' ? '#28a745' : '#dc3545';
        $statusText = $recent['has_scraped_data'] === 'あり' ? '✅ 正常' : '❌ 不完全';
        
        echo "<tr>";
        echo "<td>{$recent['id']}</td>";
        echo "<td style='font-family: monospace; font-size: 0.7em;'>{$recent['source_item_id']}</td>";
        echo "<td>" . htmlspecialchars(substr($recent['active_title'], 0, 30)) . "...</td>";
        echo "<td style='color: {$statusColor}; font-weight: bold;'>{$recent['has_scraped_data']}</td>";
        echo "<td style='font-size: 0.7em;'>{$recent['created_at']}</td>";
        echo "<td style='font-size: 0.7em;'>{$recent['updated_at']}</td>";
        echo "<td style='color: {$statusColor}; font-weight: bold;'>{$statusText}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 5. 推奨アクション
    echo "<h2>5. 🎯 推奨アクション</h2>";
    
    $scrapedDataCount = $stats["non_empty_scraped_yahoo_data"];
    $totalCount = $stats['total_records'];
    $scrapedPercentage = $totalCount > 0 ? round($scrapedDataCount / $totalCount * 100, 1) : 0;
    
    echo "<div style='padding: 20px; border-radius: 8px; margin: 15px 0;'>";
    
    if ($scrapedPercentage < 50) {
        echo "<div style='background: #ffe6e6; border: 2px solid #dc3545;'>";
        echo "<h4 style='color: #dc3545; margin: 0 0 10px 0;'>🚨 緊急: 画像データ不足</h4>";
        echo "<p><strong>scraped_yahoo_data充足率:</strong> {$scrapedPercentage}%</p>";
        echo "<p><strong>推奨アクション:</strong></p>";
        echo "<ol>";
        echo "<li><strong>再スクレイピング実行</strong> - scraped_yahoo_dataを充実させる</li>";
        echo "<li><strong>スクレイピングコード確認</strong> - 画像抽出部分の動作確認</li>";
        echo "<li><strong>データベース保存処理確認</strong> - JSON保存の確認</li>";
        echo "</ol>";
        echo "</div>";
    } elseif ($scrapedPercentage < 80) {
        echo "<div style='background: #fff3cd; border: 2px solid #ffc107;'>";
        echo "<h4 style='color: #856404; margin: 0 0 10px 0;'>⚠️ 注意: 画像データ不完全</h4>";
        echo "<p><strong>scraped_yahoo_data充足率:</strong> {$scrapedPercentage}%</p>";
        echo "<p><strong>推奨アクション:</strong> 部分的な再スクレイピング</p>";
        echo "</div>";
    } else {
        echo "<div style='background: #e8f5e8; border: 2px solid #28a745;'>";
        echo "<h4 style='color: #28a745; margin: 0 0 10px 0;'>✅ 良好: 画像データ充実</h4>";
        echo "<p><strong>scraped_yahoo_data充足率:</strong> {$scrapedPercentage}%</p>";
        echo "<p><strong>推奨アクション:</strong> JavaScript表示部分の修正</p>";
        echo "</div>";
    }
    
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo "<hr>";
echo "<p style='text-align: center;'>";
echo "<a href='../02_scraping/scraping.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>🕷️ 再スクレイピング実行</a>";
echo "<a href='../05_editing/editing.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>📝 editing.phpで確認</a>";
echo "</p>";
?>
