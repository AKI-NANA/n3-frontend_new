<?php
/**
 * Webサーバー動作確認テスト
 */
header('Content-Type: text/html; charset=UTF-8');

echo "<h1>🌐 Webサーバー動作確認</h1>";

echo "<h2>基本情報</h2>";
echo "<p><strong>現在時刻:</strong> " . date('Y-m-d H:i:s') . "</p>";
echo "<p><strong>現在のPHPファイル:</strong> " . $_SERVER['PHP_SELF'] . "</p>";
echo "<p><strong>ドキュメントルート:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p><strong>実際のファイルパス:</strong> " . __FILE__ . "</p>";
echo "<p><strong>現在のディレクトリ:</strong> " . __DIR__ . "</p>";
echo "<p><strong>リクエストURI:</strong> " . $_SERVER['REQUEST_URI'] . "</p>";

echo "<h2>ファイル一覧</h2>";
$files = scandir(__DIR__);
echo "<ul>";
foreach ($files as $file) {
    if ($file !== '.' && $file !== '..') {
        $is_php = pathinfo($file, PATHINFO_EXTENSION) === 'php';
        $icon = $is_php ? '🐘' : '📄';
        $size = filesize(__DIR__ . '/' . $file);
        echo "<li>$icon <a href='$file' target='_blank'>$file</a> (" . number_format($size) . " bytes)</li>";
    }
}
echo "</ul>";

echo "<h2>重要ファイル確認</h2>";
$important_files = [
    'emergency_fix_test.php' => 'Emergency Fix Test',
    'yahoo_parser_emergency.php' => 'Emergency Parser',
    'scraping.php' => 'Main Scraping System'
];

foreach ($important_files as $filename => $description) {
    $filepath = __DIR__ . '/' . $filename;
    $exists = file_exists($filepath);
    $status = $exists ? "✅ 存在" : "❌ 不存在";
    $size = $exists ? " (" . number_format(filesize($filepath)) . " bytes)" : "";
    
    echo "<p><strong>$description:</strong> $status$size";
    if ($exists) {
        echo " - <a href='$filename' target='_blank'>アクセス</a>";
    }
    echo "</p>";
}

echo "<h2>アクセス方法テスト</h2>";
echo "<p>以下のリンクをクリックして動作確認してください:</p>";
echo "<ul>";
echo "<li><a href='emergency_fix_test.php' target='_blank'>emergency_fix_test.php</a></li>";
echo "<li><a href='yahoo_parser_emergency.php' target='_blank'>yahoo_parser_emergency.php</a></li>";
echo "<li><a href='scraping.php' target='_blank'>scraping.php</a></li>";
echo "</ul>";

// 簡単なPHP動作テスト
echo "<h2>PHP動作テスト</h2>";
echo "<p>現在の日時: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>ランダム数値: " . rand(1000, 9999) . "</p>";
echo "<p>PHP設定 - memory_limit: " . ini_get('memory_limit') . "</p>";
echo "<p>PHP設定 - max_execution_time: " . ini_get('max_execution_time') . "</p>";
?>
