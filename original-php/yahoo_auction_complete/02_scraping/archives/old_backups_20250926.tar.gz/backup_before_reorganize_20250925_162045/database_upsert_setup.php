<?php
/**
 * データベーステーブル修正・UPSERT対応
 */

echo "<h1>🔧 データベーステーブル修正 - UPSERT対応</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. 現在のテーブル構造確認
    echo "<h2>1. 現在のテーブル構造確認</h2>";
    $sql = "SELECT column_name, data_type, is_nullable, column_default 
            FROM information_schema.columns 
            WHERE table_name = 'yahoo_scraped_products' 
            ORDER BY ordinal_position";
    
    $stmt = $pdo->query($sql);
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>カラム名</th><th>データ型</th><th>NULL許可</th><th>デフォルト値</th></tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>{$column['column_name']}</td>";
        echo "<td>{$column['data_type']}</td>";
        echo "<td>{$column['is_nullable']}</td>";
        echo "<td>" . ($column['column_default'] ?: 'なし') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 2. 既存のインデックスと制約確認
    echo "<h2>2. 既存のインデックスと制約確認</h2>";
    $constraintSql = "SELECT constraint_name, constraint_type, column_name 
                      FROM information_schema.key_column_usage kcu
                      JOIN information_schema.table_constraints tc 
                      ON kcu.constraint_name = tc.constraint_name
                      WHERE kcu.table_name = 'yahoo_scraped_products'";
    
    $constraintStmt = $pdo->query($constraintSql);
    $constraints = $constraintStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($constraints)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>制約名</th><th>制約タイプ</th><th>カラム名</th></tr>";
        
        foreach ($constraints as $constraint) {
            echo "<tr>";
            echo "<td>{$constraint['constraint_name']}</td>";
            echo "<td>{$constraint['constraint_type']}</td>";
            echo "<td>{$constraint['column_name']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div style='color: orange; padding: 10px;'>📊 カスタム制約は見つかりませんでした</div>";
    }
    
    // 3. source_item_id のユニーク制約追加
    echo "<h2>3. source_item_id ユニーク制約追加</h2>";
    
    try {
        // 既存の重複データをチェック
        $duplicateCheckSql = "SELECT source_item_id, COUNT(*) as count 
                              FROM yahoo_scraped_products 
                              WHERE source_item_id IS NOT NULL 
                              GROUP BY source_item_id 
                              HAVING COUNT(*) > 1";
        
        $duplicateStmt = $pdo->query($duplicateCheckSql);
        $duplicates = $duplicateStmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($duplicates)) {
            echo "<div style='color: orange; padding: 10px; background: #fff3cd; margin: 10px 0;'>⚠️ 重複データが見つかりました:</div>";
            echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr><th>source_item_id</th><th>重複数</th></tr>";
            
            foreach ($duplicates as $duplicate) {
                echo "<tr>";
                echo "<td>{$duplicate['source_item_id']}</td>";
                echo "<td>{$duplicate['count']}</td>";
                echo "</tr>";
            }
            echo "</table>";
            
            // 重複データを削除（最新のもの以外）
            echo "<h3>重複データクリーンアップ</h3>";
            $cleanupSql = "DELETE FROM yahoo_scraped_products 
                          WHERE id NOT IN (
                              SELECT MAX(id) 
                              FROM yahoo_scraped_products 
                              GROUP BY source_item_id
                          )";
            
            $cleanupResult = $pdo->exec($cleanupSql);
            echo "<div style='color: blue; padding: 10px;'>🗑️ {$cleanupResult}件の重複データを削除しました</div>";
        } else {
            echo "<div style='color: green; padding: 10px;'>✅ 重複データは見つかりませんでした</div>";
        }
        
        // ユニーク制約を追加
        $uniqueConstraintSql = "ALTER TABLE yahoo_scraped_products 
                               ADD CONSTRAINT unique_source_item_id 
                               UNIQUE (source_item_id)";
        
        $pdo->exec($uniqueConstraintSql);
        echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ source_item_id にユニーク制約を追加しました</div>";
        
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'already exists') !== false) {
            echo "<div style='color: blue; padding: 10px;'>📋 ユニーク制約は既に存在します</div>";
        } else {
            echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>❌ ユニーク制約追加エラー: " . $e->getMessage() . "</div>";
        }
    }
    
    // 4. 制約追加後の確認
    echo "<h2>4. 制約追加後の確認</h2>";
    $constraintStmt = $pdo->query($constraintSql);
    $constraints = $constraintStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>制約名</th><th>制約タイプ</th><th>カラム名</th></tr>";
    
    foreach ($constraints as $constraint) {
        echo "<tr>";
        echo "<td>{$constraint['constraint_name']}</td>";
        echo "<td>{$constraint['constraint_type']}</td>";
        echo "<td>{$constraint['column_name']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<h2>5. 次のステップ</h2>";
    echo "<div style='padding: 10px; background: #f0f8ff; border-radius: 5px;'>";
    echo "<ol>";
    echo "<li><strong>UPSERT対応保存関数の実装</strong> - database_save_upsert.php</li>";
    echo "<li><strong>スクレイピングシステムの修正</strong> - scraping.php</li>";
    echo "<li><strong>デバッグログの実装</strong> - データフロー追跡</li>";
    echo "<li><strong>テストデータでの動作確認</strong> - 同一URLからの重複テスト</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベース接続エラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='scraping.php'>← スクレイピングに戻る</a> | <a href='../05_editing/editing.php'>データ編集へ →</a></p>";
?>
