<?php
/**
 * 緊急診断用: 実際のYahoo!オークションページでリアルタイムテスト
 * URL: https://auctions.yahoo.co.jp/jp/auction/m1198908523
 * 期待される結果: 価格 37,777円、状態「未使用に近い」
 */

header('Content-Type: text/html; charset=UTF-8');

// テスト対象URL
$test_url = 'https://auctions.yahoo.co.jp/jp/auction/m1198908523';
$item_id = 'm1198908523';

?><!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🚨 緊急診断: Yahoo!オークションパーサーテスト</title>
    <style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    .result { margin: 15px 0; padding: 15px; border-radius: 6px; }
    .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
    .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
    .warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; }
    .info { background: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; font-size: 11px; max-height: 300px; overflow-y: auto; }
    .expected { background: #e8f5e8; padding: 10px; border-left: 4px solid #28a745; margin: 10px 0; }
    .actual { background: #fdf2e8; padding: 10px; border-left: 4px solid #fd7e14; margin: 10px 0; }
    .comparison { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚨 緊急診断: パーサー精度検証</h1>
        
        <div class="result info">
            <strong>テスト対象:</strong><br>
            URL: <?php echo $test_url; ?><br>
            商品ID: <?php echo $item_id; ?><br>
            実行時刻: <?php echo date('Y-m-d H:i:s'); ?>
        </div>

        <div class="expected">
            <h3>🎯 期待される正確な結果:</h3>
            <ul>
                <li><strong>タイトル:</strong> マツバのゲンガー VS ポケモンカードe 1ED ポケカ ポケモンカード</li>
                <li><strong>価格:</strong> 37,777円</li>
                <li><strong>状態:</strong> 未使用に近い</li>
                <li><strong>カテゴリ:</strong> ポケモンカードゲーム</li>
                <li><strong>入札:</strong> 0件</li>
            </ul>
        </div>

        <?php
        // HTMLデータ取得
        $context = stream_context_create([
            'http' => [
                'header' => "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n",
                'timeout' => 30
            ]
        ]);
        
        $html = @file_get_contents($test_url, false, $context);
        
        if (!$html) {
            echo '<div class="result error"><strong>❌ HTML取得失敗:</strong> Yahoo!オークションページにアクセスできませんでした。</div>';
        } else {
            echo '<div class="result success"><strong>✅ HTML取得成功:</strong> ' . strlen($html) . ' 文字</div>';
            
            // 修正版パーサーのテスト
            if (file_exists('yahoo_parser_fixed_v2.php')) {
                require_once 'yahoo_parser_fixed_v2.php';
                
                echo '<h2>🔍 修正版パーサー結果:</h2>';
                
                $start_time = microtime(true);
                $result = parseYahooAuctionHTML_Fixed($html, $test_url, $item_id);
                $execution_time = round((microtime(true) - $start_time) * 1000, 2);
                
                if ($result) {
                    $accuracy_check = [
                        'タイトル' => [
                            'expected' => 'マツバのゲンガー',
                            'actual' => $result['title'] ?? 'null',
                            'match' => strpos($result['title'] ?? '', 'ゲンガー') !== false
                        ],
                        '価格' => [
                            'expected' => 37777,
                            'actual' => $result['current_price'] ?? 0,
                            'match' => ($result['current_price'] ?? 0) == 37777
                        ],
                        '状態' => [
                            'expected' => '未使用に近い',
                            'actual' => $result['condition'] ?? 'null',
                            'match' => strpos($result['condition'] ?? '', 'Like New') !== false || strpos($result['condition'] ?? '', '未使用') !== false
                        ]
                    ];
                    
                    $total_matches = array_sum(array_column($accuracy_check, 'match'));
                    $accuracy_percentage = round(($total_matches / count($accuracy_check)) * 100, 1);
                    
                    $result_class = $accuracy_percentage >= 80 ? 'success' : ($accuracy_percentage >= 50 ? 'warning' : 'error');
                    
                    echo "<div class='result $result_class'>";
                    echo "<strong>精度: {$accuracy_percentage}% ({$total_matches}/" . count($accuracy_check) . " 項目正確)</strong><br>";
                    echo "品質スコア: " . ($result['data_quality'] ?? 'N/A') . "%<br>";
                    echo "実行時間: {$execution_time}ms";
                    echo "</div>";
                    
                    echo '<div class="comparison">';
                    echo '<div class="expected"><h4>期待値 vs 実際の値:</h4>';
                    foreach ($accuracy_check as $field => $check) {
                        $icon = $check['match'] ? '✅' : '❌';
                        echo "<p><strong>{$field}:</strong> $icon<br>";
                        echo "期待: {$check['expected']}<br>";
                        echo "実際: {$check['actual']}</p>";
                    }
                    echo '</div>';
                    
                    echo '<div class="actual"><h4>完全な抽出結果:</h4>';
                    echo '<pre>' . htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</pre>';
                    echo '</div>';
                    echo '</div>';
                    
                } else {
                    echo '<div class="result error"><strong>❌ パーサー失敗:</strong> データ抽出に完全に失敗しました（品質スコア60%未満）</div>';
                }
                
            } else {
                echo '<div class="result error"><strong>❌ パーサーファイル不存在:</strong> yahoo_parser_fixed_v2.php が見つかりません</div>';
            }
            
            // HTMLデバッグ情報
            echo '<h2>🔍 HTMLデバッグ情報:</h2>';
            
            // JSONデータ検索
            if (preg_match('/__NEXT_DATA__\s*=\s*({.*?})/s', $html, $matches)) {
                echo '<div class="result success"><strong>✅ __NEXT_DATA__ 発見:</strong> JSONデータが存在します</div>';
                $json_data = json_decode($matches[1], true);
                if ($json_data) {
                    echo '<pre>' . htmlspecialchars(json_encode($json_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</pre>';
                }
            } else {
                echo '<div class="result warning"><strong>⚠️ __NEXT_DATA__ なし:</strong> HTMLパースに依存します</div>';
            }
            
            // 重要HTML要素の確認
            $dom = new DOMDocument();
            @$dom->loadHTML($html);
            $xpath = new DOMXPath($dom);
            
            $checks = [
                'タイトル (h1)' => $xpath->query('//h1')->length,
                '価格 (円を含むspan)' => $xpath->query('//span[contains(text(), "円")]')->length,
                '画像 (img)' => $xpath->query('//img')->length,
                'スクリプト (__NEXT_DATA__)' => $xpath->query('//script[contains(text(), "__NEXT_DATA__")]')->length
            ];
            
            echo '<div class="result info"><strong>HTML要素確認:</strong><br>';
            foreach ($checks as $element => $count) {
                echo "• {$element}: {$count}個<br>";
            }
            echo '</div>';
        }
        ?>
        
        <div class="result warning">
            <strong>🚨 問題の原因特定:</strong><br>
            1. パーサーが呼び出されていない<br>
            2. JSON抽出パターンが不適合<br>
            3. HTML セレクターが不正確<br>
            4. 品質スコア計算の問題
        </div>
    </div>
</body>
</html>
