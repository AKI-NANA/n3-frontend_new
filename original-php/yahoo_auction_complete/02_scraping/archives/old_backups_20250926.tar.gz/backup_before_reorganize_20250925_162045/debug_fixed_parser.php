<?php
/**
 * 完全修正版パーサー問題診断ツール（独立実行版）
 */

// 最小限の依存関係で実行
function writeLog($message, $level = 'INFO') {
    echo "[{$level}] {$message}\n";
}

// fetchYahooAuctionHTML関数の簡易版
function fetchYahooAuctionHTML($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language: ja,en-US;q=0.7,en;q=0.3',
        ],
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $html = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return ($html && $http_code === 200) ? $html : false;
}

function debugFixedParserIssues($url) {
    echo "🔍 完全修正版パーサー問題診断開始\n";
    echo "URL: {$url}\n";
    echo str_repeat("=", 80) . "\n\n";
    
    // 1. HTML取得テスト
    echo "📡 1. HTML取得テスト\n";
    echo str_repeat("-", 40) . "\n";
    $html = fetchYahooAuctionHTML($url);
    
    if (!$html) {
        echo "❌ HTML取得失敗\n";
        return;
    }
    
    echo "✅ HTML取得成功: " . strlen($html) . "文字\n\n";
    
    // 2. DOM解析テスト
    echo "🏗️ 2. DOM解析テスト\n";
    echo str_repeat("-", 40) . "\n";
    
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $success = $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
    libxml_use_internal_errors(false);
    
    if (!$success) {
        echo "❌ DOM解析失敗\n";
        return;
    }
    
    $xpath = new DOMXPath($dom);
    echo "✅ DOM解析成功\n\n";
    
    // 3. オークション判定詳細テスト
    echo "🎯 3. オークション判定詳細テスト\n";
    echo str_repeat("-", 40) . "\n";
    
    debugAuctionDetectionDetailed($xpath);
    
    // 4. カテゴリ抽出詳細テスト
    echo "\n📂 4. カテゴリ抽出詳細テスト\n";
    echo str_repeat("-", 40) . "\n";
    
    debugCategoryExtractionDetailed($xpath);
    
    // 5. 商品状態抽出詳細テスト
    echo "\n🔍 5. 商品状態抽出詳細テスト\n";
    echo str_repeat("-", 40) . "\n";
    
    debugConditionExtractionDetailed($xpath);
    
    // 6. 価格抽出詳細テスト
    echo "\n💰 6. 価格抽出詳細テスト\n";
    echo str_repeat("-", 40) . "\n";
    
    debugPriceExtractionDetailed($xpath);
    
    // 7. タイトル抽出詳細テスト
    echo "\n📝 7. タイトル抽出詳細テスト\n";
    echo str_repeat("-", 40) . "\n";
    
    debugTitleExtractionDetailed($dom, $xpath);
    
    // 8. 全体的な要素確認
    echo "\n🔎 8. 全体的な要素確認\n";
    echo str_repeat("-", 40) . "\n";
    
    debugOverallElementsDetailed($xpath);
    
    echo "\n" . str_repeat("=", 80) . "\n";
    echo "診断完了\n";
}

function debugAuctionDetectionDetailed($xpath) {
    echo "🔍 オークション判定の詳細分析:\n";
    
    // 入札数パターンテスト
    echo "\n【入札数検出テスト】\n";
    $bid_patterns = [
        '//li[svg/@aria-label="入札"]/a[contains(text(), "件")]',
        '//*[contains(text(), "件") and contains(text(), "入札")]',
        '//a[contains(text(), "件")]',
        '//*[contains(text(), "件")]'
    ];
    
    foreach ($bid_patterns as $i => $pattern) {
        $elements = $xpath->query($pattern);
        echo "パターン" . ($i + 1) . ": {$pattern}\n";
        echo "  マッチ数: " . $elements->length . "\n";
        
        if ($elements->length > 0) {
            for ($j = 0; $j < min(3, $elements->length); $j++) {
                $text = trim($elements->item($j)->textContent);
                echo "  テキスト[{$j}]: '{$text}'\n";
                
                // 数値抽出テスト
                if (preg_match('/(\\d+)件/', $text, $matches)) {
                    echo "    抽出数値: {$matches[1]}\n";
                }
            }
        }
    }
    
    // 終了時間パターンテスト
    echo "\n【終了時間検出テスト】\n";
    $end_patterns = [
        '//li[svg/@aria-label="時間"]/span[contains(text(), "終了予定")]',
        '//*[contains(text(), "終了予定")]',
        '//*[contains(text(), "時間") and contains(text(), "終了")]',
        '//*[contains(text(), "時間")]',
        '//*[contains(text(), "終了")]'
    ];
    
    foreach ($end_patterns as $i => $pattern) {
        $elements = $xpath->query($pattern);
        echo "パターン" . ($i + 1) . ": {$pattern}\n";
        echo "  マッチ数: " . $elements->length . "\n";
        
        if ($elements->length > 0) {
            for ($j = 0; $j < min(3, $elements->length); $j++) {
                $text = trim($elements->item($j)->textContent);
                echo "  テキスト[{$j}]: '{$text}'\n";
                
                // 時間抽出テスト
                if (preg_match('/(\\d+)時間.*終了/', $text, $matches)) {
                    echo "    抽出時間: {$matches[1]}時間\n";
                }
            }
        }
    }
    
    // 入札ボタンテスト
    echo "\n【入札ボタン検出テスト】\n";
    $bid_button = $xpath->query('//*[contains(text(), "入札する")]');
    echo "入札ボタン数: " . $bid_button->length . "\n";
    
    if ($bid_button->length > 0) {
        echo "入札ボタンテキスト: '" . trim($bid_button->item(0)->textContent) . "'\n";
    }
    
    // ウォッチボタン vs 入札ボタンの判別
    echo "\n【ボタン種別判別テスト】\n";
    $watch_button = $xpath->query('//*[contains(text(), "ウォッチ")]');
    echo "ウォッチボタン数: " . $watch_button->length . "\n";
    
    $buy_button = $xpath->query('//*[contains(text(), "今すぐ落札") or contains(text(), "即決")]');
    echo "即決ボタン数: " . $buy_button->length . "\n";
    
    // 現在価格 vs 開始価格の判別
    echo "\n【価格種別判別テスト】\n";
    $current_price = $xpath->query('//*[contains(text(), "現在")]');
    echo "「現在」を含む要素数: " . $current_price->length . "\n";
    
    $start_price = $xpath->query('//*[contains(text(), "開始価格")]');
    echo "「開始価格」を含む要素数: " . $start_price->length . "\n";
}

function debugCategoryExtractionDetailed($xpath) {
    echo "📂 カテゴリ抽出の詳細分析:\n";
    
    // カテゴリdt要素の確認
    echo "\n【カテゴリdt要素確認】\n";
    $category_dt = $xpath->query('//dt[text()="カテゴリ"]');
    echo "カテゴリdt要素数: " . $category_dt->length . "\n";
    
    if ($category_dt->length > 0) {
        echo "✅ カテゴリdt要素が存在\n";
        
        // dd要素の確認
        $category_dd = $xpath->query('following-sibling::dd[1]', $category_dt->item(0));
        echo "対応するdd要素数: " . $category_dd->length . "\n";
        
        if ($category_dd->length > 0) {
            // li要素の確認
            $li_elements = $xpath->query('.//li', $category_dd->item(0));
            echo "li要素数: " . $li_elements->length . "\n";
            
            // 全リンクの表示
            $all_links = $xpath->query('.//a', $category_dd->item(0));
            echo "リンク数: " . $all_links->length . "\n";
            
            echo "\n【カテゴリパンくずリスト】\n";
            for ($i = 0; $i < $all_links->length; $i++) {
                $link_text = trim($all_links->item($i)->textContent);
                $is_last = ($i === $all_links->length - 1);
                echo "  [{$i}] {$link_text}" . ($is_last ? " ← 最終カテゴリ" : "") . "\n";
            }
            
            // Gemini推奨XPathのテスト
            echo "\n【Gemini推奨XPath結果】\n";
            $final_category_xpath = '//dt[text()="カテゴリ"]/following-sibling::dd[1]//li[last()]/a';
            $final_node = $xpath->query($final_category_xpath)->item(0);
            
            if ($final_node) {
                echo "✅ 最終カテゴリ取得成功: '" . trim($final_node->textContent) . "'\n";
            } else {
                echo "❌ 最終カテゴリ取得失敗\n";
                
                // 代替手法テスト
                if ($all_links->length > 0) {
                    $last_link = $all_links->item($all_links->length - 1);
                    echo "代替手法での最終カテゴリ: '" . trim($last_link->textContent) . "'\n";
                }
            }
        } else {
            echo "❌ 対応するdd要素が見つかりません\n";
        }
    } else {
        echo "❌ カテゴリdt要素が見つかりません\n";
        
        // 類似要素の検索
        echo "\n【類似要素検索】\n";
        $similar_elements = $xpath->query('//dt[contains(text(), "カテ")]');
        echo "「カテ」を含むdt要素数: " . $similar_elements->length . "\n";
        
        for ($i = 0; $i < min(5, $similar_elements->length); $i++) {
            $text = trim($similar_elements->item($i)->textContent);
            echo "  [{$i}]: '{$text}'\n";
        }
        
        // パンくずナビゲーション的な要素の検索
        echo "\n【パンくず要素検索】\n";
        $breadcrumb_patterns = [
            '//nav//a',
            '//*[@class and contains(@class, "breadcrumb")]//a',
            '//ul[@class and contains(@class, "path")]//a'
        ];
        
        foreach ($breadcrumb_patterns as $i => $pattern) {
            $elements = $xpath->query($pattern);
            echo "パンくずパターン" . ($i + 1) . ": " . $elements->length . "個\n";
            
            if ($elements->length > 0) {
                for ($j = 0; $j < min(3, $elements->length); $j++) {
                    $text = trim($elements->item($j)->textContent);
                    echo "  [{$j}]: '{$text}'\n";
                }
            }
        }
    }
}

function debugConditionExtractionDetailed($xpath) {
    echo "🔍 商品状態抽出の詳細分析:\n";
    
    // 商品状態dt要素の確認
    echo "\n【商品状態dt要素確認】\n";
    $condition_dt = $xpath->query('//dt[text()="商品の状態"]');
    echo "商品状態dt要素数: " . $condition_dt->length . "\n";
    
    if ($condition_dt->length > 0) {
        echo "✅ 商品状態dt要素が存在\n";
        
        // dd要素とリンクの確認
        $condition_dd = $xpath->query('following-sibling::dd[1]', $condition_dt->item(0));
        echo "対応するdd要素数: " . $condition_dd->length . "\n";
        
        if ($condition_dd->length > 0) {
            $condition_link = $xpath->query('.//a', $condition_dd->item(0));
            echo "リンク数: " . $condition_link->length . "\n";
            
            if ($condition_link->length > 0) {
                $condition_text = trim($condition_link->item(0)->textContent);
                echo "商品状態テキスト: '{$condition_text}'\n";
                
                // マッピングテスト
                $condition_map = [
                    '新品、未使用' => 'New',
                    '未使用に近い' => 'Like New',
                    '目立った傷や汚れなし' => 'Excellent',
                    'やや傷や汚れあり' => 'Good',
                    '傷や汚れあり' => 'Fair',
                    '全体的に状態が悪い' => 'Poor',
                    'ジャンク品' => 'For Parts'
                ];
                
                $mapped_condition = $condition_map[$condition_text] ?? 'Used';
                echo "マッピング結果: '{$condition_text}' -> '{$mapped_condition}'\n";
            } else {
                echo "❌ リンクが見つかりません\n";
                
                // dd要素内の全テキストを表示
                $dd_text = trim($condition_dd->item(0)->textContent);
                echo "dd要素内テキスト: '{$dd_text}'\n";
            }
        }
    } else {
        echo "❌ 商品状態dt要素が見つかりません\n";
        
        // 類似要素の検索
        echo "\n【類似要素検索】\n";
        $similar_elements = $xpath->query('//dt[contains(text(), "状態")]');
        echo "「状態」を含むdt要素数: " . $similar_elements->length . "\n";
        
        for ($i = 0; $i < min(5, $similar_elements->length); $i++) {
            $text = trim($similar_elements->item($i)->textContent);
            echo "  [{$i}]: '{$text}'\n";
        }
        
        // 代替パターンの検索
        echo "\n【代替状態表現検索】\n";
        $condition_patterns = [
            '//*[contains(text(), "新品")]',
            '//*[contains(text(), "中古")]',
            '//*[contains(text(), "未使用")]',
            '//*[contains(text(), "傷")]'
        ];
        
        foreach ($condition_patterns as $i => $pattern) {
            $elements = $xpath->query($pattern);
            echo "パターン" . ($i + 1) . ": " . $elements->length . "個\n";
            
            if ($elements->length > 0) {
                $text = trim($elements->item(0)->textContent);
                echo "  例: '" . substr($text, 0, 50) . "...'\n";
            }
        }
    }
}

function debugPriceExtractionDetailed($xpath) {
    echo "💰 価格抽出の詳細分析:\n";
    
    $price_patterns = [
        '//dt[contains(text(), "現在")]/following-sibling::dd[1]',
        '//*[contains(text(), "現在")]/following-sibling::*[contains(text(), "円")]',
        '//*[contains(text(), "現在")]',
        '//*[contains(text(), "円")]',
        '//*[contains(text(), "価格")]'
    ];
    
    foreach ($price_patterns as $i => $pattern) {
        echo "\n【価格パターン" . ($i + 1) . "】\n";
        echo "XPath: {$pattern}\n";
        
        $elements = $xpath->query($pattern);
        echo "マッチ数: " . $elements->length . "\n";
        
        if ($elements->length > 0) {
            for ($j = 0; $j < min(3, $elements->length); $j++) {
                $text = trim($elements->item($j)->textContent);
                echo "  テキスト[{$j}]: '" . substr($text, 0, 100) . "...'\n";
                
                // 数値抽出テスト
                if (preg_match('/([0-9,]+)/', $text, $matches)) {
                    $price = (int)str_replace(',', '', $matches[1]);
                    echo "    抽出価格: ¥{$price}\n";
                }
            }
        }
    }
}

function debugTitleExtractionDetailed($dom, $xpath) {
    echo "📝 タイトル抽出の詳細分析:\n";
    
    $title_patterns = [
        '//title',
        '//h1',
        '//*[@class and contains(@class, "ProductTitle")]',
        '//h2',
        '//*[contains(@class, "title")]'
    ];
    
    foreach ($title_patterns as $i => $pattern) {
        echo "\n【タイトルパターン" . ($i + 1) . "】\n";
        echo "XPath: {$pattern}\n";
        
        $elements = $xpath->query($pattern);
        echo "マッチ数: " . $elements->length . "\n";
        
        if ($elements->length > 0) {
            for ($j = 0; $j < min(3, $elements->length); $j++) {
                $text = trim($elements->item($j)->textContent);
                $clean_title = str_replace(' - Yahoo!オークション', '', $text);
                $clean_title = preg_replace('/\\s+/', ' ', $clean_title);
                
                echo "  生テキスト[{$j}]: '" . substr($text, 0, 80) . "...'\n";
                echo "  クリーンテキスト[{$j}]: '" . substr($clean_title, 0, 80) . "...'\n";
                echo "  文字数: " . strlen($clean_title) . "\n";
                echo "  適格性: " . (strlen($clean_title) > 5 && strlen($clean_title) < 200 ? "✅" : "❌") . "\n";
            }
        }
    }
}

function debugOverallElementsDetailed($xpath) {
    echo "🔎 全体的な要素確認:\n";
    
    // dt-dd構造の全体確認
    echo "\n【dt-dd構造の全体確認】\n";
    $all_dt = $xpath->query('//dt');
    echo "全dt要素数: " . $all_dt->length . "\n";
    
    echo "\n【全dt要素のテキスト】\n";
    for ($i = 0; $i < min(10, $all_dt->length); $i++) {
        $text = trim($all_dt->item($i)->textContent);
        echo "  dt[{$i}]: '{$text}'\n";
    }
    
    // フォーム要素の確認
    echo "\n【フォーム要素確認】\n";
    $buttons = $xpath->query('//button | //input[@type="button"] | //input[@type="submit"]');
    echo "ボタン要素数: " . $buttons->length . "\n";
    
    for ($i = 0; $i < min(5, $buttons->length); $i++) {
        $text = trim($buttons->item($i)->textContent);
        $value = $buttons->item($i)->getAttribute('value');
        echo "  button[{$i}]: text='{$text}' value='{$value}'\n";
    }
}

// コマンドライン実行の場合
if (isset($argv[1])) {
    debugFixedParserIssues($argv[1]);
} else {
    echo "使用方法: php " . basename(__FILE__) . " <URL>\n";
    echo "例: php " . basename(__FILE__) . " https://auctions.yahoo.co.jp/jp/auction/l1200404917\n";
}
?>
