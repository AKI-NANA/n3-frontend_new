<?php
/**
 * ハイブリッド価格管理システム - データベース構造セットアップ
 * Gemini推奨のハイブリッド方式を実装
 */

echo "<h1>🏦 ハイブリッド価格管理システム - セットアップ</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. 為替レートテーブル作成（Gemini推奨）
    echo "<h2>1. 為替レートテーブル作成</h2>";
    
    $exchangeRateTableSql = "
        CREATE TABLE IF NOT EXISTS exchange_rates (
            id SERIAL PRIMARY KEY,
            currency_from VARCHAR(3) NOT NULL,
            currency_to VARCHAR(3) NOT NULL,
            rate DECIMAL(10, 4) NOT NULL,
            recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
            source VARCHAR(50) DEFAULT 'manual',
            is_active BOOLEAN DEFAULT true
        )";
    
    $pdo->exec($exchangeRateTableSql);
    echo "<div style='color: green; padding: 10px;'>✅ exchange_rates テーブル作成完了</div>";
    
    // インデックス作成
    $indexSql = "CREATE INDEX IF NOT EXISTS idx_exchange_rates_currency_pair ON exchange_rates (currency_from, currency_to)";
    $pdo->exec($indexSql);
    
    $indexTimeSql = "CREATE INDEX IF NOT EXISTS idx_exchange_rates_recorded_at ON exchange_rates (recorded_at DESC)";
    $pdo->exec($indexTimeSql);
    
    echo "<div style='color: green; padding: 10px;'>✅ インデックス作成完了</div>";
    
    // 2. yahoo_scraped_products テーブルにハイブリッド価格カラム追加
    echo "<h2>2. yahoo_scraped_products テーブル - ハイブリッド価格カラム追加</h2>";
    
    // 既存カラム確認
    $columnCheckSql = "SELECT column_name FROM information_schema.columns WHERE table_name = 'yahoo_scraped_products'";
    $columnStmt = $pdo->query($columnCheckSql);
    $existingColumns = $columnStmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<div style='background: #f0f8ff; padding: 10px; border-radius: 5px; margin: 10px 0;'>";
    echo "<h4>既存カラム確認:</h4>";
    echo "<p>" . implode(', ', $existingColumns) . "</p>";
    echo "</div>";
    
    // 必要なカラムを追加
    $hybridColumns = [
        'cached_price_usd' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS cached_price_usd DECIMAL(10, 2)',
        'cache_rate' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS cache_rate DECIMAL(10, 4)',
        'cache_updated_at' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS cache_updated_at TIMESTAMP',
        'final_listing_price_usd' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS final_listing_price_usd DECIMAL(10, 2)',
        'shipping_cost_jpy' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS shipping_cost_jpy INTEGER DEFAULT 0',
        'profit_margin_percent' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS profit_margin_percent DECIMAL(5, 2) DEFAULT 20.00',
        'listing_status' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS listing_status VARCHAR(20) DEFAULT \'pending\'',
        'price_calculation_log' => 'ALTER TABLE yahoo_scraped_products ADD COLUMN IF NOT EXISTS price_calculation_log JSONB'
    ];
    
    foreach ($hybridColumns as $columnName => $sql) {
        try {
            $pdo->exec($sql);
            echo "<div style='color: green; padding: 5px;'>✅ {$columnName} カラム追加完了</div>";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'already exists') !== false) {
                echo "<div style='color: blue; padding: 5px;'>📋 {$columnName} カラムは既に存在</div>";
            } else {
                echo "<div style='color: red; padding: 5px;'>❌ {$columnName} エラー: " . $e->getMessage() . "</div>";
            }
        }
    }
    
    // 3. 初期為替レートデータ挿入
    echo "<h2>3. 初期為替レートデータ挿入</h2>";
    
    // 既存データ確認
    $existingRatesSql = "SELECT COUNT(*) as count FROM exchange_rates WHERE currency_from = 'JPY' AND currency_to = 'USD'";
    $existingStmt = $pdo->query($existingRatesSql);
    $existingCount = $existingStmt->fetch()['count'];
    
    if ($existingCount == 0) {
        // 初期レートデータ挿入
        $initialRates = [
            ['JPY', 'USD', 150.0000, 'initial_setup'],
            ['USD', 'JPY', 0.0067, 'initial_setup'], // 1/150
        ];
        
        $insertRateSql = "INSERT INTO exchange_rates (currency_from, currency_to, rate, source) VALUES (?, ?, ?, ?)";
        $insertStmt = $pdo->prepare($insertRateSql);
        
        foreach ($initialRates as $rate) {
            $insertStmt->execute($rate);
        }
        
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ 初期為替レートデータ（JPY-USD: 150.0）を挿入しました</div>";
    } else {
        echo "<div style='color: blue; padding: 10px;'>📋 為替レートデータは既に存在します ({$existingCount}件)</div>";
    }
    
    // 4. 現在の為替レート表示
    echo "<h2>4. 現在の為替レート確認</h2>";
    
    $currentRatesSql = "SELECT currency_from, currency_to, rate, recorded_at, source 
                        FROM exchange_rates 
                        WHERE is_active = true 
                        ORDER BY recorded_at DESC 
                        LIMIT 10";
    
    $currentStmt = $pdo->query($currentRatesSql);
    $currentRates = $currentStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($currentRates)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>通貨ペア</th><th>レート</th><th>記録日時</th><th>ソース</th></tr>";
        
        foreach ($currentRates as $rate) {
            echo "<tr>";
            echo "<td>{$rate['currency_from']} → {$rate['currency_to']}</td>";
            echo "<td>{$rate['rate']}</td>";
            echo "<td>{$rate['recorded_at']}</td>";
            echo "<td>{$rate['source']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // 5. 価格キャッシュ更新サンプル
    echo "<h2>5. 既存商品の価格キャッシュ更新</h2>";
    
    $updateCacheSql = "UPDATE yahoo_scraped_products 
                       SET cached_price_usd = ROUND(price_jpy / 150.0, 2),
                           cache_rate = 150.0,
                           cache_updated_at = CURRENT_TIMESTAMP
                       WHERE cached_price_usd IS NULL AND price_jpy > 0";
    
    $updateResult = $pdo->exec($updateCacheSql);
    echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>🔄 {$updateResult}件の商品価格キャッシュを更新しました</div>";
    
    // 6. 価格管理統計
    echo "<h2>6. 価格管理統計</h2>";
    
    $statsSql = "SELECT 
                    COUNT(*) as total_products,
                    COUNT(CASE WHEN cached_price_usd IS NOT NULL THEN 1 END) as cached_products,
                    COUNT(CASE WHEN final_listing_price_usd IS NOT NULL THEN 1 END) as final_priced_products,
                    AVG(price_jpy) as avg_price_jpy,
                    AVG(cached_price_usd) as avg_cached_usd
                 FROM yahoo_scraped_products";
    
    $statsStmt = $pdo->query($statsSql);
    $stats = $statsStmt->fetch();
    
    echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 5px;'>";
    echo "<h4>価格管理統計:</h4>";
    echo "<p><strong>総商品数:</strong> {$stats['total_products']}件</p>";
    echo "<p><strong>キャッシュ済み:</strong> {$stats['cached_products']}件</p>";
    echo "<p><strong>最終価格決定済み:</strong> {$stats['final_priced_products']}件</p>";
    echo "<p><strong>平均価格（円）:</strong> ¥" . number_format($stats['avg_price_jpy']) . "</p>";
    echo "<p><strong>平均キャッシュ価格（ドル）:</strong> $" . number_format($stats['avg_cached_usd'], 2) . "</p>";
    echo "</div>";
    
    // 7. 次のステップ
    echo "<h2>7. 次のステップ</h2>";
    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
    echo "<ol>";
    echo "<li><strong>価格計算API作成</strong> - price_calculator.php</li>";
    echo "<li><strong>為替レート更新システム</strong> - exchange_rate_updater.php</li>";
    echo "<li><strong>スクレイピング修正</strong> - ハイブリッド方式対応</li>";
    echo "<li><strong>編集画面修正</strong> - 動的価格表示対応</li>";
    echo "<li><strong>出品価格計算機能</strong> - 送料・利益計算含む</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='scraping.php'>← スクレイピングに戻る</a> | <a href='../05_editing/editing.php'>データ編集へ →</a></p>";
?>
