<?php
/**
 * データベース保存機能修正版
 * スクレイピングデータを正しいテーブルに保存
 */

// データベース接続
function getScrapingDatabaseConnection() {
    try {
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        return $pdo;
    } catch (PDOException $e) {
        error_log("スクレイピング用DB接続失敗: " . $e->getMessage());
        return null;
    }
}

// 商品データをyahoo_scraped_productsテーブルに保存
function saveScrapedProductToDatabase($product_data) {
    try {
        $pdo = getScrapingDatabaseConnection();
        if (!$pdo) {
            return false;
        }
        
        // yahoo_scraped_productsテーブルに保存
        $sql = "INSERT INTO yahoo_scraped_products (
            source_item_id,
            sku,
            ebay_item_id,
            title_hash,
            price_jpy,
            scraped_yahoo_data,
            active_title,
            active_description,
            active_price_usd,
            active_image_url,
            current_stock,
            status,
            priority_source,
            created_at,
            updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT (source_item_id) DO UPDATE SET
            active_title = EXCLUDED.active_title,
            active_description = EXCLUDED.active_description,
            price_jpy = EXCLUDED.price_jpy,
            scraped_yahoo_data = EXCLUDED.scraped_yahoo_data,
            updated_at = EXCLUDED.updated_at";
        
        $stmt = $pdo->prepare($sql);
        
        // データ準備
        $source_item_id = $product_data['item_id'] ?? 'SCRAPED_' . time();
        $sku = 'SKU-' . strtoupper($source_item_id);
        $ebay_item_id = null; // 未出品なのでNULL
        $title_hash = md5($product_data['title'] ?? '');
        $price_jpy = (int)($product_data['current_price'] ?? 0);
        $scraped_yahoo_data = json_encode([
            'category' => $product_data['category'] ?? 'Unknown',
            'condition' => $product_data['condition'] ?? 'Used',
            'url' => $product_data['source_url'] ?? '',
            'seller_name' => $product_data['seller_info']['name'] ?? '',
            'end_time' => $product_data['auction_info']['end_time'] ?? '',
            'bid_count' => $product_data['auction_info']['bid_count'] ?? 0,
            'scraped_at' => $product_data['scraped_at'] ?? date('Y-m-d H:i:s')
        ], JSON_UNESCAPED_UNICODE);
        $active_title = $product_data['title'] ?? 'タイトル不明';
        $active_description = $product_data['description'] ?? '';
        $active_price_usd = round($price_jpy / 150, 2); // 簡易USD換算
        $active_image_url = $product_data['images'][0] ?? 'https://via.placeholder.com/300x200/725CAD/FFFFFF?text=No+Image';
        $current_stock = 1;
        $status = 'scraped';
        $priority_source = 'yahoo';
        $created_at = date('Y-m-d H:i:s');
        $updated_at = date('Y-m-d H:i:s');
        
        $stmt->execute([
            $source_item_id,
            $sku,
            $ebay_item_id,
            $title_hash,
            $price_jpy,
            $scraped_yahoo_data,
            $active_title,
            $active_description,
            $active_price_usd,
            $active_image_url,
            $current_stock,
            $status,
            $priority_source,
            $created_at,
            $updated_at
        ]);
        
        error_log("スクレイピングデータDB保存成功: {$source_item_id}");
        return true;
        
    } catch (Exception $e) {
        error_log("スクレイピングデータDB保存失敗: " . $e->getMessage());
        return false;
    }
}

// テスト用サンプルデータ作成
function createSampleScrapedData() {
    $sample_products = [
        [
            'item_id' => 'SCRAPED_001',
            'title' => 'ヴィンテージ 腕時計 セイコー 自動巻き',
            'description' => '1970年代のセイコー自動巻き腕時計です。動作確認済み。',
            'current_price' => 45000,
            'condition' => 'Used',
            'category' => 'Watch',
            'images' => ['https://via.placeholder.com/300x200/0B1D51/FFFFFF?text=Watch'],
            'seller_info' => ['name' => 'vintage_collector'],
            'auction_info' => ['end_time' => date('Y-m-d H:i:s', strtotime('+3 days')), 'bid_count' => 5],
            'source_url' => 'https://auctions.yahoo.co.jp/jp/auction/scraped001',
            'scraped_at' => date('Y-m-d H:i:s')
        ],
        [
            'item_id' => 'SCRAPED_002', 
            'title' => '限定版 フィギュア ガンダム MSN-04',
            'description' => 'バンダイ製ガンダムフィギュア限定版です。未開封品。',
            'current_price' => 28000,
            'condition' => 'New',
            'category' => 'Figure',
            'images' => ['https://via.placeholder.com/300x200/725CAD/FFFFFF?text=Gundam'],
            'seller_info' => ['name' => 'figure_shop'],
            'auction_info' => ['end_time' => date('Y-m-d H:i:s', strtotime('+5 days')), 'bid_count' => 12],
            'source_url' => 'https://auctions.yahoo.co.jp/jp/auction/scraped002',
            'scraped_at' => date('Y-m-d H:i:s')
        ]
    ];
    
    $success_count = 0;
    foreach ($sample_products as $product) {
        if (saveScrapedProductToDatabase($product)) {
            $success_count++;
        }
    }
    
    return [
        'success' => $success_count > 0,
        'message' => "{$success_count}件のサンプルデータを作成しました",
        'created_count' => $success_count
    ];
}

// 実際のスクレイピング結果をDBに保存する関数（修正版）
function saveProductToDatabase($product_data) {
    return saveScrapedProductToDatabase($product_data);
}

echo "✅ データベース保存機能修正版読み込み完了\n";
?>
