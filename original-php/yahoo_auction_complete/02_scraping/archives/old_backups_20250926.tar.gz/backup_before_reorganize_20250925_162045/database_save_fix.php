<?php
/**
 * 修正版データベース保存関数 - テーブル構造対応
 * SKUカラムが存在しないため、対応するSQL文に修正
 */

// 商品データをデータベースに保存（テーブル構造修正版）
function saveProductToDatabase_Fixed($product_data) {
    try {
        writeLog("🔄 [DB保存開始] データベース保存処理開始", 'INFO');
        
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        writeLog("✅ [DB接続成功] PDO接続確立", 'SUCCESS');
        
        // 入力データの検証
        if (!$product_data || !is_array($product_data)) {
            writeLog("❌ [DB保存エラー] 無効な商品データ", 'ERROR');
            return false;
        }
        
        // データ準備（実際のテーブル構造に合わせて修正）
        $source_item_id = $product_data['item_id'] ?? 'SCRAPED_' . time() . '_' . rand(100, 999);
        $price_jpy = (int)($product_data['current_price'] ?? 0);
        $active_title = $product_data['title'] ?? 'タイトル不明';
        $active_description = $product_data['description'] ?? '';
        $active_price_usd = $price_jpy > 0 ? round($price_jpy / 150, 2) : null;
        $active_image_url = (!empty($product_data['images']) && isset($product_data['images'][0])) 
            ? $product_data['images'][0] 
            : 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image';
        $current_stock = 1;
        $status = 'scraped';
        
        // 文字列の長さ制限チェック
        if (strlen($active_title) > 5000) {
            $active_title = substr($active_title, 0, 4997) . '...';
            writeLog("⚠️ [タイトル切り詰め] タイトルが長すぎるため切り詰めました", 'WARNING');
        }
        
        if (strlen($active_description) > 10000) {
            $active_description = substr($active_description, 0, 9997) . '...';
            writeLog("⚠️ [説明切り詰め] 説明が長すぎるため切り詰めました", 'WARNING');
        }
        
        // JSONデータ構築（エラーハンドリング付き）
        $scraped_yahoo_data_array = [
            'category' => $product_data['category'] ?? 'Unknown',
            'condition' => $product_data['condition'] ?? 'Used',
            'url' => $product_data['source_url'] ?? '',
            'seller_name' => $product_data['seller_info']['name'] ?? 'Unknown',
            'bid_count' => $product_data['auction_info']['bid_count'] ?? 0,
            'end_time' => $product_data['auction_info']['end_time'] ?? '',
            'scraped_at' => date('Y-m-d H:i:s'),
            'scraping_method' => $product_data['scraping_method'] ?? 'unknown',
            'data_quality' => $product_data['data_quality'] ?? null,
            'extraction_success' => $product_data['extraction_success'] ?? null
        ];
        
        $scraped_yahoo_data = json_encode($scraped_yahoo_data_array, JSON_UNESCAPED_UNICODE);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            writeLog("❌ [JSONエラー] JSONエンコード失敗: " . json_last_error_msg(), 'ERROR');
            $scraped_yahoo_data = json_encode([
                'error' => 'JSON encoding failed',
                'scraped_at' => date('Y-m-d H:i:s'),
                'scraping_method' => $product_data['scraping_method'] ?? 'unknown'
            ], JSON_UNESCAPED_UNICODE);
        }
        
        writeLog("📝 [データ準備完了] source_item_id: {$source_item_id}, title: {$active_title}, price: ¥{$price_jpy}", 'INFO');
        writeLog("🖼️ [画像URL] {$active_image_url}", 'INFO');
        writeLog("📊 [JSON] " . strlen($scraped_yahoo_data) . "文字", 'INFO');
        
        // 重複チェック
        writeLog("🔍 [重複チェック開始] source_item_id: {$source_item_id}", 'INFO');
        $checkSql = "SELECT id, source_item_id, active_title, created_at FROM yahoo_scraped_products WHERE source_item_id = ?";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->execute([$source_item_id]);
        $existing = $checkStmt->fetch();
        
        if ($existing) {
            // 重複回避のため新しいIDで保存
            $originalId = $source_item_id;
            $timestamp = date('YmdHis');
            $source_item_id = $originalId . '_' . $timestamp;
            
            writeLog("🔄 [既存データ発見] ID: {$existing['id']}, Title: {$existing['active_title']}", 'INFO');
            writeLog("⚡ [重複回避] 新しいIDで保存: {$originalId} → {$source_item_id}", 'WARNING');
        }
        
        writeLog("🔄 [INSERT実行開始] 新規データを挿入します", 'INFO');
        
        // INSERT実行（実際のテーブル構造に合わせて修正）
        $sql = "INSERT INTO yahoo_scraped_products (
            source_item_id, price_jpy, scraped_yahoo_data, active_title,
            active_description, active_price_usd, active_image_url, current_stock,
            status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        
        $params = [
            $source_item_id, $price_jpy, $scraped_yahoo_data, $active_title,
            $active_description, $active_price_usd, $active_image_url, $current_stock, $status
        ];
        
        writeLog("📋 [INSERTパラメータ] " . json_encode([
            'source_item_id' => $source_item_id,
            'price_jpy' => $price_jpy,
            'title_length' => strlen($active_title),
            'description_length' => strlen($active_description),
            'json_length' => strlen($scraped_yahoo_data),
            'status' => $status
        ]), 'DEBUG');
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            $insertId = $pdo->lastInsertId();
            writeLog("✅ [INSERT成功] 新規ID: {$insertId}, source_item_id: {$source_item_id}", 'SUCCESS');
            
            // 保存確認クエリ
            writeLog("🔍 [保存確認] データが正しく保存されたか確認中...", 'INFO');
            $verifySql = "SELECT id, source_item_id, active_title, price_jpy FROM yahoo_scraped_products WHERE id = ?";
            $verifyStmt = $pdo->prepare($verifySql);
            $verifyStmt->execute([$insertId]);
            $saved = $verifyStmt->fetch();
            
            if ($saved) {
                writeLog("✅ [保存確認成功] ID: {$saved['id']}, Title: {$saved['active_title']}, Price: ¥{$saved['price_jpy']}", 'SUCCESS');
                return true;
            } else {
                writeLog("❌ [保存確認失敗] 挿入されたデータが見つかりません", 'ERROR');
                return false;
            }
        } else {
            writeLog("❌ [INSERT失敗] result: false", 'ERROR');
            writeLog("❌ [INSERT失敗詳細] PDO::errorInfo: " . json_encode($stmt->errorInfo()), 'ERROR');
            return false;
        }
        
    } catch (PDOException $e) {
        writeLog("❌ [DB保存PDOエラー] " . $e->getMessage(), 'ERROR');
        writeLog("❌ [DB SQLState] " . $e->getCode(), 'ERROR');
        writeLog("❌ [DB ErrorInfo] " . json_encode($e->errorInfo ?? []), 'ERROR');
        
        // デバッグ情報を出力
        if (isset($source_item_id)) writeLog("🔍 [エラー時データ] source_item_id: {$source_item_id}", 'DEBUG');
        if (isset($active_title)) writeLog("🔍 [エラー時データ] title_length: " . strlen($active_title), 'DEBUG');
        if (isset($active_description)) writeLog("🔍 [エラー時データ] description_length: " . strlen($active_description), 'DEBUG');
        if (isset($scraped_yahoo_data)) writeLog("🔍 [エラー時データ] json_length: " . strlen($scraped_yahoo_data), 'DEBUG');
        
        // エラーの種類を判定
        $errorMessage = $e->getMessage();
        
        if (strpos($errorMessage, 'relation') !== false && strpos($errorMessage, 'does not exist') !== false) {
            writeLog("🚨 [DBテーブル不存在] yahoo_scraped_products テーブルが存在しません", 'ERROR');
        } elseif (strpos($errorMessage, 'duplicate key') !== false) {
            writeLog("🚨 [DB重複キーエラー] 重複した source_item_id です", 'ERROR');
        } elseif (strpos($errorMessage, 'violates not-null') !== false) {
            writeLog("🚨 [DB NULL制約エラー] 必須項目が空です", 'ERROR');
        } elseif (strpos($errorMessage, 'value too long') !== false) {
            writeLog("🚨 [DB文字列長エラー] 文字列が長すぎます", 'ERROR');
        } elseif (strpos($errorMessage, 'invalid input syntax') !== false) {
            writeLog("🚨 [DB構文エラー] データ形式が不正です", 'ERROR');
        } else {
            writeLog("🚨 [DB不明エラー] 詳細: {$errorMessage}", 'ERROR');
        }
        
        return false;
    } catch (Exception $e) {
        writeLog("❌ [DB保存例外] " . $e->getMessage(), 'ERROR');
        return false;
    }
}

// 元の関数を新しい関数で置き換える
if (!function_exists('saveProductToDatabase_Original')) {
    function saveProductToDatabase_Original($product_data) {
        // 元の関数をバックアップとして保持
        return false;
    }
}

// 元の関数を修正版で置き換える
function saveProductToDatabase($product_data) {
    return saveProductToDatabase_Fixed($product_data);
}

writeLog("✅ [関数置き換え完了] saveProductToDatabase を修正版に置き換えました", 'SUCCESS');
?>
