<?php
/**
 * ハイブリッド価格管理対応データベース保存関数
 * Gemini推奨：円価格をマスターデータとし、ドル価格はキャッシュとして管理
 */

// ハイブリッド価格管理対応データベース保存関数
function saveProductToDatabaseHybrid($product_data) {
    try {
        writeLog("🏦 [ハイブリッド保存開始] Gemini推奨ハイブリッド方式でデータベース保存開始", 'INFO');
        
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        writeLog("✅ [接続成功] PostgreSQL接続確立", 'SUCCESS');
        
        // 入力データの検証
        if (!$product_data || !is_array($product_data)) {
            writeLog("❌ [入力データエラー] 無効な商品データ", 'ERROR');
            return ['success' => false, 'error' => '無効な商品データです'];
        }
        
        // データ準備（Gemini推奨：円価格をマスターデータとする）
        $source_item_id = $product_data['item_id'] ?? 'SCRAPED_' . time() . '_' . rand(100, 999);
        $price_jpy = (int)($product_data['current_price'] ?? 0); // マスターデータ（円）
        $active_title = $product_data['title'] ?? 'タイトル不明';
        $active_description = $product_data['description'] ?? '';
        $current_stock = 1;
        $status = 'scraped';
        
        writeLog("💰 [マスターデータ] 円価格: ¥" . number_format($price_jpy), 'INFO');
        
        // 🔴 価格検証（異常価格の検出）
        $price_validation = validatePrice($price_jpy, $active_title, $source_item_id);
        
        if (!$price_validation['valid']) {
            writeLog("🚨 [価格異常検出] " . $price_validation['error'], 'ERROR');
            
            return [
                'success' => false,
                'error' => $price_validation['error'],
                'price_validation' => $price_validation,
                'original_data' => [
                    'source_item_id' => $source_item_id,
                    'title' => $active_title,
                    'price_jpy' => $price_jpy,
                    'source_url' => $product_data['source_url'] ?? ''
                ]
            ];
        }
        
        writeLog("✅ [価格検証通過] 円価格: ¥" . number_format($price_jpy), 'SUCCESS');
        
        // 💱 為替レート取得・キャッシュ価格計算
        $current_rate = getCurrentExchangeRate('JPY', 'USD');
        $cached_price_usd = $price_jpy > 0 ? round($price_jpy / $current_rate, 2) : null;
        
        writeLog("💱 [為替レート] 1ドル = {$current_rate}円", 'INFO');
        writeLog("💰 [キャッシュ価格] $" . number_format($cached_price_usd, 2), 'INFO');
        
        // 🖼️ 画像データの処理・検証
        $image_validation = validateAndProcessImages($product_data['images'] ?? []);
        $active_image_url = $image_validation['primary_image'];
        
        if (!$image_validation['valid']) {
            writeLog("⚠️ [画像警告] " . $image_validation['warning'], 'WARNING');
        } else {
            writeLog("✅ [画像検証] " . $image_validation['image_count'] . "枚の画像を処理", 'SUCCESS');
        }
        
        // 📍 ソース検証（ヤフオクURLの確認）
        $source_url = $product_data['source_url'] ?? '';
        $source_validation = validateSourceUrl($source_url);
        
        if (!$source_validation['valid']) {
            writeLog("⚠️ [ソース警告] " . $source_validation['warning'], 'WARNING');
        }
        
        // JSONデータ構築（ハイブリッド情報付き）
        $scraped_yahoo_data_array = [
            'category' => $product_data['category'] ?? 'Unknown',
            'condition' => $product_data['condition'] ?? 'Used',
            'url' => $source_url,
            'seller_name' => $product_data['seller_info']['name'] ?? 'Unknown',
            'bid_count' => $product_data['auction_info']['bid_count'] ?? 0,
            'end_time' => $product_data['auction_info']['end_time'] ?? '',
            'scraped_at' => date('Y-m-d H:i:s'),
            'scraping_method' => $product_data['scraping_method'] ?? 'unknown',
            'data_quality' => $product_data['data_quality'] ?? null,
            'extraction_success' => $product_data['extraction_success'] ?? null,
            // ハイブリッド価格管理情報
            'price_management' => [
                'master_currency' => 'JPY',
                'cache_currency' => 'USD',
                'exchange_rate_at_scraping' => $current_rate,
                'price_validation' => $price_validation,
                'hybrid_system_version' => '1.0'
            ],
            'validation_info' => [
                'price' => $price_validation,
                'image' => $image_validation,
                'source' => $source_validation
            ],
            'all_images' => $product_data['images'] ?? []
        ];
        
        $scraped_yahoo_data = json_encode($scraped_yahoo_data_array, JSON_UNESCAPED_UNICODE);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            writeLog("❌ [JSONエラー] JSONエンコード失敗: " . json_last_error_msg(), 'ERROR');
            return ['success' => false, 'error' => 'データエンコードエラー'];
        }
        
        // ユニーク制約確認
        $constraintCheckSql = "SELECT constraint_name FROM information_schema.table_constraints WHERE table_name = 'yahoo_scraped_products' AND constraint_type = 'UNIQUE'";
        $constraintStmt = $pdo->query($constraintCheckSql);
        $constraints = $constraintStmt->fetchAll(PDO::FETCH_COLUMN);
        $has_unique_constraint = !empty($constraints);
        
        // UPSERT実行（ハイブリッド価格管理対応）
        writeLog("🔄 [UPSERT実行] ハイブリッド価格管理データベース保存開始", 'INFO');
        
        if ($has_unique_constraint) {
            // ユニーク制約がある場合：ON CONFLICT使用
            $sql = "INSERT INTO yahoo_scraped_products (
                source_item_id, price_jpy, scraped_yahoo_data, active_title,
                active_description, active_image_url, current_stock, status,
                cached_price_usd, cache_rate, cache_updated_at,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON CONFLICT (source_item_id) DO UPDATE SET
                active_title = EXCLUDED.active_title,
                price_jpy = EXCLUDED.price_jpy,
                scraped_yahoo_data = EXCLUDED.scraped_yahoo_data,
                active_description = EXCLUDED.active_description,
                active_image_url = EXCLUDED.active_image_url,
                current_stock = EXCLUDED.current_stock,
                status = EXCLUDED.status,
                cached_price_usd = EXCLUDED.cached_price_usd,
                cache_rate = EXCLUDED.cache_rate,
                cache_updated_at = EXCLUDED.cache_updated_at,
                updated_at = CURRENT_TIMESTAMP";
        } else {
            // ユニーク制約がない場合：通常のINSERT
            $sql = "INSERT INTO yahoo_scraped_products (
                source_item_id, price_jpy, scraped_yahoo_data, active_title,
                active_description, active_image_url, current_stock, status,
                cached_price_usd, cache_rate, cache_updated_at,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        }
        
        $params = [
            $source_item_id, $price_jpy, $scraped_yahoo_data, $active_title,
            $active_description, $active_image_url, $current_stock, $status,
            $cached_price_usd, $current_rate
        ];
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            // 保存確認
            $verifySql = "SELECT id, source_item_id, active_title, price_jpy, cached_price_usd, cache_rate, created_at, updated_at FROM yahoo_scraped_products WHERE source_item_id = ?";
            $verifyStmt = $pdo->prepare($verifySql);
            $verifyStmt->execute([$source_item_id]);
            $saved = $verifyStmt->fetch();
            
            if ($saved) {
                $action = ($saved['created_at'] === $saved['updated_at']) ? 'INSERT（新規作成）' : 'UPDATE（既存更新）';
                writeLog("✅ [保存成功] {$action} - ID: {$saved['id']}", 'SUCCESS');
                writeLog("💰 [価格保存] 円: ¥" . number_format($saved['price_jpy']) . ", ドル: $" . number_format($saved['cached_price_usd'], 2) . " (レート: {$saved['cache_rate']})", 'SUCCESS');
                
                return [
                    'success' => true,
                    'action' => $action,
                    'id' => $saved['id'],
                    'source_item_id' => $source_item_id,
                    'price_jpy' => $saved['price_jpy'],
                    'cached_price_usd' => $saved['cached_price_usd'],
                    'exchange_rate' => $saved['cache_rate'],
                    'hybrid_system' => true,
                    'validations' => [
                        'price' => $price_validation,
                        'image' => $image_validation,
                        'source' => $source_validation
                    ]
                ];
            } else {
                writeLog("❌ [保存確認失敗] 保存されたデータが見つかりません", 'ERROR');
                return ['success' => false, 'error' => '保存確認に失敗しました'];
            }
        } else {
            writeLog("❌ [SQL実行失敗] クエリ実行に失敗", 'ERROR');
            return ['success' => false, 'error' => 'SQL実行に失敗しました'];
        }
        
    } catch (PDOException $e) {
        writeLog("❌ [PDOエラー] " . $e->getMessage(), 'ERROR');
        return ['success' => false, 'error' => 'データベースエラー: ' . $e->getMessage()];
    } catch (Exception $e) {
        writeLog("❌ [予期しないエラー] " . $e->getMessage(), 'ERROR');
        return ['success' => false, 'error' => '予期しないエラー: ' . $e->getMessage()];
    }
}

// 為替レート取得関数（price_calculator_api.phpから移植）
function getCurrentExchangeRate($from = 'JPY', $to = 'USD') {
    try {
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $sql = "SELECT rate FROM exchange_rates 
                WHERE currency_from = ? AND currency_to = ? AND is_active = true 
                ORDER BY recorded_at DESC 
                LIMIT 1";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$from, $to]);
        $result = $stmt->fetch();
        
        return $result ? (float)$result['rate'] : 150.0; // デフォルト150円/ドル
    } catch (Exception $e) {
        writeLog("⚠️ [為替レート取得エラー] デフォルトレート使用: " . $e->getMessage(), 'WARNING');
        return 150.0;
    }
}

// 価格検証関数（既存の関数を使用）
function validatePrice($price_jpy, $title, $source_item_id) {
    $validation = [
        'valid' => true,
        'warnings' => [],
        'error' => '',
        'price_range' => 'normal'
    ];
    
    // 価格が0円の場合
    if ($price_jpy == 0) {
        $validation['valid'] = false;
        $validation['error'] = "🚨 重大エラー: 価格が0円です。スクレイピングに失敗している可能性があります。";
        $validation['price_range'] = 'zero';
        return $validation;
    }
    
    // 異常に低い価格（100円未満）
    if ($price_jpy < 100) {
        $validation['valid'] = false;
        $validation['error'] = "🚨 価格異常: ¥{$price_jpy}は異常に低い価格です。データ確認が必要です。";
        $validation['price_range'] = 'too_low';
        return $validation;
    }
    
    // 異常に高い価格（1000万円以上）
    if ($price_jpy > 10000000) {
        $validation['valid'] = false;
        $validation['error'] = "🚨 価格異常: ¥" . number_format($price_jpy) . "は異常に高い価格です。データ確認が必要です。";
        $validation['price_range'] = 'too_high';
        return $validation;
    }
    
    // 警告レベルの価格範囲
    if ($price_jpy < 500) {
        $validation['warnings'][] = "低価格商品: ¥{$price_jpy}";
        $validation['price_range'] = 'low';
    } elseif ($price_jpy > 1000000) {
        $validation['warnings'][] = "高額商品: ¥" . number_format($price_jpy);
        $validation['price_range'] = 'high';
    }
    
    return $validation;
}

// 画像検証・処理関数（既存の関数を使用）
function validateAndProcessImages($images) {
    $validation = [
        'valid' => true,
        'warning' => '',
        'image_count' => 0,
        'primary_image' => 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image',
        'all_images' => []
    ];
    
    if (empty($images) || !is_array($images)) {
        $validation['valid'] = false;
        $validation['warning'] = '画像が取得されていません';
        return $validation;
    }
    
    $valid_images = [];
    foreach ($images as $image_url) {
        if (!empty($image_url) && filter_var($image_url, FILTER_VALIDATE_URL)) {
            $valid_images[] = $image_url;
        }
    }
    
    $validation['image_count'] = count($valid_images);
    $validation['all_images'] = $valid_images;
    
    if (count($valid_images) > 0) {
        $validation['primary_image'] = $valid_images[0];
        $validation['valid'] = true;
    } else {
        $validation['valid'] = false;
        $validation['warning'] = '有効な画像URLが見つかりません';
    }
    
    return $validation;
}

// ソースURL検証関数（既存の関数を使用）
function validateSourceUrl($source_url) {
    $validation = [
        'valid' => true,
        'warning' => '',
        'source_type' => 'unknown'
    ];
    
    if (empty($source_url)) {
        $validation['valid'] = false;
        $validation['warning'] = 'ソースURLが空です';
        return $validation;
    }
    
    if (strpos($source_url, 'auctions.yahoo.co.jp') !== false) {
        $validation['source_type'] = 'ヤフオク';
        $validation['valid'] = true;
    } elseif (strpos($source_url, 'yahoo.co.jp') !== false) {
        $validation['source_type'] = 'Yahoo';
        $validation['warning'] = 'Yahoo（ヤフオク以外）からのデータです';
    } else {
        $validation['valid'] = false;
        $validation['warning'] = 'ヤフオク以外のソースURLです: ' . $source_url;
    }
    
    return $validation;
}

writeLog("✅ [ハイブリッド関数準備完了] saveProductToDatabaseHybrid を定義しました", 'SUCCESS');
?>
