<?php
/**
 * Yahoo オークション Geminiアドバイス実装版パーサー
 * HTMLパーサーベースのJSON抽出 + DOM直接解析フォールバック
 */

/**
 * Geminiアドバイス実装版Yahoo オークション解析
 */
function parseYahooAuctionHTML_GeminiAdvised($html, $url, $item_id) {
    try {
        writeLog("🤖 [Geminiアドバイス版解析開始] Gemini Advised Parser for: {$item_id}", 'INFO');
        
        // DOMDocument初期化
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_use_internal_errors(false);
        
        $xpath = new DOMXPath($dom);
        
        // エラー・警告追跡
        $errors = [];
        $warnings = [];
        
        // 1. HTMLパーサーベースのJSON抽出（Gemini推奨方法）
        $json_data = extractJSONDataGeminiMethod($dom, $xpath, $html, $errors);
        
        // 2. HTML構造ベースのオークション形式判定
        $auction_check = checkAuctionTypeGeminiMethod($xpath, $json_data);
        if ($auction_check['is_auction']) {
            writeLog("🚨 [オークション判定] オークション形式のため処理を中断: " . $auction_check['reason'], 'ERROR');
            
            return [
                'success' => false,
                'error' => 'オークション形式のため処理を中断しました',
                'reason' => $auction_check['reason'],
                'auction_details' => $auction_check['details'],
                'business_policy' => '定額出品のみ取扱 - オークション形式は商用リスクのため完全除外'
            ];
        }
        
        writeLog("✅ [定額出品確認] 定額出品として処理を続行", 'SUCCESS');
        
        // 3. データ抽出（JSON優先 + HTMLフォールバック）
        $extracted_data = extractAllDataGeminiMethod($json_data, $xpath, $errors);
        
        // 4. フィールドごとの個別検証（Gemini推奨デバッグ方法）
        $validation_result = validateDataGeminiMethod($extracted_data, $errors);
        
        if (!$validation_result['is_valid']) {
            writeLog("❌ [データ検証失敗] 必須データ不足: " . implode(', ', $validation_result['missing_fields']), 'ERROR');
            writeLog("🔍 [詳細診断] URL: {$url}, HTMLサイズ: " . strlen($html) . "文字", 'DEBUG');
            
            // 各フィールドの状態をログ出力
            foreach ($extracted_data as $field => $value) {
                $status = empty($value) ? '❌ MISSING' : '✅ OK';
                $display_value = is_null($value) ? 'NULL' : (empty($value) ? 'EMPTY' : substr(strval($value), 0, 50));
                writeLog("🔍 [フィールド状態] {$field}: {$status} - '{$display_value}'", 'DEBUG');
            }
            
            return [
                'success' => false,
                'error' => '必須データが不足しているため処理を中断しました',
                'missing_fields' => $validation_result['missing_fields'],
                'extracted_data' => $extracted_data,
                'debug_info' => [
                    'url' => $url,
                    'html_size' => strlen($html),
                    'json_extraction_success' => !is_null($json_data),
                    'field_details' => $validation_result['field_details']
                ]
            ];
        }
        
        // 5. 成功時のデータ構築
        $product_data = [
            'item_id' => $item_id,
            'title' => $extracted_data['title'],
            'description' => generateDescriptionGemini($extracted_data),
            'current_price' => $extracted_data['price'],
            'immediate_price' => $extracted_data['price'],
            'condition' => $extracted_data['condition'],
            'category' => $extracted_data['category'],
            'brand' => $extracted_data['brand'] ?? null,
            'images' => $extracted_data['images'] ?? [],
            'main_image' => isset($extracted_data['images'][0]) ? $extracted_data['images'][0] : 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image',
            'basic_info' => $extracted_data['basic_info'] ?? [],
            'seller_info' => [
                'name' => 'Yahoo出品者',
                'rating' => 'N/A'
            ],
            'auction_info' => [
                'auction_type' => 'fixed_price',
                'bid_count' => 0,
                'end_time' => null
            ],
            'scraped_at' => date('Y-m-d H:i:s'),
            'source_url' => $url,
            'scraping_method' => 'gemini_advised',
            'data_quality' => 100,
            'errors' => $errors,
            'warnings' => $warnings,
            'validation_status' => 'validated',
            'commercial_grade' => 'A'
        ];
        
        writeLog("✅ [Geminiアドバイス版解析完了] Category: {$extracted_data['category']}, Condition: {$extracted_data['condition']}, Price: ¥{$extracted_data['price']}", 'SUCCESS');
        
        return $product_data;
        
    } catch (Exception $e) {
        writeLog("❌ [Geminiアドバイス版解析例外] " . $e->getMessage(), 'ERROR');
        return false;
    }
}

/**
 * Gemini推奨: HTMLパーサーベースのJSON抽出
 */
function extractJSONDataGeminiMethod($dom, $xpath, $html, &$errors) {
    try {
        writeLog("📊 [Gemini JSON抽出] HTMLパーサーベースでJSON抽出開始", 'INFO');
        
        // 方法1: __NEXT_DATA__を含むscriptタグを特定
        $script_nodes = $xpath->query('//script[contains(text(), "__NEXT_DATA__")]');
        
        if ($script_nodes->length > 0) {
            $script_content = $script_nodes->item(0)->nodeValue;
            
            // JSONデータを抽出
            if (preg_match('/__NEXT_DATA__"\s*=\s*({.*?})(?:\s*<\/script>|$)/s', $script_content, $matches)) {
                $data_json = $matches[1];
                $item_data = json_decode($data_json, true);
                
                if (json_last_error() === JSON_ERROR_NONE) {
                    writeLog("✅ [Gemini JSON抽出] __NEXT_DATA__から成功: " . strlen($data_json) . "文字", 'SUCCESS');
                    return $item_data;
                } else {
                    writeLog("❌ [JSON デコード失敗] " . json_last_error_msg(), 'ERROR');
                }
            }
        }
        
        // 方法2: initialStateを含むscriptタグを特定
        $script_nodes = $xpath->query('//script[contains(text(), "initialState")]');
        
        if ($script_nodes->length > 0) {
            $script_content = $script_nodes->item(0)->nodeValue;
            
            if (preg_match('/"initialState":\s*({.*?})/', $script_content, $matches)) {
                $data_json = $matches[1];
                $item_data = json_decode($data_json, true);
                
                if (json_last_error() === JSON_ERROR_NONE) {
                    writeLog("✅ [Gemini JSON抽出] initialStateから成功: " . strlen($data_json) . "文字", 'SUCCESS');
                    return $item_data;
                } else {
                    writeLog("❌ [JSON デコード失敗] " . json_last_error_msg(), 'ERROR');
                }
            }
        }
        
        // 方法3: フォールバック - 正規表現による全体検索
        if (preg_match('/{"props":.*?"initialState":\s*({.*?})/', $html, $matches)) {
            $data_json = $matches[1];
            $item_data = json_decode($data_json, true);
            
            if (json_last_error() === JSON_ERROR_NONE) {
                writeLog("⚠️ [Gemini JSON抽出] フォールバック正規表現で成功", 'WARNING');
                return $item_data;
            }
        }
        
        $errors[] = 'JSONデータの抽出に失敗しました（全ての方法で失敗）';
        writeLog("❌ [Gemini JSON抽出失敗] 全ての方法でJSONデータを取得できません", 'ERROR');
        return null;
        
    } catch (Exception $e) {
        $errors[] = "JSONデータ抽出中にエラー: " . $e->getMessage();
        writeLog("❌ [Gemini JSON抽出例外] " . $e->getMessage(), 'ERROR');
        return null;
    }
}

/**
 * Gemini推奨: 全データ抽出（JSON優先 + HTMLフォールバック）
 */
function extractAllDataGeminiMethod($json_data, $xpath, &$errors) {
    $extracted_data = [
        'title' => null,
        'price' => null,
        'condition' => null,
        'category' => null,
        'brand' => null,
        'images' => [],
        'basic_info' => []
    ];
    
    // JSON抽出を試行
    if ($json_data) {
        writeLog("🔄 [データ抽出] JSON優先抽出を開始", 'INFO');
        $extracted_data = array_merge($extracted_data, extractFromJSONGemini($json_data, $errors));
    }
    
    // HTMLフォールバック抽出
    writeLog("🔄 [データ抽出] HTMLフォールバック抽出を開始", 'INFO');
    $html_data = extractFromHTMLGemini($xpath, $errors);
    
    // JSON失敗分をHTMLで補完
    foreach ($extracted_data as $key => $value) {
        if (empty($value) && !empty($html_data[$key])) {
            $extracted_data[$key] = $html_data[$key];
            writeLog("🔄 [フォールバック] {$key}をHTMLから補完", 'INFO');
        }
    }
    
    return $extracted_data;
}

/**
 * JSONからのデータ抽出
 */
function extractFromJSONGemini($json_data, &$errors) {
    $data = [];
    
    try {
        if (isset($json_data['item']['detail']['item'])) {
            $item = $json_data['item']['detail']['item'];
            
            // タイトル
            if (isset($item['title'])) {
                $data['title'] = trim($item['title']);
            }
            
            // 価格
            $price_fields = ['bidorbuy', 'price', 'initPrice'];
            foreach ($price_fields as $field) {
                if (isset($item[$field]) && $item[$field] > 0) {
                    $data['price'] = (int)$item[$field];
                    break;
                }
            }
            
            // 商品状態
            if (isset($item['conditionName'])) {
                $condition_map = [
                    '新品、未使用' => 'New',
                    '未使用に近い' => 'Like New',
                    '目立った傷や汚れなし' => 'Excellent',
                    'やや傷や汚れあり' => 'Good',
                    '傷や汚れあり' => 'Fair',
                    '全体的に状態が悪い' => 'Poor',
                    'ジャンク品' => 'For Parts'
                ];
                $data['condition'] = $condition_map[$item['conditionName']] ?? 'Used';
            }
            
            // カテゴリ
            if (isset($item['category']['path'])) {
                $category_path = $item['category']['path'];
                $data['category'] = end($category_path)['name'];
            }
            
            // ブランド
            if (isset($item['brand']['path'])) {
                $brand_path = $item['brand']['path'];
                $data['brand'] = end($brand_path)['name'];
            }
        }
    } catch (Exception $e) {
        $errors[] = "JSON抽出中にエラー: " . $e->getMessage();
    }
    
    return $data;
}

/**
 * Gemini推奨: HTMLからの直接データ抽出
 */
function extractFromHTMLGemini($xpath, &$errors) {
    $data = [];
    
    try {
        // タイトル（Gemini推奨XPath）
        $title_node = $xpath->query('//div[@id="itemTitle"]//h1')->item(0);
        if ($title_node) {
            $data['title'] = trim($title_node->nodeValue);
            writeLog("✅ [HTML抽出] タイトル: " . substr($data['title'], 0, 50) . "...", 'SUCCESS');
        }
        
        // 価格（Gemini推奨XPath）
        $price_node = $xpath->query('//dt[text()="即決"]/following-sibling::dd[1]//span[contains(@class, "kxUAXU")]')->item(0);
        if ($price_node) {
            $price_text = trim($price_node->nodeValue);
            $data['price'] = (int)str_replace(['円', ',', ' '], '', $price_text);
            writeLog("✅ [HTML抽出] 価格: ¥" . $data['price'], 'SUCCESS');
        }
        
        // 商品状態（Gemini推奨XPath）
        $condition_node = $xpath->query('//li[svg[@aria-label="状態"]]//span')->item(0);
        if ($condition_node) {
            $japanese_condition = trim($condition_node->nodeValue);
            $condition_map = [
                '新品、未使用' => 'New',
                '未使用に近い' => 'Like New',
                '目立った傷や汚れなし' => 'Excellent',
                'やや傷や汚れあり' => 'Good',
                '傷や汚れあり' => 'Fair',
                '全体的に状態が悪い' => 'Poor',
                'ジャンク品' => 'For Parts'
            ];
            $data['condition'] = $condition_map[$japanese_condition] ?? 'Used';
            writeLog("✅ [HTML抽出] 商品状態: {$japanese_condition} -> {$data['condition']}", 'SUCCESS');
        }
        
        // カテゴリ（Gemini推奨XPath）
        $category_nodes = $xpath->query('//dt[text()="カテゴリ"]/following-sibling::dd[1]//a');
        if ($category_nodes->length > 0) {
            $category_path = [];
            foreach ($category_nodes as $node) {
                $category_path[] = trim($node->nodeValue);
            }
            $data['category'] = end($category_path); // 最終カテゴリのみ
            writeLog("✅ [HTML抽出] カテゴリ: " . $data['category'], 'SUCCESS');
        }
        
    } catch (Exception $e) {
        $errors[] = "HTML抽出中にエラー: " . $e->getMessage();
    }
    
    return $data;
}

/**
 * Gemini推奨: オークション形式判定
 */
function checkAuctionTypeGeminiMethod($xpath, $json_data) {
    $is_auction = false;
    $reasons = [];
    $details = [];
    
    try {
        // HTML構造による判定
        $current_price_dt = $xpath->query('//dt[text()="現在"]');
        $immediate_price_dt = $xpath->query('//dt[text()="即決"]');
        $bid_button = $xpath->query('//button[contains(text(), "入札")]');
        $buy_now_button = $xpath->query('//button[contains(text(), "今すぐ落札")]');
        
        if ($current_price_dt->length === 0 && $immediate_price_dt->length > 0 && $buy_now_button->length > 0) {
            // 定額出品の確実な判定
            $is_auction = false;
            $reasons[] = "定額出品（即決価格のみ + 今すぐ落札ボタン）";
            $details['fixed_price_confirmed'] = true;
        } else {
            // その他はオークション扱い
            $is_auction = true;
            $reasons[] = "オークション形式の可能性";
        }
        
        $reason_text = implode(', ', $reasons);
        writeLog("🎯 [Gemini オークション判定] 結果: " . ($is_auction ? 'オークション' : '定額出品') . " ({$reason_text})", $is_auction ? 'WARNING' : 'SUCCESS');
        
        return [
            'is_auction' => $is_auction,
            'reason' => $reason_text,
            'details' => $details
        ];
        
    } catch (Exception $e) {
        writeLog("❌ [Gemini オークション判定エラー] " . $e->getMessage(), 'ERROR');
        return [
            'is_auction' => true,
            'reason' => 'エラーのため安全策としてオークション扱い',
            'details' => ['error' => $e->getMessage()]
        ];
    }
}

/**
 * Gemini推奨: フィールドごとの個別検証
 */
function validateDataGeminiMethod($extracted_data, &$errors) {
    $required_fields = ['title', 'price', 'condition', 'category'];
    $missing_fields = [];
    $field_details = [];
    
    foreach ($required_fields as $field) {
        $value = $extracted_data[$field] ?? null;
        $is_valid = !empty($value);
        
        $field_details[$field] = [
            'value' => $value,
            'is_valid' => $is_valid,
            'type' => gettype($value),
            'length' => is_string($value) ? strlen($value) : null
        ];
        
        if (!$is_valid) {
            $missing_fields[] = $field;
        }
    }
    
    return [
        'is_valid' => empty($missing_fields),
        'missing_fields' => $missing_fields,
        'field_details' => $field_details
    ];
}

/**
 * 説明文生成
 */
function generateDescriptionGemini($extracted_data) {
    $parts = [];
    
    if (!empty($extracted_data['title'])) $parts[] = $extracted_data['title'];
    if (!empty($extracted_data['category'])) $parts[] = "カテゴリ: {$extracted_data['category']}";
    if (!empty($extracted_data['condition'])) $parts[] = "状態: {$extracted_data['condition']}";
    if (!empty($extracted_data['brand'])) $parts[] = "ブランド: {$extracted_data['brand']}";
    
    return implode(" | ", $parts);
}

echo "✅ Gemini Advised Yahoo Auction Parser 読み込み完了\n";
?>
