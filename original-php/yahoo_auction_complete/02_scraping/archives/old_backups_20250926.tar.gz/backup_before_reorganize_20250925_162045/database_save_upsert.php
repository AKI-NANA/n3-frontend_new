<?php
/**
 * UPSERT対応データベース保存関数
 * Gemini推奨のON CONFLICT DO UPDATE方式を実装
 */

// UPSERT対応データベース保存関数（Gemini推奨）
function saveProductToDatabaseUpsert($product_data) {
    try {
        writeLog("🚀 [UPSERT保存開始] UPSERT方式でデータベース保存開始", 'INFO');
        
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        writeLog("✅ [UPSERT接続成功] PDO接続確立", 'SUCCESS');
        
        // 入力データの検証
        if (!$product_data || !is_array($product_data)) {
            writeLog("❌ [UPSERT保存エラー] 無効な商品データ", 'ERROR');
            return false;
        }
        
        // スクレイピング直後のデータ確認（Gemini推奨デバッグ手順1）
        writeLog("🔍 [UPSERT DEBUG 1] スクレイピング直後データ: " . json_encode($product_data, JSON_UNESCAPED_UNICODE), 'DEBUG');
        
        // データ準備（元のsource_item_idを保持 - Gemini推奨）
        $source_item_id = $product_data['item_id'] ?? 'SCRAPED_' . time() . '_' . rand(100, 999);
        
        // ⚠️ 重要：タイムスタンプ付きIDは生成しない（Gemini指摘通り）
        // $source_item_id = $originalId . '_' . $timestamp; // この行は削除
        
        $price_jpy = (int)($product_data['current_price'] ?? 0);
        $active_title = $product_data['title'] ?? 'タイトル不明';
        $active_description = $product_data['description'] ?? '';
        $active_price_usd = $price_jpy > 0 ? round($price_jpy / 150, 2) : null;
        $active_image_url = (!empty($product_data['images']) && isset($product_data['images'][0])) 
            ? $product_data['images'][0] 
            : 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image';
        $current_stock = 1;
        $status = 'scraped';
        
        // JSONデータ構築
        $scraped_yahoo_data_array = [
            'category' => $product_data['category'] ?? 'Unknown',
            'condition' => $product_data['condition'] ?? 'Used',
            'url' => $product_data['source_url'] ?? '',
            'seller_name' => $product_data['seller_info']['name'] ?? 'Unknown',
            'bid_count' => $product_data['auction_info']['bid_count'] ?? 0,
            'end_time' => $product_data['auction_info']['end_time'] ?? '',
            'scraped_at' => date('Y-m-d H:i:s'),
            'scraping_method' => $product_data['scraping_method'] ?? 'unknown',
            'data_quality' => $product_data['data_quality'] ?? null,
            'extraction_success' => $product_data['extraction_success'] ?? null
        ];
        
        $scraped_yahoo_data = json_encode($scraped_yahoo_data_array, JSON_UNESCAPED_UNICODE);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            writeLog("❌ [UPSERT JSONエラー] JSONエンコード失敗: " . json_last_error_msg(), 'ERROR');
            $scraped_yahoo_data = json_encode([
                'error' => 'JSON encoding failed',
                'scraped_at' => date('Y-m-d H:i:s'),
                'scraping_method' => $product_data['scraping_method'] ?? 'unknown'
            ], JSON_UNESCAPED_UNICODE);
        }
        
        // データベース保存直前のデータ確認（Gemini推奨デバッグ手順2）
        $debug_data = [
            'source_item_id' => $source_item_id,
            'active_title' => $active_title,
            'price_jpy' => $price_jpy,
            'title_length' => strlen($active_title),
            'json_length' => strlen($scraped_yahoo_data)
        ];
        writeLog("🔍 [UPSERT DEBUG 2] DB保存直前データ: " . json_encode($debug_data, JSON_UNESCAPED_UNICODE), 'DEBUG');
        
        writeLog("📝 [UPSERT データ準備完了] source_item_id: {$source_item_id}, title: {$active_title}, price: ¥{$price_jpy}", 'INFO');
        
        // UPSERT実行（Gemini推奨のON CONFLICT DO UPDATE）
        writeLog("🔄 [UPSERT実行開始] ON CONFLICT DO UPDATE方式", 'INFO');
        
        $sql = "INSERT INTO yahoo_scraped_products (
            source_item_id, price_jpy, scraped_yahoo_data, active_title,
            active_description, active_price_usd, active_image_url, current_stock,
            status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT (source_item_id) DO UPDATE SET
            active_title = EXCLUDED.active_title,
            price_jpy = EXCLUDED.price_jpy,
            scraped_yahoo_data = EXCLUDED.scraped_yahoo_data,
            active_description = EXCLUDED.active_description,
            active_price_usd = EXCLUDED.active_price_usd,
            active_image_url = EXCLUDED.active_image_url,
            current_stock = EXCLUDED.current_stock,
            status = EXCLUDED.status,
            updated_at = CURRENT_TIMESTAMP";
        
        $params = [
            $source_item_id, $price_jpy, $scraped_yahoo_data, $active_title,
            $active_description, $active_price_usd, $active_image_url, $current_stock, $status
        ];
        
        writeLog("📋 [UPSERT パラメータ] " . json_encode($debug_data), 'DEBUG');
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            // UPSERT後のデータ確認
            $verifySql = "SELECT id, source_item_id, active_title, price_jpy, created_at, updated_at FROM yahoo_scraped_products WHERE source_item_id = ?";
            $verifyStmt = $pdo->prepare($verifySql);
            $verifyStmt->execute([$source_item_id]);
            $saved = $verifyStmt->fetch();
            
            if ($saved) {
                $action = ($saved['created_at'] === $saved['updated_at']) ? 'INSERT（新規作成）' : 'UPDATE（既存更新）';
                writeLog("✅ [UPSERT成功] {$action} - ID: {$saved['id']}, Title: {$saved['active_title']}, Price: ¥{$saved['price_jpy']}", 'SUCCESS');
                writeLog("📅 [UPSERT タイムスタンプ] 作成: {$saved['created_at']}, 更新: {$saved['updated_at']}", 'INFO');
                
                // Gemini推奨デバッグ手順3: データベース直接確認ログ
                writeLog("🔍 [UPSERT DEBUG 3] DB保存後確認: " . json_encode($saved, JSON_UNESCAPED_UNICODE), 'DEBUG');
                
                return true;
            } else {
                writeLog("❌ [UPSERT確認失敗] 保存されたデータが見つかりません", 'ERROR');
                return false;
            }
        } else {
            writeLog("❌ [UPSERT失敗] result: false", 'ERROR');
            writeLog("❌ [UPSERT失敗詳細] PDO::errorInfo: " . json_encode($stmt->errorInfo()), 'ERROR');
            return false;
        }
        
    } catch (PDOException $e) {
        writeLog("❌ [UPSERT PDOエラー] " . $e->getMessage(), 'ERROR');
        writeLog("❌ [UPSERT SQLState] " . $e->getCode(), 'ERROR');
        writeLog("❌ [UPSERT ErrorInfo] " . json_encode($e->errorInfo ?? []), 'ERROR');
        
        // 制約エラーの場合の詳細ログ
        if (strpos($e->getMessage(), 'unique_source_item_id') !== false) {
            writeLog("🚨 [UPSERT制約エラー] source_item_id のユニーク制約違反です", 'ERROR');
            writeLog("💡 [UPSERT対処法] database_upsert_setup.php を実行してテーブル構造を確認してください", 'INFO');
        }
        
        return false;
    } catch (Exception $e) {
        writeLog("❌ [UPSERT例外] " . $e->getMessage(), 'ERROR');
        return false;
    }
}

writeLog("✅ [UPSERT関数準備完了] saveProductToDatabaseUpsert を定義しました", 'SUCCESS');
?>
