<?php
/**
 * Yahoo オークション スクレイピング デバッグテスト
 * 必須データ不足エラーの詳細診断
 */

header('Content-Type: text/html; charset=UTF-8');
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h1>🔍 Yahoo オークション スクレイピング デバッグテスト</h1>\n";
echo "<pre>\n";

// 基本設定の読み込み
$base_dir = dirname(__FILE__);
require_once $base_dir . '/includes.php';

$test_url = "https://auctions.yahoo.co.jp/jp/auction/l1200404917";
$item_id = "l1200404917";

echo "📋 [デバッグテスト開始] URL: {$test_url}\n";
echo "================================================================================\n\n";

try {
    // 1. HTML取得テスト
    echo "📡 [1. HTML取得テスト]\n";
    echo "----------------------------------------\n";
    
    $html_content = fetchYahooAuctionHTML($test_url);
    
    if ($html_content) {
        echo "✅ HTML取得成功: " . strlen($html_content) . "文字\n\n";
        
        // 2. HTML構造ベースパーサーの直接呼び出し
        echo "🔧 [2. HTML構造ベースパーサー直接テスト]\n";
        echo "----------------------------------------\n";
        
        // パーサーファイルを直接読み込み
        if (file_exists($base_dir . '/yahoo_parser_html_structure.php')) {
            require_once $base_dir . '/yahoo_parser_html_structure.php';
            echo "✅ HTML構造ベースパーサー読み込み完了\n";
        } else {
            echo "❌ パーサーファイルが見つかりません\n";
            exit;
        }
        
        // 3. パーサー実行
        echo "\n🚀 [3. パーサー実行]\n";
        echo "----------------------------------------\n";
        
        $product_data = parseYahooAuctionHTML_HTMLStructureBased($html_content, $test_url, $item_id);
        
        // 4. 結果の詳細表示
        echo "\n📊 [4. 解析結果詳細]\n";
        echo "----------------------------------------\n";
        
        if ($product_data === false) {
            echo "❌ パーサー実行時にエラーが発生しました\n";
        } elseif (is_array($product_data) && isset($product_data['success']) && $product_data['success'] === false) {
            echo "🚫 パーサーによる処理拒否:\n";
            echo "   理由: " . ($product_data['reason'] ?? 'unknown') . "\n";
            echo "   エラー: " . ($product_data['error'] ?? 'unknown') . "\n";
            
            if (isset($product_data['missing_fields'])) {
                echo "   不足フィールド: " . implode(', ', $product_data['missing_fields']) . "\n";
            }
            
            if (isset($product_data['extracted_data'])) {
                echo "\n📋 抽出されたデータ:\n";
                foreach ($product_data['extracted_data'] as $key => $value) {
                    $display_value = $value ?? 'NULL';
                    $status = $value ? '✅' : '❌';
                    echo "   {$status} {$key}: {$display_value}\n";
                }
            }
        } elseif (is_array($product_data)) {
            echo "✅ パーサー実行成功:\n";
            echo "   Grade: " . ($product_data['commercial_grade'] ?? 'N/A') . "\n";
            echo "   Quality: " . ($product_data['data_quality'] ?? 'N/A') . "%\n";
            echo "   Category: " . ($product_data['category'] ?? 'N/A') . "\n";
            echo "   Condition: " . ($product_data['condition'] ?? 'N/A') . "\n";
            echo "   Price: ¥" . ($product_data['current_price'] ?? 'N/A') . "\n";
            echo "   Title: " . (isset($product_data['title']) ? substr($product_data['title'], 0, 50) . '...' : 'N/A') . "\n";
        } else {
            echo "❌ 予期しない戻り値の型: " . gettype($product_data) . "\n";
            var_dump($product_data);
        }
        
        // 5. ログファイルの内容表示
        echo "\n📝 [5. 最新ログエントリ]\n";
        echo "----------------------------------------\n";
        
        $log_file = $base_dir . '/logs/system.log';
        if (file_exists($log_file)) {
            $log_lines = file($log_file, FILE_IGNORE_NEW_LINES);
            $recent_logs = array_slice($log_lines, -10); // 最後の10行
            
            foreach ($recent_logs as $line) {
                echo $line . "\n";
            }
        } else {
            echo "❌ ログファイルが見つかりません: {$log_file}\n";
        }
        
    } else {
        echo "❌ HTML取得に失敗しました\n";
    }
    
} catch (Exception $e) {
    echo "❌ [例外発生] " . $e->getMessage() . "\n";
    echo "   ファイル: " . $e->getFile() . "\n";
    echo "   行番号: " . $e->getLine() . "\n";
}

echo "\n================================================================================\n";
echo "📋 [デバッグテスト完了]\n";
echo "</pre>\n";
?>
