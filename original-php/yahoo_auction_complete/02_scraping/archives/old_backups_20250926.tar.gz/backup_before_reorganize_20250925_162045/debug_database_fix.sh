#!/bin/bash

# データベース保存エラー修正スクリプト

echo "🔧 データベース保存エラー修正スクリプト"
echo "==============================="

# 1. PostgreSQL サービス確認
echo "1. PostgreSQL サービス確認..."
if command -v brew >/dev/null 2>&1; then
    brew services list | grep postgres
else
    sudo systemctl status postgresql
fi

# 2. データベース接続テスト
echo "2. データベース接続テスト..."
psql -h localhost -U postgres -d nagano3_db -c "SELECT version();" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ データベース接続成功"
else
    echo "❌ データベース接続失敗"
    echo "対処法: PostgreSQLサービスを起動してください"
    echo "brew services start postgresql"
fi

# 3. テーブル存在確認
echo "3. テーブル存在確認..."
psql -h localhost -U postgres -d nagano3_db -c "SELECT COUNT(*) FROM yahoo_scraped_products;" 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ yahoo_scraped_products テーブル存在"
else
    echo "❌ yahoo_scraped_products テーブル不存在"
    echo "対処法: database_diagnosis.php を実行してテーブルを作成"
fi

# 4. ファイル権限確認
echo "4. ファイル権限確認..."
echo "scraping.php: $(ls -la scraping.php | awk '{print $1}')"
echo "database_diagnosis.php: $(ls -la database_diagnosis.php 2>/dev/null | awk '{print $1}')"

# 5. ログファイル確認
echo "5. 最新ログ確認..."
if [ -f "scraping_logs.txt" ]; then
    echo "最新5行のログ:"
    tail -5 scraping_logs.txt
else
    echo "⚠️ ログファイルが見つかりません"
fi

echo ""
echo "🎯 次のステップ:"
echo "1. http://localhost:8000/new_structure/02_scraping/debug_database_save.php"
echo "2. http://localhost:8000/new_structure/02_scraping/database_diagnosis.php"
echo "3. http://localhost:8000/new_structure/02_scraping/scraping.php"
