<?php
/**
 * editing.php用ハイブリッド価格表示修正パッチ
 * 円価格を主要表示、ドル価格は補助表示に修正
 */

echo "<h1>📝 editing.php ハイブリッド価格表示修正</h1>";
echo "<p>editing.phpの価格表示を円価格優先に修正します</p>";

// editing.phpの修正内容
$editing_php_path = '../05_editing/editing.php';

if (file_exists($editing_php_path)) {
    echo "<h2>1. editing.php バックアップ作成</h2>";
    
    // バックアップ作成
    $backup_path = '../05_editing/editing_backup_' . date('Ymd_His') . '.php';
    if (copy($editing_php_path, $backup_path)) {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ バックアップ作成完了: {$backup_path}</div>";
    } else {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ バックアップ作成失敗</div>";
    }
    
    echo "<h2>2. ハイブリッド価格表示修正コード</h2>";
    echo "<p>以下のコードをediting.phpの該当箇所に適用してください：</p>";
    
    // 修正コード1: データ取得SQL
    echo "<h3>🔧 修正1: データ取得SQL（ハイブリッド価格対応）</h3>";
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<pre style='font-size: 0.9em; overflow-x: auto;'>";
    echo htmlspecialchars('
// ハイブリッド価格管理対応データ取得クエリ
$sql = "SELECT 
            id,
            source_item_id as item_id,
            COALESCE(active_title, \'タイトルなし\') as title,
            price_jpy as price,  -- 円価格を主要価格として使用
            cached_price_usd as price_usd,  -- キャッシュUSD価格
            price_jpy as current_price,  -- 表示用に円価格を使用
            COALESCE((scraped_yahoo_data->>\'category\')::text, category, \'N/A\') as category_name,
            COALESCE((scraped_yahoo_data->>\'condition\')::text, condition_name, \'N/A\') as condition_name,
            COALESCE(active_image_url, \'https://placehold.co/150x150/725CAD/FFFFFF/png?text=No+Image\') as picture_url,
            (scraped_yahoo_data->>\'url\')::text as source_url,
            updated_at,
            CASE 
                WHEN (scraped_yahoo_data->>\'url\')::text LIKE \'%auctions.yahoo.co.jp%\' THEN \'ヤフオク\'
                WHEN (scraped_yahoo_data->>\'url\')::text LIKE \'%yahoo.co.jp%\' THEN \'Yahoo\'
                ELSE \'Unknown\'
            END as platform,
            sku as master_sku,
            CASE 
                WHEN ebay_item_id IS NULL OR ebay_item_id = \'\' THEN \'not_listed\'
                ELSE \'listed\'
            END as listing_status,
            status,
            current_stock,
            ebay_item_id,
            cache_rate,
            cache_updated_at
        FROM {$actualTable} 
        {$whereClause} 
        ORDER BY updated_at DESC, id DESC 
        LIMIT ? OFFSET ?";
    ');
    echo "</pre>";
    echo "</div>";
    
    // 修正コード2: JavaScript価格表示
    echo "<h3>🔧 修正2: JavaScript価格表示関数</h3>";
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<pre style='font-size: 0.9em; overflow-x: auto;'>";
    echo htmlspecialchars('
// ハイブリッド価格表示関数（JavaScript）
function formatHybridPrice(priceJpy, priceUsd, cacheRate) {
    const jpyFormatted = priceJpy ? `¥${parseInt(priceJpy).toLocaleString()}` : "¥0";
    const usdFormatted = priceUsd ? `$${parseFloat(priceUsd).toFixed(2)}` : "$0.00";
    const rateInfo = cacheRate ? `(1$ = ${cacheRate}円)` : "";
    
    return `
        <div class="hybrid-price-display">
            <div class="price-primary">${jpyFormatted}</div>
            <div class="price-secondary">${usdFormatted} ${rateInfo}</div>
        </div>
    `;
}

// テーブル行生成時の価格表示
function createTableRow(product) {
    return `
        <tr>
            <td><input type="checkbox" class="product-checkbox" value="${product.id}"></td>
            <td><img src="${product.picture_url}" class="product-thumbnail" width="60" height="60" alt="商品画像"></td>
            <td>${product.item_id}</td>
            <td>${product.title}</td>
            <td>${formatHybridPrice(product.price, product.price_usd, product.cache_rate)}</td>
            <td>${product.category_name}</td>
            <td>${product.condition_name}</td>
            <td><span class="source-badge source-yahoo">${product.platform}</span></td>
            <td>${product.updated_at}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-sm btn-info" onclick="viewProduct(\'${product.item_id}\')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-warning" onclick="editProduct(\'${product.item_id}\')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteProduct(\'${product.id}\')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `;
}
    ');
    echo "</pre>";
    echo "</div>";
    
    // 修正コード3: CSS
    echo "<h3>🔧 修正3: ハイブリッド価格表示CSS</h3>";
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0;'>";
    echo "<pre style='font-size: 0.9em; overflow-x: auto;'>";
    echo htmlspecialchars('
/* ハイブリッド価格表示CSS */
.hybrid-price-display {
    text-align: center;
    line-height: 1.2;
}

.price-primary {
    font-weight: bold;
    font-size: 1.1em;
    color: #2e8b57;  /* 緑色 - 円価格 */
    margin-bottom: 2px;
}

.price-secondary {
    font-size: 0.8em;
    color: #4682b4;  /* 青色 - USD価格 */
    font-style: italic;
}

/* ソースバッジ修正 */
.source-badge.source-yahoo { 
    background: #0B1D51; 
    color: white;
}

.source-badge.source-ヤフオク { 
    background: #ff6600; 
    color: white;
}
    ');
    echo "</pre>";
    echo "</div>";
    
    echo "<h2>3. 自動修正スクリプト実行</h2>";
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
    echo "<p><strong>手動修正が必要な箇所:</strong></p>";
    echo "<ol>";
    echo "<li><strong>getScrapedProductsData関数</strong> - SQL文を上記の修正版に置き換え</li>";
    echo "<li><strong>getAllProductsData関数</strong> - 同様にSQL文を修正</li>";
    echo "<li><strong>HTMLテンプレート</strong> - 価格カラムの表示形式を修正</li>";
    echo "<li><strong>JavaScript関数</strong> - 価格表示関数を追加</li>";
    echo "<li><strong>CSS</strong> - ハイブリッド価格表示スタイルを追加</li>";
    echo "</ol>";
    echo "</div>";
    
} else {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ editing.php が見つかりません: {$editing_php_path}</div>";
}

// 4. 上書き問題の確認
echo "<h2>4. 上書き問題の確認</h2>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 重複データ確認
    $duplicateSql = "SELECT source_item_id, COUNT(*) as count, 
                            array_agg(id ORDER BY created_at DESC) as ids,
                            array_agg(created_at ORDER BY created_at DESC) as dates
                     FROM yahoo_scraped_products 
                     WHERE source_item_id IS NOT NULL 
                     GROUP BY source_item_id 
                     HAVING COUNT(*) > 1 
                     ORDER BY count DESC 
                     LIMIT 10";
    
    $duplicateStmt = $pdo->query($duplicateSql);
    $duplicates = $duplicateStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($duplicates)) {
        echo "<div style='color: orange; padding: 10px; background: #fff3cd;'>⚠️ 重複データが見つかりました:</div>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
        echo "<tr><th>source_item_id</th><th>重複数</th><th>データベースID</th><th>作成日時</th></tr>";
        
        foreach ($duplicates as $duplicate) {
            $ids = json_decode($duplicate['ids']);
            $dates = json_decode($duplicate['dates']);
            
            echo "<tr>";
            echo "<td>{$duplicate['source_item_id']}</td>";
            echo "<td>{$duplicate['count']}</td>";
            echo "<td>" . implode(', ', $ids) . "</td>";
            echo "<td>" . implode('<br>', $dates) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        echo "<h3>重複データクリーンアップ</h3>";
        $cleanupSql = "DELETE FROM yahoo_scraped_products 
                       WHERE id NOT IN (
                           SELECT DISTINCT ON (source_item_id) id 
                           FROM yahoo_scraped_products 
                           ORDER BY source_item_id, updated_at DESC
                       )";
        
        $cleanupResult = $pdo->exec($cleanupSql);
        echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>🗑️ {$cleanupResult}件の重複データを削除しました</div>";
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ 重複データは見つかりませんでした</div>";
    }
    
    // UNIQUE制約確認
    $constraintSql = "SELECT constraint_name FROM information_schema.table_constraints 
                      WHERE table_name = 'yahoo_scraped_products' AND constraint_type = 'UNIQUE'";
    $constraintStmt = $pdo->query($constraintSql);
    $constraints = $constraintStmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($constraints)) {
        echo "<div style='color: orange; padding: 10px; background: #fff3cd;'>⚠️ UNIQUE制約が設定されていません</div>";
        echo "<h3>UNIQUE制約追加</h3>";
        
        try {
            $uniqueSql = "ALTER TABLE yahoo_scraped_products ADD CONSTRAINT unique_source_item_id UNIQUE (source_item_id)";
            $pdo->exec($uniqueSql);
            echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ source_item_id にUNIQUE制約を追加しました</div>";
        } catch (PDOException $e) {
            echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ UNIQUE制約追加エラー: " . $e->getMessage() . "</div>";
        }
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ UNIQUE制約が設定されています: " . implode(', ', $constraints) . "</div>";
    }
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ 重複確認エラー: " . $e->getMessage() . "</div>";
}

echo "<hr>";
echo "<h2>5. 次のアクション</h2>";
echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
echo "<ol>";
echo "<li><strong>editing.php修正</strong> - 上記コードを適用</li>";
echo "<li><strong>ハイブリッドシステムセットアップ実行</strong></li>";
echo "<li><strong>同一商品での再スクレイピングテスト</strong></li>";
echo "<li><strong>価格表示確認</strong> - 円価格優先、ヤフオク表示</li>";
echo "</ol>";
echo "</div>";

echo "<p><a href='hybrid_price_system_setup.php' class='btn' style='background: #007bff; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>ハイブリッドシステムセットアップ</a>";
echo "<a href='scraping.php' class='btn' style='background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px; margin-right: 10px;'>スクレイピングテスト</a>";
echo "<a href='../05_editing/editing.php' class='btn' style='background: #6f42c1; color: white; padding: 10px 15px; text-decoration: none; border-radius: 5px;'>編集画面確認</a></p>";
?>
