<?php
/**
 * データベース構造修正・UPSERT対応（SQL修正版）
 */

echo "<h1>🔧 データベーステーブル修正 - SQL修正版</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. テーブル存在確認
    echo "<h2>1. テーブル存在確認</h2>";
    $tableCheckSql = "SELECT table_name FROM information_schema.tables WHERE table_name = 'yahoo_scraped_products'";
    $tableStmt = $pdo->query($tableCheckSql);
    $table = $tableStmt->fetch();
    
    if ($table) {
        echo "<div style='color: green; padding: 10px;'>✅ yahoo_scraped_products テーブルが存在します</div>";
    } else {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ yahoo_scraped_products テーブルが存在しません</div>";
        exit;
    }
    
    // 2. 現在のテーブル構造確認
    echo "<h2>2. 現在のテーブル構造確認</h2>";
    $sql = "SELECT column_name, data_type, is_nullable, column_default 
            FROM information_schema.columns 
            WHERE table_name = 'yahoo_scraped_products' 
            ORDER BY ordinal_position";
    
    $stmt = $pdo->query($sql);
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>カラム名</th><th>データ型</th><th>NULL許可</th><th>デフォルト値</th></tr>";
    
    $has_source_item_id = false;
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>{$column['column_name']}</td>";
        echo "<td>{$column['data_type']}</td>";
        echo "<td>{$column['is_nullable']}</td>";
        echo "<td>" . ($column['column_default'] ?: 'なし') . "</td>";
        echo "</tr>";
        
        if ($column['column_name'] === 'source_item_id') {
            $has_source_item_id = true;
        }
    }
    echo "</table>";
    
    if (!$has_source_item_id) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ source_item_id カラムが存在しません</div>";
        
        // source_item_id カラムを追加
        echo "<h3>source_item_id カラム追加</h3>";
        $addColumnSql = "ALTER TABLE yahoo_scraped_products ADD COLUMN source_item_id VARCHAR(255)";
        $pdo->exec($addColumnSql);
        echo "<div style='color: green; padding: 10px;'>✅ source_item_id カラムを追加しました</div>";
    }
    
    // 3. 制約確認（修正版クエリ）
    echo "<h2>3. 制約確認</h2>";
    $constraintSql = "SELECT tc.constraint_name, tc.constraint_type, kcu.column_name 
                      FROM information_schema.table_constraints tc
                      LEFT JOIN information_schema.key_column_usage kcu 
                      ON tc.constraint_name = kcu.constraint_name
                      WHERE tc.table_name = 'yahoo_scraped_products'";
    
    $constraintStmt = $pdo->query($constraintSql);
    $constraints = $constraintStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($constraints)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>制約名</th><th>制約タイプ</th><th>カラム名</th></tr>";
        
        $has_unique_constraint = false;
        foreach ($constraints as $constraint) {
            echo "<tr>";
            echo "<td>{$constraint['constraint_name']}</td>";
            echo "<td>{$constraint['constraint_type']}</td>";
            echo "<td>" . ($constraint['column_name'] ?: 'N/A') . "</td>";
            echo "</tr>";
            
            if ($constraint['constraint_type'] === 'UNIQUE' && $constraint['column_name'] === 'source_item_id') {
                $has_unique_constraint = true;
            }
        }
        echo "</table>";
    } else {
        echo "<div style='color: orange; padding: 10px;'>📊 制約が見つかりませんでした</div>";
        $has_unique_constraint = false;
    }
    
    // 4. 重複データ確認
    echo "<h2>4. 重複データ確認</h2>";
    $duplicateCheckSql = "SELECT source_item_id, COUNT(*) as count 
                          FROM yahoo_scraped_products 
                          WHERE source_item_id IS NOT NULL 
                          GROUP BY source_item_id 
                          HAVING COUNT(*) > 1 
                          ORDER BY count DESC";
    
    $duplicateStmt = $pdo->query($duplicateCheckSql);
    $duplicates = $duplicateStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($duplicates)) {
        echo "<div style='color: orange; padding: 10px; background: #fff3cd; margin: 10px 0;'>⚠️ 重複データが " . count($duplicates) . " 件見つかりました:</div>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>source_item_id</th><th>重複数</th></tr>";
        
        foreach (array_slice($duplicates, 0, 10) as $duplicate) {
            echo "<tr>";
            echo "<td>{$duplicate['source_item_id']}</td>";
            echo "<td>{$duplicate['count']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        if (count($duplicates) > 10) {
            echo "<div style='color: blue; padding: 10px;'>... さらに " . (count($duplicates) - 10) . " 件の重複があります</div>";
        }
        
        // 重複データクリーンアップ
        echo "<h3>重複データクリーンアップ</h3>";
        $cleanupSql = "DELETE FROM yahoo_scraped_products 
                       WHERE id NOT IN (
                           SELECT DISTINCT ON (source_item_id) id 
                           FROM yahoo_scraped_products 
                           ORDER BY source_item_id, created_at DESC
                       )";
        
        $cleanupResult = $pdo->exec($cleanupSql);
        echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>🗑️ {$cleanupResult}件の重複データを削除しました</div>";
    } else {
        echo "<div style='color: green; padding: 10px;'>✅ 重複データは見つかりませんでした</div>";
    }
    
    // 5. ユニーク制約追加
    if (!$has_unique_constraint) {
        echo "<h2>5. ユニーク制約追加</h2>";
        try {
            $uniqueConstraintSql = "ALTER TABLE yahoo_scraped_products 
                                   ADD CONSTRAINT unique_source_item_id 
                                   UNIQUE (source_item_id)";
            
            $pdo->exec($uniqueConstraintSql);
            echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ source_item_id にユニーク制約を追加しました</div>";
            
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'already exists') !== false) {
                echo "<div style='color: blue; padding: 10px;'>📋 ユニーク制約は既に存在します</div>";
            } else {
                echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>❌ ユニーク制約追加エラー: " . $e->getMessage() . "</div>";
            }
        }
    } else {
        echo "<h2>5. ユニーク制約確認</h2>";
        echo "<div style='color: green; padding: 10px;'>✅ source_item_id のユニーク制約は既に存在します</div>";
    }
    
    // 6. データサンプル確認
    echo "<h2>6. データサンプル確認</h2>";
    $sampleSql = "SELECT id, source_item_id, active_title, price_jpy, created_at, updated_at 
                  FROM yahoo_scraped_products 
                  ORDER BY created_at DESC 
                  LIMIT 5";
    
    $sampleStmt = $pdo->query($sampleSql);
    $samples = $sampleStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($samples)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
        echo "<tr><th>ID</th><th>source_item_id</th><th>タイトル</th><th>価格</th><th>作成日</th></tr>";
        
        foreach ($samples as $sample) {
            echo "<tr>";
            echo "<td>{$sample['id']}</td>";
            echo "<td>" . substr($sample['source_item_id'], 0, 20) . "...</td>";
            echo "<td>" . substr($sample['active_title'], 0, 30) . "...</td>";
            echo "<td>¥" . number_format($sample['price_jpy']) . "</td>";
            echo "<td>{$sample['created_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div style='color: orange; padding: 10px;'>📊 データが見つかりませんでした</div>";
    }
    
    // 7. テーブル総数確認
    echo "<h2>7. テーブル統計</h2>";
    $countSql = "SELECT COUNT(*) as total_count FROM yahoo_scraped_products";
    $countStmt = $pdo->query($countSql);
    $count = $countStmt->fetch();
    
    $nullCountSql = "SELECT COUNT(*) as null_count FROM yahoo_scraped_products WHERE source_item_id IS NULL";
    $nullCountStmt = $pdo->query($nullCountSql);
    $nullCount = $nullCountStmt->fetch();
    
    echo "<div style='padding: 10px; background: #f0f8ff; border-radius: 5px;'>";
    echo "<p><strong>総レコード数:</strong> {$count['total_count']}件</p>";
    echo "<p><strong>source_item_id が NULL:</strong> {$nullCount['null_count']}件</p>";
    echo "<p><strong>有効なデータ:</strong> " . ($count['total_count'] - $nullCount['null_count']) . "件</p>";
    echo "</div>";
    
    echo "<h2>8. 次のステップ</h2>";
    echo "<div style='padding: 10px; background: #e8f5e8; border-radius: 5px;'>";
    echo "<ol>";
    echo "<li><strong>✅ データベース構造準備完了</strong></li>";
    echo "<li><strong>🔄 スクレイピングテスト実行</strong> - <a href='scraping.php'>scraping.php</a></li>";
    echo "<li><strong>📊 データ確認</strong> - <a href='../05_editing/editing.php'>editing.php</a></li>";
    echo "</ol>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
    echo "<div style='padding: 10px; background: #fff3cd; border-radius: 5px;'>";
    echo "<h3>トラブルシューティング:</h3>";
    echo "<ul>";
    echo "<li>PostgreSQLサービスが起動しているか確認</li>";
    echo "<li>データベース名: nagano3_db が存在するか確認</li>";
    echo "<li>ユーザー権限が正しいか確認</li>";
    echo "</ul>";
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='scraping.php'>← スクレイピングに戻る</a> | <a href='../05_editing/editing.php'>データ編集へ →</a></p>";
?>
