<?php
/**
 * データベーステーブル診断ツール
 * yahoo_scraped_productsテーブルの構造とエラーを調査
 */

function diagnoseYahooScrapedTable() {
    try {
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        echo "=== yahoo_scraped_products テーブル診断 ===\n\n";
        
        // 1. テーブル存在確認
        $sql = "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'yahoo_scraped_products')";
        $stmt = $pdo->query($sql);
        $exists = $stmt->fetchColumn();
        echo "1. テーブル存在: " . ($exists ? "✅ あり" : "❌ なし") . "\n";
        
        if (!$exists) {
            echo "テーブルが存在しません。作成が必要です。\n";
            return;
        }
        
        // 2. カラム情報取得
        $sql = "SELECT column_name, data_type, is_nullable, column_default 
                FROM information_schema.columns 
                WHERE table_name = 'yahoo_scraped_products' 
                ORDER BY ordinal_position";
        $stmt = $pdo->query($sql);
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "\n2. カラム構造:\n";
        foreach ($columns as $col) {
            echo "  - {$col['column_name']}: {$col['data_type']} (NULL: {$col['is_nullable']}) Default: " . ($col['column_default'] ?: 'なし') . "\n";
        }
        
        // 3. インデックス確認
        $sql = "SELECT indexname, indexdef FROM pg_indexes WHERE tablename = 'yahoo_scraped_products'";
        $stmt = $pdo->query($sql);
        $indexes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "\n3. インデックス:\n";
        foreach ($indexes as $idx) {
            echo "  - {$idx['indexname']}: {$idx['indexdef']}\n";
        }
        
        // 4. データ件数確認
        $sql = "SELECT COUNT(*) FROM yahoo_scraped_products";
        $stmt = $pdo->query($sql);
        $count = $stmt->fetchColumn();
        echo "\n4. データ件数: {$count}件\n";
        
        // 5. 簡単なINSERTテスト
        echo "\n5. INSERTテスト実行中...\n";
        
        $test_id = 'DIAG_TEST_' . time();
        $sql = "INSERT INTO yahoo_scraped_products (source_item_id, sku, active_title) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([$test_id, 'SKU-DIAG', 'テスト商品']);
        
        if ($result) {
            echo "✅ INSERTテスト成功\n";
            
            // 挿入されたデータを確認
            $sql = "SELECT * FROM yahoo_scraped_products WHERE source_item_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$test_id]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo "挿入されたデータ:\n";
            foreach ($data as $key => $value) {
                echo "  {$key}: " . ($value ?: 'NULL') . "\n";
            }
            
            // テストデータ削除
            $sql = "DELETE FROM yahoo_scraped_products WHERE source_item_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$test_id]);
            echo "テストデータ削除完了\n";
        } else {
            echo "❌ INSERTテスト失敗\n";
        }
        
    } catch (PDOException $e) {
        echo "❌ データベースエラー: " . $e->getMessage() . "\n";
    } catch (Exception $e) {
        echo "❌ 一般エラー: " . $e->getMessage() . "\n";
    }
}

// 実行
diagnoseYahooScrapedTable();
?>
