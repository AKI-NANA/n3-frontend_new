<?php
/**
 * 価格検証強化版データベース保存関数
 * 価格異常を即座に検出・アラート表示
 */

// 価格検証強化版データベース保存関数
function saveProductToDatabaseWithPriceValidation($product_data) {
    try {
        writeLog("🚀 [価格検証保存開始] 価格検証機能付きデータベース保存開始", 'INFO');
        
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        writeLog("✅ [接続成功] PostgreSQL接続確立", 'SUCCESS');
        
        // 入力データの検証
        if (!$product_data || !is_array($product_data)) {
            writeLog("❌ [入力データエラー] 無効な商品データ", 'ERROR');
            return ['success' => false, 'error' => '無効な商品データです'];
        }
        
        // データ準備
        $source_item_id = $product_data['item_id'] ?? 'SCRAPED_' . time() . '_' . rand(100, 999);
        $price_jpy = (int)($product_data['current_price'] ?? 0);
        $active_title = $product_data['title'] ?? 'タイトル不明';
        $active_description = $product_data['description'] ?? '';
        $current_stock = 1;
        $status = 'scraped';
        
        // 🔴 価格検証（重要：異常価格の検出）
        $price_validation = validatePrice($price_jpy, $active_title, $source_item_id);
        
        if (!$price_validation['valid']) {
            writeLog("🚨 [価格異常検出] " . $price_validation['error'], 'ERROR');
            
            // 価格異常時は保存を中止し、詳細情報を返す
            return [
                'success' => false,
                'error' => $price_validation['error'],
                'price_validation' => $price_validation,
                'original_data' => [
                    'source_item_id' => $source_item_id,
                    'title' => $active_title,
                    'price_jpy' => $price_jpy,
                    'source_url' => $product_data['source_url'] ?? ''
                ]
            ];
        }
        
        writeLog("✅ [価格検証通過] 価格: ¥" . number_format($price_jpy), 'SUCCESS');
        
        // ドル換算計算（正確な変換）
        $active_price_usd = $price_jpy > 0 ? round($price_jpy / 150, 2) : null;
        
        // 🖼️ 画像データの処理・検証
        $image_validation = validateAndProcessImages($product_data['images'] ?? []);
        $active_image_url = $image_validation['primary_image'];
        
        if (!$image_validation['valid']) {
            writeLog("⚠️ [画像警告] " . $image_validation['warning'], 'WARNING');
        } else {
            writeLog("✅ [画像検証] " . $image_validation['image_count'] . "枚の画像を処理", 'SUCCESS');
        }
        
        // 📍 ソース検証（ヤフオクURLの確認）
        $source_url = $product_data['source_url'] ?? '';
        $source_validation = validateSourceUrl($source_url);
        
        if (!$source_validation['valid']) {
            writeLog("⚠️ [ソース警告] " . $source_validation['warning'], 'WARNING');
        }
        
        // JSONデータ構築（検証情報付き）
        $scraped_yahoo_data_array = [
            'category' => $product_data['category'] ?? 'Unknown',
            'condition' => $product_data['condition'] ?? 'Used',
            'url' => $source_url,
            'seller_name' => $product_data['seller_info']['name'] ?? 'Unknown',
            'bid_count' => $product_data['auction_info']['bid_count'] ?? 0,
            'end_time' => $product_data['auction_info']['end_time'] ?? '',
            'scraped_at' => date('Y-m-d H:i:s'),
            'scraping_method' => $product_data['scraping_method'] ?? 'unknown',
            'data_quality' => $product_data['data_quality'] ?? null,
            'extraction_success' => $product_data['extraction_success'] ?? null,
            // 検証情報を追加
            'price_validation' => $price_validation,
            'image_validation' => $image_validation,
            'source_validation' => $source_validation,
            'all_images' => $product_data['images'] ?? []
        ];
        
        $scraped_yahoo_data = json_encode($scraped_yahoo_data_array, JSON_UNESCAPED_UNICODE);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            writeLog("❌ [JSONエラー] JSONエンコード失敗: " . json_last_error_msg(), 'ERROR');
            return ['success' => false, 'error' => 'データエンコードエラー'];
        }
        
        // ユニーク制約確認
        $constraintCheckSql = "SELECT constraint_name FROM information_schema.table_constraints WHERE table_name = 'yahoo_scraped_products' AND constraint_type = 'UNIQUE'";
        $constraintStmt = $pdo->query($constraintCheckSql);
        $constraints = $constraintStmt->fetchAll(PDO::FETCH_COLUMN);
        $has_unique_constraint = !empty($constraints);
        
        // UPSERT実行
        writeLog("🔄 [UPSERT実行] データベース保存開始", 'INFO');
        
        if ($has_unique_constraint) {
            // ユニーク制約がある場合：ON CONFLICT使用
            $sql = "INSERT INTO yahoo_scraped_products (
                source_item_id, price_jpy, scraped_yahoo_data, active_title,
                active_description, active_price_usd, active_image_url, current_stock,
                status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON CONFLICT (source_item_id) DO UPDATE SET
                active_title = EXCLUDED.active_title,
                price_jpy = EXCLUDED.price_jpy,
                scraped_yahoo_data = EXCLUDED.scraped_yahoo_data,
                active_description = EXCLUDED.active_description,
                active_price_usd = EXCLUDED.active_price_usd,
                active_image_url = EXCLUDED.active_image_url,
                current_stock = EXCLUDED.current_stock,
                status = EXCLUDED.status,
                updated_at = CURRENT_TIMESTAMP";
        } else {
            // ユニーク制約がない場合：通常のINSERT
            $sql = "INSERT INTO yahoo_scraped_products (
                source_item_id, price_jpy, scraped_yahoo_data, active_title,
                active_description, active_price_usd, active_image_url, current_stock,
                status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        }
        
        $params = [
            $source_item_id, $price_jpy, $scraped_yahoo_data, $active_title,
            $active_description, $active_price_usd, $active_image_url, $current_stock, $status
        ];
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            // 保存確認
            $verifySql = "SELECT id, source_item_id, active_title, price_jpy, created_at, updated_at FROM yahoo_scraped_products WHERE source_item_id = ?";
            $verifyStmt = $pdo->prepare($verifySql);
            $verifyStmt->execute([$source_item_id]);
            $saved = $verifyStmt->fetch();
            
            if ($saved) {
                $action = ($saved['created_at'] === $saved['updated_at']) ? 'INSERT（新規作成）' : 'UPDATE（既存更新）';
                writeLog("✅ [保存成功] {$action} - ID: {$saved['id']}, 価格: ¥" . number_format($saved['price_jpy']), 'SUCCESS');
                
                return [
                    'success' => true,
                    'action' => $action,
                    'id' => $saved['id'],
                    'source_item_id' => $source_item_id,
                    'price_jpy' => $saved['price_jpy'],
                    'price_usd' => $active_price_usd,
                    'validations' => [
                        'price' => $price_validation,
                        'image' => $image_validation,
                        'source' => $source_validation
                    ]
                ];
            } else {
                writeLog("❌ [保存確認失敗] 保存されたデータが見つかりません", 'ERROR');
                return ['success' => false, 'error' => '保存確認に失敗しました'];
            }
        } else {
            writeLog("❌ [SQL実行失敗] クエリ実行に失敗", 'ERROR');
            return ['success' => false, 'error' => 'SQL実行に失敗しました'];
        }
        
    } catch (PDOException $e) {
        writeLog("❌ [PDOエラー] " . $e->getMessage(), 'ERROR');
        return ['success' => false, 'error' => 'データベースエラー: ' . $e->getMessage()];
    } catch (Exception $e) {
        writeLog("❌ [予期しないエラー] " . $e->getMessage(), 'ERROR');
        return ['success' => false, 'error' => '予期しないエラー: ' . $e->getMessage()];
    }
}

// 価格検証関数
function validatePrice($price_jpy, $title, $source_item_id) {
    $validation = [
        'valid' => true,
        'warnings' => [],
        'error' => '',
        'price_range' => 'normal'
    ];
    
    // 価格が0円の場合
    if ($price_jpy == 0) {
        $validation['valid'] = false;
        $validation['error'] = "🚨 重大エラー: 価格が0円です。スクレイピングに失敗している可能性があります。";
        $validation['price_range'] = 'zero';
        return $validation;
    }
    
    // 異常に低い価格（100円未満）
    if ($price_jpy < 100) {
        $validation['valid'] = false;
        $validation['error'] = "🚨 価格異常: ¥{$price_jpy}は異常に低い価格です。データ確認が必要です。";
        $validation['price_range'] = 'too_low';
        return $validation;
    }
    
    // 異常に高い価格（1000万円以上）
    if ($price_jpy > 10000000) {
        $validation['valid'] = false;
        $validation['error'] = "🚨 価格異常: ¥" . number_format($price_jpy) . "は異常に高い価格です。データ確認が必要です。";
        $validation['price_range'] = 'too_high';
        return $validation;
    }
    
    // 警告レベルの価格範囲
    if ($price_jpy < 500) {
        $validation['warnings'][] = "低価格商品: ¥{$price_jpy}";
        $validation['price_range'] = 'low';
    } elseif ($price_jpy > 1000000) {
        $validation['warnings'][] = "高額商品: ¥" . number_format($price_jpy);
        $validation['price_range'] = 'high';
    }
    
    return $validation;
}

// 画像検証・処理関数
function validateAndProcessImages($images) {
    $validation = [
        'valid' => true,
        'warning' => '',
        'image_count' => 0,
        'primary_image' => 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image',
        'all_images' => []
    ];
    
    if (empty($images) || !is_array($images)) {
        $validation['valid'] = false;
        $validation['warning'] = '画像が取得されていません';
        return $validation;
    }
    
    $valid_images = [];
    foreach ($images as $image_url) {
        if (!empty($image_url) && filter_var($image_url, FILTER_VALIDATE_URL)) {
            $valid_images[] = $image_url;
        }
    }
    
    $validation['image_count'] = count($valid_images);
    $validation['all_images'] = $valid_images;
    
    if (count($valid_images) > 0) {
        $validation['primary_image'] = $valid_images[0];
        $validation['valid'] = true;
    } else {
        $validation['valid'] = false;
        $validation['warning'] = '有効な画像URLが見つかりません';
    }
    
    return $validation;
}

// ソースURL検証関数
function validateSourceUrl($source_url) {
    $validation = [
        'valid' => true,
        'warning' => '',
        'source_type' => 'unknown'
    ];
    
    if (empty($source_url)) {
        $validation['valid'] = false;
        $validation['warning'] = 'ソースURLが空です';
        return $validation;
    }
    
    if (strpos($source_url, 'auctions.yahoo.co.jp') !== false) {
        $validation['source_type'] = 'ヤフオク';
        $validation['valid'] = true;
    } elseif (strpos($source_url, 'yahoo.co.jp') !== false) {
        $validation['source_type'] = 'Yahoo';
        $validation['warning'] = 'Yahoo（ヤフオク以外）からのデータです';
    } else {
        $validation['valid'] = false;
        $validation['warning'] = 'ヤフオク以外のソースURLです: ' . $source_url;
    }
    
    return $validation;
}

writeLog("✅ [価格検証関数準備完了] saveProductToDatabaseWithPriceValidation を定義しました", 'SUCCESS');
?>
