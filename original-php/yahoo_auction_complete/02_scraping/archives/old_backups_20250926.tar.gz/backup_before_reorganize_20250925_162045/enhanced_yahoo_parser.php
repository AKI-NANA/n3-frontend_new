<?php
/**
 * 強化版Yahooオークション HTML解析
 * 旧システムの成功パターンを組み込み
 */

// Yahoo オークション HTML解析（強化版・画像抽出対応）
function parseYahooAuctionHTML($html, $url, $item_id) {
    try {
        writeLog("HTML解析開始: {$item_id} (" . strlen($html) . "文字)", 'INFO');
        
        // HTMLエンティティのデコード
        $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
        
        // 商品タイトルを抽出（複数パターン）
        $title = 'タイトル取得失敗';
        $title_patterns = [
            '/<title[^>]*>([^<]+)<\/title>/i',
            '/<h1[^>]*class="[^"]*ProductTitle[^"]*"[^>]*>([^<]+)<\/h1>/i',
            '/<h1[^>]*class="[^"]*title[^"]*"[^>]*>([^<]+)<\/h1>/i',
            '/<h1[^>]*>([^<]+)<\/h1>/i',
            '/<meta\s+property="og:title"\s+content="([^"]+)"/i'
        ];
        
        foreach ($title_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $title = trim(strip_tags($matches[1]));
                $title = str_replace([' - Yahoo!オークション', 'Yahoo!オークション - ', ' | ヤフオク!'], '', $title);
                if (strlen($title) > 10) { // 有効なタイトルかチェック
                    writeLog("タイトル抽出成功: {$title}", 'SUCCESS');
                    break;
                }
            }
        }
        
        // 現在価格を抽出（複数パターン・高精度）
        $current_price = 0;
        $price_patterns = [
            '/現在価格[\s\S]*?(\d{1,3}(?:,\d{3})*)[\s]*円/u',
            '/現在[\s\S]*?(\d{1,3}(?:,\d{3})*)[\s]*円/u',
            '/価格[\s\S]*?(\d{1,3}(?:,\d{3})*)[\s]*円/u',
            '/"currentPrice"\s*:\s*"?(\d+)"?/i',
            '/data-price="(\d+)"/i',
            '/¥(\d{1,3}(?:,\d{3})*)/u',
            '/(\d{1,3}(?:,\d{3})*)[\s]*円/u'
        ];
        
        foreach ($price_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $price_num = (int)str_replace(',', '', $matches[1]);
                if ($price_num > 0) {
                    $current_price = $price_num;
                    writeLog("価格抽出成功: ¥{$current_price}", 'SUCCESS');
                    break;
                }
            }
        }
        
        // 入札数を抽出
        $bid_count = 0;
        $bid_patterns = [
            '/入札数[\s\S]*?(\d+)/u',
            '/入札[\s\S]*?(\d+)/u',
            '/"bidCount"\s*:\s*(\d+)/i',
            '/data-bid-count="(\d+)"/i'
        ];
        
        foreach ($bid_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $bid_count = (int)$matches[1];
                writeLog("入札数抽出成功: {$bid_count}件", 'SUCCESS');
                break;
            }
        }
        
        // 画像URLを抽出（全枚数対応・Yahoo特化）
        $images = [];
        $image_patterns = [
            // Yahooオークション専用の画像パターン
            '/<img[^>]*src="(https:\/\/auctions\.c\.yimg\.jp[^"]+)"/i',
            '/<img[^>]*src="(https:\/\/[^"]*yimg\.jp[^"]+)"/i',
            '/<img[^>]*class="[^"]*ProductImage[^"]*"[^>]*src="([^"]+)"/i',
            '/<img[^>]*data-src="(https:\/\/auctions\.c\.yimg\.jp[^"]+)"/i',
            '/<img[^>]*src="([^"]*\/auction_img\/[^"]+)"/i',
            // 一般的な画像パターン（JPEG, PNG, GIF）
            '/<img[^>]*src="([^"]+\.(jpg|jpeg|png|gif))"/i'
        ];
        
        foreach ($image_patterns as $pattern) {
            if (preg_match_all($pattern, $html, $matches)) {
                foreach ($matches[1] as $img_url) {
                    // 重複チェック & Yahoo画像サーバーの優先
                    if (!in_array($img_url, $images) && 
                        (strpos($img_url, 'http') === 0) &&
                        !strpos($img_url, 'placeholder') &&
                        !strpos($img_url, 'loading')) {
                        $images[] = $img_url;
                    }
                }
            }
        }
        
        writeLog("画像抽出完了: " . count($images) . "枚", count($images) > 0 ? 'SUCCESS' : 'WARNING');
        
        // カテゴリを抽出
        $category = 'Yahoo Auction';
        $category_patterns = [
            '/カテゴリ[\s\S]*?<a[^>]*>([^<]+)<\/a>/u',
            '/"categoryName"\s*:\s*"([^"]+)"/i',
            '/data-category="([^"]+)"/i'
        ];
        
        foreach ($category_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $category = trim($matches[1]);
                writeLog("カテゴリ抽出成功: {$category}", 'SUCCESS');
                break;
            }
        }
        
        // 状態を抽出
        $condition = 'Used';
        if (preg_match('/新品|未使用|未開封/u', $html)) {
            $condition = 'New';
        } elseif (preg_match('/中古|使用済|傷あり/u', $html)) {
            $condition = 'Used';
        }
        
        // 出品者情報を抽出
        $seller_name = '出品者不明';
        $seller_patterns = [
            '/出品者[\s\S]*?<a[^>]*>([^<]+)<\/a>/u',
            '/"sellerName"\s*:\s*"([^"]+)"/i',
            '/data-seller="([^"]+)"/i'
        ];
        
        foreach ($seller_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $seller_name = trim($matches[1]);
                writeLog("出品者抽出成功: {$seller_name}", 'SUCCESS');
                break;
            }
        }
        
        // 商品説明を抽出（最初の300文字）
        $description = '商品説明取得失敗';
        $desc_patterns = [
            '/<div[^>]*class="[^"]*ProductDetail[^"]*"[^>]*>([\s\S]*?)<\/div>/u',
            '/<div[^>]*class="[^"]*ItemDetail[^"]*"[^>]*>([\s\S]*?)<\/div>/u',
            '/<div[^>]*class="[^"]*description[^"]*"[^>]*>([\s\S]*?)<\/div>/u'
        ];
        
        foreach ($desc_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $description = trim(strip_tags($matches[1]));
                $description = mb_substr($description, 0, 300, 'UTF-8');
                if (strlen($description) > 20) {
                    writeLog("説明抽出成功: " . mb_substr($description, 0, 50, 'UTF-8') . "...", 'SUCCESS');
                    break;
                }
            }
        }
        
        // 終了時間を抽出
        $end_time = date('Y-m-d H:i:s', strtotime('+7 days'));
        $time_patterns = [
            '/終了時間[\s\S]*?(\d{4})年(\d{1,2})月(\d{1,2})日\s*(\d{1,2})時(\d{1,2})分/u',
            '/終了[\s\S]*?(\d{4})\/(\d{1,2})\/(\d{1,2})\s+(\d{1,2}):(\d{2})/u',
            '/"endTime"\s*:\s*"([^"]+)"/i'
        ];
        
        foreach ($time_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                if (count($matches) >= 6) {
                    $end_time = sprintf('%04d-%02d-%02d %02d:%02d:00', 
                        $matches[1], $matches[2], $matches[3], $matches[4], $matches[5]);
                    writeLog("終了時間抽出成功: {$end_time}", 'SUCCESS');
                    break;
                }
            }
        }
        
        $product_data = [
            'item_id' => $item_id,
            'title' => $title,
            'description' => $description,
            'current_price' => $current_price,
            'condition' => $condition,
            'category' => $category,
            'images' => $images,
            'seller_info' => [
                'name' => $seller_name,
                'rating' => 'N/A'
            ],
            'auction_info' => [
                'end_time' => $end_time,
                'bid_count' => $bid_count
            ],
            'scraped_at' => date('Y-m-d H:i:s'),
            'source_url' => $url,
            'scraping_method' => 'enhanced_html_parsing_v2'
        ];
        
        writeLog("商品データ解析完了: {$title} - ¥{$current_price} (画像" . count($images) . "枚)", 'SUCCESS');
        
        // データベースに保存
        $save_result = saveProductToDatabase($product_data);
        if ($save_result) {
            writeLog("商品データベース保存成功: {$item_id}", 'SUCCESS');
            $product_data['database_saved'] = true;
        } else {
            writeLog("商品データベース保存失敗: {$item_id}", 'WARNING');
            $product_data['database_saved'] = false;
        }
        
        return $product_data;
        
    } catch (Exception $e) {
        writeLog("HTML解析例外: " . $e->getMessage(), 'ERROR');
        return false;
    }
}

echo "✅ 強化版Yahoo HTML解析機能読み込み完了\n";
?>
