<?php
/**
 * データベース直接確認ツール
 */

// 直接アクセス対応
if (!defined('SECURE_ACCESS')) {
    define('SECURE_ACCESS', true);
}

// データベース接続
function getDbConnection() {
    try {
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        return $pdo;
    } catch (PDOException $e) {
        return null;
    }
}

// API処理
$action = $_GET['action'] ?? '';

if (!empty($action)) {
    header('Content-Type: application/json');
    
    $pdo = getDbConnection();
    if (!$pdo) {
        echo json_encode(['success' => false, 'message' => 'データベース接続失敗']);
        exit;
    }
    
    try {
        switch ($action) {
            case 'count_all':
                $stmt = $pdo->query("SELECT COUNT(*) as count FROM yahoo_scraped_products");
                $result = $stmt->fetch();
                echo json_encode(['success' => true, 'count' => $result['count']]);
                break;
                
            case 'get_latest':
                $stmt = $pdo->query("
                    SELECT 
                        id, source_item_id, active_title, price_jpy, status, 
                        ebay_item_id, created_at, updated_at
                    FROM yahoo_scraped_products 
                    ORDER BY created_at DESC 
                    LIMIT 10
                ");
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $results]);
                break;
                
            case 'get_test_data':
                $stmt = $pdo->query("
                    SELECT 
                        id, source_item_id, active_title, price_jpy, status, 
                        ebay_item_id, created_at
                    FROM yahoo_scraped_products 
                    WHERE source_item_id LIKE 'TEST_%'
                    ORDER BY created_at DESC
                ");
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $results]);
                break;
                
            case 'get_non_test_data':
                $stmt = $pdo->query("
                    SELECT 
                        id, source_item_id, active_title, price_jpy, status, 
                        ebay_item_id, created_at
                    FROM yahoo_scraped_products 
                    WHERE source_item_id NOT LIKE 'TEST_%'
                    ORDER BY created_at DESC
                ");
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $results]);
                break;
                
            case 'get_unlisted_count':
                $stmt = $pdo->query("
                    SELECT COUNT(*) as count 
                    FROM yahoo_scraped_products 
                    WHERE (ebay_item_id IS NULL OR ebay_item_id = '')
                ");
                $result = $stmt->fetch();
                echo json_encode(['success' => true, 'count' => $result['count']]);
                break;
                
            case 'get_ebay_status':
                $stmt = $pdo->query("
                    SELECT 
                        CASE 
                            WHEN ebay_item_id IS NULL THEN 'NULL'
                            WHEN ebay_item_id = '' THEN 'EMPTY'
                            ELSE 'HAS_VALUE'
                        END as ebay_status,
                        COUNT(*) as count
                    FROM yahoo_scraped_products 
                    GROUP BY 
                        CASE 
                            WHEN ebay_item_id IS NULL THEN 'NULL'
                            WHEN ebay_item_id = '' THEN 'EMPTY'
                            ELSE 'HAS_VALUE'
                        END
                ");
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $results]);
                break;
                
            default:
                echo json_encode(['success' => false, 'message' => '不明なアクション']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>データベース直接確認ツール</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2rem; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 2rem; border-radius: 8px; }
        .section { margin-bottom: 2rem; padding: 1rem; border: 1px solid #ddd; border-radius: 8px; background: #f9f9f9; }
        .btn { padding: 8px 16px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; margin: 4px; }
        .btn:hover { background: #0056b3; }
        .btn-success { background: #28a745; }
        .btn-warning { background: #ffc107; color: #212529; }
        .btn-danger { background: #dc3545; }
        .results { background: #f8f9fa; padding: 1rem; border-radius: 4px; margin-top: 1rem; }
        .table { width: 100%; border-collapse: collapse; margin: 1rem 0; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 0.9rem; }
        .table th { background: #f8f9fa; font-weight: bold; }
        .status { padding: 0.5rem 1rem; border-radius: 4px; margin: 0.5rem 0; }
        .status-success { background: #d4edda; color: #155724; }
        .status-error { background: #f8d7da; color: #721c24; }
        .status-info { background: #d1ecf1; color: #0c5460; }
        .status-warning { background: #fff3cd; color: #856404; }
        .code { background: #2d2d2d; color: #00ff00; padding: 1rem; border-radius: 4px; font-family: monospace; white-space: pre-wrap; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Yahoo Auction データベース直接確認</h1>
        
        <div class="section">
            <h3>📊 基本統計</h3>
            <button class="btn" onclick="checkTotalCount()">総データ数確認</button>
            <button class="btn" onclick="checkUnlistedCount()">未出品データ数確認</button>
            <button class="btn" onclick="checkEbayStatus()">eBay ID状況確認</button>
            <div id="statsResults" class="results" style="display: none;"></div>
        </div>
        
        <div class="section">
            <h3>📋 データ一覧</h3>
            <button class="btn btn-success" onclick="getLatestData()">最新10件取得</button>
            <button class="btn btn-warning" onclick="getTestData()">テストデータ確認</button>
            <button class="btn btn-danger" onclick="getNonTestData()">スクレイピングデータ確認</button>
            <div id="dataResults" class="results" style="display: none;"></div>
        </div>
        
        <div class="section">
            <h3>💻 手動SQL実行</h3>
            <p>ターミナルで以下のコマンドを実行してデータベースに直接接続：</p>
            <div class="code">psql -h localhost -d nagano3_db -U postgres
# パスワード: Kn240914

-- 基本確認
SELECT COUNT(*) FROM yahoo_scraped_products;

-- 最新5件
SELECT id, source_item_id, active_title, price_jpy, ebay_item_id, created_at 
FROM yahoo_scraped_products 
ORDER BY created_at DESC 
LIMIT 5;</div>
        </div>
        
        <div id="diagnosis" class="section" style="display: none;">
            <h3>🔬 診断結果</h3>
            <div id="diagnosisContent"></div>
        </div>
    </div>

    <script>
        async function checkTotalCount() {
            try {
                const response = await fetch('?action=count_all');
                const data = await response.json();
                
                const resultsDiv = document.getElementById('statsResults');
                if (data.success) {
                    resultsDiv.innerHTML = `
                        <div class="status status-info">
                            <strong>総データ数:</strong> ${data.count}件
                        </div>
                    `;
                    resultsDiv.style.display = 'block';
                    
                    if (data.count === 0) {
                        showDiagnosis('❌ データベースにデータが1件もありません。スクレイピングが全く成功していません。');
                    } else {
                        showDiagnosis(`✅ データベースに${data.count}件のデータがあります。スクレイピングは成功しています。`);
                    }
                } else {
                    resultsDiv.innerHTML = `<div class="status status-error">エラー: ${data.message}</div>`;
                    resultsDiv.style.display = 'block';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        async function checkUnlistedCount() {
            try {
                const response = await fetch('?action=get_unlisted_count');
                const data = await response.json();
                
                const resultsDiv = document.getElementById('statsResults');
                if (data.success) {
                    resultsDiv.innerHTML = `
                        <div class="status status-info">
                            <strong>未出品データ数:</strong> ${data.count}件
                        </div>
                    `;
                    resultsDiv.style.display = 'block';
                    
                    if (data.count === 0) {
                        showDiagnosis('⚠️ 未出品データが0件です。全データが出品済み扱いになっているか、ebay_item_idに値が入っています。');
                    } else {
                        showDiagnosis(`✅ 未出品データが${data.count}件あります。編集システムで表示されるはずです。`);
                    }
                } else {
                    resultsDiv.innerHTML = `<div class="status status-error">エラー: ${data.message}</div>`;
                    resultsDiv.style.display = 'block';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        async function checkEbayStatus() {
            try {
                const response = await fetch('?action=get_ebay_status');
                const data = await response.json();
                
                const resultsDiv = document.getElementById('statsResults');
                if (data.success) {
                    let html = '<h4>eBay ID状況:</h4>';
                    data.data.forEach(item => {
                        const statusText = {
                            'NULL': 'NULL (未出品)',
                            'EMPTY': '空文字 (未出品)',
                            'HAS_VALUE': '値あり (出品済み)'
                        }[item.ebay_status] || item.ebay_status;
                        
                        html += `<div class="status status-info">${statusText}: ${item.count}件</div>`;
                    });
                    resultsDiv.innerHTML = html;
                    resultsDiv.style.display = 'block';
                } else {
                    resultsDiv.innerHTML = `<div class="status status-error">エラー: ${data.message}</div>`;
                    resultsDiv.style.display = 'block';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        async function getLatestData() {
            try {
                const response = await fetch('?action=get_latest');
                const data = await response.json();
                
                const resultsDiv = document.getElementById('dataResults');
                if (data.success) {
                    let html = '<h4>最新10件のデータ:</h4>';
                    
                    if (data.data.length === 0) {
                        html += '<div class="status status-warning">データが見つかりません</div>';
                    } else {
                        html += '<table class="table"><thead><tr>';
                        html += '<th>ID</th><th>Source ID</th><th>タイトル</th><th>価格</th><th>ステータス</th><th>eBay ID</th><th>作成日時</th>';
                        html += '</tr></thead><tbody>';
                        
                        data.data.forEach(item => {
                            html += '<tr>';
                            html += `<td>${item.id}</td>`;
                            html += `<td>${item.source_item_id}</td>`;
                            html += `<td>${item.active_title || 'N/A'}</td>`;
                            html += `<td>¥${item.price_jpy || 0}</td>`;
                            html += `<td>${item.status || 'N/A'}</td>`;
                            html += `<td>${item.ebay_item_id || 'NULL'}</td>`;
                            html += `<td>${new Date(item.created_at).toLocaleString()}</td>`;
                            html += '</tr>';
                        });
                        html += '</tbody></table>';
                    }
                    
                    resultsDiv.innerHTML = html;
                    resultsDiv.style.display = 'block';
                } else {
                    resultsDiv.innerHTML = `<div class="status status-error">エラー: ${data.message}</div>`;
                    resultsDiv.style.display = 'block';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        async function getTestData() {
            try {
                const response = await fetch('?action=get_test_data');
                const data = await response.json();
                
                const resultsDiv = document.getElementById('dataResults');
                if (data.success) {
                    let html = '<h4>テストデータ:</h4>';
                    
                    if (data.data.length === 0) {
                        html += '<div class="status status-warning">テストデータが見つかりません</div>';
                    } else {
                        html += `<div class="status status-success">${data.data.length}件のテストデータが見つかりました</div>`;
                        html += '<table class="table"><thead><tr>';
                        html += '<th>ID</th><th>Source ID</th><th>タイトル</th><th>価格</th><th>eBay ID</th><th>作成日時</th>';
                        html += '</tr></thead><tbody>';
                        
                        data.data.forEach(item => {
                            html += '<tr>';
                            html += `<td>${item.id}</td>`;
                            html += `<td>${item.source_item_id}</td>`;
                            html += `<td>${item.active_title || 'N/A'}</td>`;
                            html += `<td>¥${item.price_jpy || 0}</td>`;
                            html += `<td>${item.ebay_item_id || 'NULL'}</td>`;
                            html += `<td>${new Date(item.created_at).toLocaleString()}</td>`;
                            html += '</tr>';
                        });
                        html += '</tbody></table>';
                    }
                    
                    resultsDiv.innerHTML = html;
                    resultsDiv.style.display = 'block';
                } else {
                    resultsDiv.innerHTML = `<div class="status status-error">エラー: ${data.message}</div>`;
                    resultsDiv.style.display = 'block';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        async function getNonTestData() {
            try {
                const response = await fetch('?action=get_non_test_data');
                const data = await response.json();
                
                const resultsDiv = document.getElementById('dataResults');
                if (data.success) {
                    let html = '<h4>実際のスクレイピングデータ:</h4>';
                    
                    if (data.data.length === 0) {
                        html += '<div class="status status-error">❌ 実際のスクレイピングデータが見つかりません！</div>';
                        html += '<p>これが問題の原因です。スクレイピングが実際には成功していません。</p>';
                        showDiagnosis('🔴 重要: 実際のスクレイピングデータが0件です。スクレイピングシステムでエラーが発生している可能性があります。');
                    } else {
                        html += `<div class="status status-success">✅ ${data.data.length}件の実際のスクレイピングデータが見つかりました</div>`;
                        html += '<table class="table"><thead><tr>';
                        html += '<th>ID</th><th>Source ID</th><th>タイトル</th><th>価格</th><th>eBay ID</th><th>作成日時</th>';
                        html += '</tr></thead><tbody>';
                        
                        data.data.forEach(item => {
                            html += '<tr>';
                            html += `<td>${item.id}</td>`;
                            html += `<td>${item.source_item_id}</td>`;
                            html += `<td>${item.active_title || 'N/A'}</td>`;
                            html += `<td>¥${item.price_jpy || 0}</td>`;
                            html += `<td>${item.ebay_item_id || 'NULL'}</td>`;
                            html += `<td>${new Date(item.created_at).toLocaleString()}</td>`;
                            html += '</tr>';
                        });
                        html += '</tbody></table>';
                        
                        showDiagnosis('✅ 実際のスクレイピングデータが見つかりました。データは正常に保存されています。');
                    }
                    
                    resultsDiv.innerHTML = html;
                    resultsDiv.style.display = 'block';
                } else {
                    resultsDiv.innerHTML = `<div class="status status-error">エラー: ${data.message}</div>`;
                    resultsDiv.style.display = 'block';
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
        
        function showDiagnosis(message) {
            document.getElementById('diagnosisContent').innerHTML = `
                <div class="status status-info">
                    ${message}
                </div>
            `;
            document.getElementById('diagnosis').style.display = 'block';
        }
    </script>
</body>
</html>
