<?php
/**
 * Yahoo オークション 実HTML構造対応 高精度パーサー（2025年版）
 * Geminiのアドバイスに基づいた実装
 */

/**
 * 実HTML構造対応のYahoo オークション解析
 */
function parseYahooAuctionHTML_RealStructure($html, $url, $item_id) {
    try {
        writeLog("🎯 [実構造解析開始] Real HTML Structure Parser for: {$item_id}", 'INFO');
        
        // DOMDocument初期化
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_use_internal_errors(false);
        
        $xpath = new DOMXPath($dom);
        
        // エラー・警告追跡
        $errors = [];
        $warnings = [];
        $quality_score = 100;
        
        // 1. 現在価格の確実な取得（Geminiアドバイス通り）
        $price_data = extractCurrentPriceFromRealHTML($xpath, $errors, $quality_score);
        
        // 2. オークション形式判定（重要）
        $auction_type = determineAuctionType($xpath, $price_data);
        
        // 3. ビジネス要件チェック：定額以外はエラー処理
        if ($auction_type !== 'fixed_price' && $auction_type !== 'buy_now') {
            writeLog("⚠️ [オークション形式警告] {$auction_type} - 価格変動リスクあり", 'WARNING');
            $warnings[] = "オークション形式のため価格が変動する可能性があります";
            $quality_score -= 20;
        }
        
        // 4. カテゴリ情報の精密抽出
        $category_data = extractCategoryFromRealHTML($xpath, $errors, $quality_score);
        
        // 5. 商品状態の確実な取得
        $condition = extractConditionFromRealHTML($xpath, $errors, $quality_score);
        
        // 6. ブランド情報の取得
        $brand = extractBrandFromRealHTML($xpath, $errors, $quality_score);
        
        // 7. オークション詳細情報の取得
        $auction_details = extractAuctionDetailsFromRealHTML($xpath, $errors, $quality_score);
        
        // 8. 商品基本情報の取得
        $basic_info = extractBasicInfoFromRealHTML($xpath, $errors, $quality_score);
        
        // 9. タイトル抽出（フォールバック対応）
        $title = extractTitleFromRealHTML($dom, $xpath, $errors, $quality_score);
        
        // 10. 品質検証（厳格）
        $validation_result = validateRealHTMLData([
            'title' => $title,
            'price_data' => $price_data,
            'category_data' => $category_data,
            'condition' => $condition,
            'auction_type' => $auction_type
        ], $errors, $warnings, $quality_score);
        
        // 11. 品質閾値チェック（商用利用基準）
        $min_commercial_quality = 70; // 商用利用最低品質
        if ($validation_result['quality_score'] < $min_commercial_quality) {
            writeLog("❌ [商用品質不合格] スコア: {$validation_result['quality_score']}% (最低: {$min_commercial_quality}%)", 'ERROR');
            return false;
        }
        
        // 最終商品データ構築
        $product_data = [
            'item_id' => $item_id,
            'title' => $title,
            'description' => generateCommercialDescription($title, $category_data, $condition, $brand),
            'current_price' => $price_data['current_price'],
            'immediate_price' => $price_data['immediate_price'],
            'start_price' => $price_data['start_price'],
            'auction_type' => $auction_type,
            'condition' => $condition,
            'category' => $category_data['final_category'],
            'category_path' => $category_data['category_path'],
            'brand' => $brand,
            'images' => [], // 別途実装
            'seller_info' => [
                'name' => 'データ取得中',
                'rating' => 'N/A'
            ],
            'auction_info' => $auction_details,
            'basic_info' => $basic_info,
            'scraped_at' => date('Y-m-d H:i:s'),
            'source_url' => $url,
            'scraping_method' => 'real_html_structure',
            'data_quality' => $validation_result['quality_score'],
            'errors' => $errors,
            'warnings' => $warnings,
            'validation_status' => $validation_result['status'],
            'commercial_grade' => $validation_result['quality_score'] >= 90 ? 'A' : ($validation_result['quality_score'] >= 70 ? 'B' : 'C')
        ];
        
        writeLog("✅ [実構造解析完了] Grade: {$product_data['commercial_grade']}, Quality: {$validation_result['quality_score']}%, Type: {$auction_type}", 'SUCCESS');
        
        return $product_data;
        
    } catch (Exception $e) {
        writeLog("❌ [実構造解析例外] " . $e->getMessage(), 'ERROR');
        return false;
    }
}

/**
 * 現在価格の確実な取得（Geminiアドバイス実装）
 */
function extractCurrentPriceFromRealHTML($xpath, &$errors, &$quality_score) {
    $price_data = [
        'current_price' => null,
        'immediate_price' => null,
        'start_price' => null,
        'tax_info' => null
    ];
    
    try {
        // 現在価格の取得（Geminiアドバイス通り）
        writeLog("💰 [現在価格抽出] dt要素「現在」をキーに抽出開始", 'INFO');
        
        $currentPriceDt = $xpath->query('//dt[contains(text(), "現在")]');
        
        if ($currentPriceDt->length > 0) {
            $currentPriceDd = $xpath->query('following-sibling::dd', $currentPriceDt->item(0));
            
            if ($currentPriceDd->length > 0) {
                $priceText = trim($currentPriceDd->item(0)->textContent);
                writeLog("📝 [価格テキスト取得] Raw: {$priceText}", 'DEBUG');
                
                // 数値とカンマ以外の文字を削除
                $cleanPrice = preg_replace('/[^0-9,]/', '', $priceText);
                $price = (int)str_replace(',', '', $cleanPrice);
                
                if ($price > 0 && $price < 100000000) { // 妥当性チェック
                    $price_data['current_price'] = $price;
                    writeLog("✅ [現在価格取得成功] ¥{$price}", 'SUCCESS');
                } else {
                    $errors[] = "現在価格の値が異常です: {$price}";
                    $quality_score -= 30;
                }
                
                // 税情報の取得
                if (preg_match('/税(\d+)円/', $priceText, $taxMatches)) {
                    $price_data['tax_info'] = (int)$taxMatches[1];
                }
            } else {
                $errors[] = "現在価格のdd要素が見つかりません";
                $quality_score -= 30;
            }
        } else {
            $errors[] = "現在価格のdt要素が見つかりません";
            $quality_score -= 30;
        }
        
        // 即決価格の取得（同様の方法）
        $buyNowDt = $xpath->query('//dt[contains(text(), "即決")]');
        if ($buyNowDt->length > 0) {
            $buyNowDd = $xpath->query('following-sibling::dd', $buyNowDt->item(0));
            if ($buyNowDd->length > 0) {
                $buyNowText = trim($buyNowDd->item(0)->textContent);
                $cleanBuyNow = preg_replace('/[^0-9,]/', '', $buyNowText);
                $buyNowPrice = (int)str_replace(',', '', $cleanBuyNow);
                
                if ($buyNowPrice > 0) {
                    $price_data['immediate_price'] = $buyNowPrice;
                    writeLog("✅ [即決価格取得成功] ¥{$buyNowPrice}", 'SUCCESS');
                }
            }
        }
        
        // 開始時の価格（オークション詳細テーブルから）
        $startPriceTh = $xpath->query('//th[contains(text(), "開始時の価格")]');
        if ($startPriceTh->length > 0) {
            $startPriceTd = $xpath->query('following-sibling::td', $startPriceTh->item(0));
            if ($startPriceTd->length > 0) {
                $startPriceText = trim($startPriceTd->item(0)->textContent);
                $cleanStartPrice = preg_replace('/[^0-9,]/', '', $startPriceText);
                $startPrice = (int)str_replace(',', '', $cleanStartPrice);
                
                if ($startPrice > 0) {
                    $price_data['start_price'] = $startPrice;
                    writeLog("✅ [開始価格取得成功] ¥{$startPrice}", 'SUCCESS');
                }
            }
        }
        
    } catch (Exception $e) {
        $errors[] = "価格抽出中にエラー: " . $e->getMessage();
        $quality_score -= 40;
    }
    
    return $price_data;
}

/**
 * オークション形式の正確な判定（修正版）
 */
function determineAuctionType($xpath, $price_data) {
    try {
        writeLog("🔍 [オークション形式判定開始] 詳細な形式分析を実行", 'INFO');
        
        // 1. 即決価格の存在確認（より詳細に）
        $hasBuyNow = !is_null($price_data['immediate_price']);
        $hasCurrentPrice = !is_null($price_data['current_price']);
        $hasStartPrice = !is_null($price_data['start_price']);
        
        writeLog("📊 [価格情報] 現在価格: {$hasCurrentPrice}, 即決価格: {$hasBuyNow}, 開始価格: {$hasStartPrice}", 'DEBUG');
        
        // 2. 入札数の確認（複数パターン）
        $bidCount = 0;
        $bidCountPatterns = [
            '//dt[contains(text(), "入札")]',
            '//th[contains(text(), "入札")]',
            '//*[contains(text(), "入札数")]',
            '//*[contains(text(), "現在の入札数")]'
        ];
        
        foreach ($bidCountPatterns as $pattern) {
            $bidElements = $xpath->query($pattern);
            if ($bidElements->length > 0) {
                $bidElement = $bidElements->item(0);
                
                // following-sibling または parent でdd/td要素を探す
                $bidValueElements = $xpath->query('following-sibling::dd | following-sibling::td | ../td[2]', $bidElement);
                
                if ($bidValueElements->length > 0) {
                    $bidText = trim($bidValueElements->item(0)->textContent);
                    writeLog("📝 [入札テキスト取得] Raw: {$bidText}", 'DEBUG');
                    
                    if (preg_match('/(\d+)/', $bidText, $matches)) {
                        $bidCount = (int)$matches[1];
                        writeLog("✅ [入札数取得成功] {$bidCount}件", 'SUCCESS');
                        break;
                    }
                }
            }
        }
        
        // 3. 終了日時の確認（オークション形式の重要な指標）
        $hasEndTime = false;
        $endTimePatterns = [
            '//th[contains(text(), "終了日時")]',
            '//dt[contains(text(), "終了")]',
            '//*[contains(text(), "終了時間")]'
        ];
        
        foreach ($endTimePatterns as $pattern) {
            $endElements = $xpath->query($pattern);
            if ($endElements->length > 0) {
                $hasEndTime = true;
                $endElement = $endElements->item(0);
                $endValueElements = $xpath->query('following-sibling::dd | following-sibling::td | ../td[2]', $endElement);
                
                if ($endValueElements->length > 0) {
                    $endTimeText = trim($endValueElements->item(0)->textContent);
                    writeLog("⏰ [終了日時取得] {$endTimeText}", 'DEBUG');
                    
                    // 既に終了しているかチェック
                    if (preg_match('/終了|完了|sold/i', $endTimeText)) {
                        writeLog("⚠️ [オークション終了] 既に終了したオークションです", 'WARNING');
                        return 'ended_auction';
                    }
                }
                break;
            }
        }
        
        // 4. 「即決価格」という文字列の存在確認
        $buyNowTextExists = false;
        $buyNowTextElements = $xpath->query('//*[contains(text(), "即決")]');
        if ($buyNowTextElements->length > 0) {
            $buyNowTextExists = true;
            writeLog("💰 [即決価格テキスト発見] 即決価格の表示を確認", 'DEBUG');
        }
        
        // 5. 「現在価格」と「開始価格」の比較
        $priceHasChanged = false;
        if ($hasCurrentPrice && $hasStartPrice) {
            $priceHasChanged = ($price_data['current_price'] > $price_data['start_price']);
            writeLog("📈 [価格変動確認] 開始: ¥{$price_data['start_price']}, 現在: ¥{$price_data['current_price']}, 変動: {$priceHasChanged}", 'DEBUG');
        }
        
        // 6. 自動延長の確認（オークション形式の指標）
        $hasAutoExtend = false;
        $autoExtendElements = $xpath->query('//th[contains(text(), "自動延長")]');
        if ($autoExtendElements->length > 0) {
            $autoExtendValue = $xpath->query('following-sibling::td', $autoExtendElements->item(0));
            if ($autoExtendValue->length > 0) {
                $autoExtendText = trim($autoExtendValue->item(0)->textContent);
                $hasAutoExtend = ($autoExtendText === 'あり');
                writeLog("🔄 [自動延長確認] {$autoExtendText} -> {$hasAutoExtend}", 'DEBUG');
            }
        }
        
        // 7. 形式判定ロジック（厳格版）
        writeLog("🧮 [判定ロジック実行] 入札数: {$bidCount}, 終了日時: {$hasEndTime}, 自動延長: {$hasAutoExtend}, 価格変動: {$priceHasChanged}", 'INFO');
        
        // オークション形式の強い指標
        $auctionIndicators = [
            $bidCount > 0,                    // 入札がある
            $priceHasChanged,                 // 価格が上昇している
            $hasAutoExtend,                   // 自動延長がある
            $hasEndTime && !$buyNowTextExists // 終了日時があるが即決価格がない
        ];
        
        $auctionScore = array_sum($auctionIndicators);
        writeLog("📊 [オークションスコア] {$auctionScore}/4", 'INFO');
        
        // 判定結果
        if ($auctionScore >= 2) {
            writeLog("🚨 [判定結果] オークション形式 (スコア: {$auctionScore})", 'WARNING');
            return 'auction_only';
        } elseif ($hasBuyNow && $bidCount == 0 && !$priceHasChanged) {
            writeLog("✅ [判定結果] 定額出品 (即決価格のみ)", 'SUCCESS');
            return 'fixed_price';
        } elseif ($hasBuyNow && $bidCount > 0) {
            writeLog("⚠️ [判定結果] 即決付きオークション", 'WARNING');
            return 'auction_with_buynow';
        } elseif ($hasEndTime && ($bidCount > 0 || $priceHasChanged)) {
            writeLog("🚨 [判定結果] 純粋オークション", 'WARNING');
            return 'auction_only';
        } else {
            writeLog("❓ [判定結果] 不明な形式 - 安全のためオークション扱い", 'WARNING');
            return 'unknown_auction'; // 安全のためオークション扱い
        }
        
    } catch (Exception $e) {
        writeLog("❌ [オークション形式判定エラー] " . $e->getMessage(), 'ERROR');
        return 'unknown_auction'; // エラー時は安全のためオークション扱い
    }
}

/**
 * カテゴリ情報の精密抽出（Geminiアドバイス実装）
 */
function extractCategoryFromRealHTML($xpath, &$errors, &$quality_score) {
    try {
        writeLog("📂 [カテゴリ抽出] dt要素「カテゴリ」をキーに抽出開始", 'INFO');
        
        $categoryDt = $xpath->query('//dt[text()="カテゴリ"]');
        
        if ($categoryDt->length > 0) {
            // 全カテゴリパスを取得
            $categoryLinks = $xpath->query('following-sibling::dd/ul/li/a', $categoryDt->item(0));
            $categoryPath = [];
            
            foreach ($categoryLinks as $link) {
                $categoryName = trim($link->textContent);
                if (!empty($categoryName)) {
                    $categoryPath[] = $categoryName;
                }
            }
            
            // 最終カテゴリ（最も具体的）を取得
            $finalCategoryLi = $xpath->query('following-sibling::dd/ul/li[last()]/a', $categoryDt->item(0));
            $finalCategory = 'その他';
            
            if ($finalCategoryLi->length > 0) {
                $finalCategory = trim($finalCategoryLi->item(0)->textContent);
                writeLog("✅ [最終カテゴリ取得] {$finalCategory}", 'SUCCESS');
            } else {
                $errors[] = "最終カテゴリの取得に失敗";
                $quality_score -= 10;
            }
            
            return [
                'final_category' => $finalCategory,
                'category_path' => $categoryPath,
                'category_count' => count($categoryPath)
            ];
            
        } else {
            $errors[] = "カテゴリ情報のdt要素が見つかりません";
            $quality_score -= 15;
            
            return [
                'final_category' => 'その他',
                'category_path' => [],
                'category_count' => 0
            ];
        }
        
    } catch (Exception $e) {
        $errors[] = "カテゴリ抽出中にエラー: " . $e->getMessage();
        $quality_score -= 15;
        
        return [
            'final_category' => 'その他',
            'category_path' => [],
            'category_count' => 0
        ];
    }
}

/**
 * 商品状態の確実な取得（Geminiアドバイス実装）
 */
function extractConditionFromRealHTML($xpath, &$errors, &$quality_score) {
    try {
        writeLog("🔍 [商品状態抽出] dt要素「商品の状態」をキーに抽出開始", 'INFO');
        
        $conditionDt = $xpath->query('//dt[text()="商品の状態"]');
        
        if ($conditionDt->length > 0) {
            $conditionDd = $xpath->query('following-sibling::dd/a', $conditionDt->item(0));
            
            if ($conditionDd->length > 0) {
                $conditionText = trim($conditionDd->item(0)->textContent);
                
                // 標準化されたコンディション
                $condition_mapping = [
                    '新品、未使用' => 'New',
                    '未使用に近い' => 'Like New',
                    '目立った傷や汚れなし' => 'Excellent',
                    'やや傷や汚れあり' => 'Good',
                    '傷や汚れあり' => 'Fair',
                    '全体的に状態が悪い' => 'Poor',
                    'ジャンク品' => 'For Parts'
                ];
                
                $standardCondition = $condition_mapping[$conditionText] ?? 'Used';
                
                writeLog("✅ [商品状態取得成功] {$conditionText} -> {$standardCondition}", 'SUCCESS');
                return $standardCondition;
                
            } else {
                $errors[] = "商品状態のa要素が見つかりません";
                $quality_score -= 10;
                return 'Used';
            }
        } else {
            $errors[] = "商品状態のdt要素が見つかりません";
            $quality_score -= 10;
            return 'Used';
        }
        
    } catch (Exception $e) {
        $errors[] = "商品状態抽出中にエラー: " . $e->getMessage();
        $quality_score -= 10;
        return 'Used';
    }
}

/**
 * ブランド情報の取得（Geminiアドバイス実装）
 */
function extractBrandFromRealHTML($xpath, &$errors, &$quality_score) {
    try {
        writeLog("🏷️ [ブランド抽出] dt要素「ブランド」をキーに抽出開始", 'INFO');
        
        $brandDt = $xpath->query('//dt[text()="ブランド"]');
        
        if ($brandDt->length > 0) {
            $brandDd = $xpath->query('following-sibling::dd/a', $brandDt->item(0));
            
            if ($brandDd->length > 0) {
                $brandName = trim($brandDd->item(0)->textContent);
                writeLog("✅ [ブランド取得成功] {$brandName}", 'SUCCESS');
                return $brandName;
            } else {
                // a要素がない場合、dd要素の直接テキストを取得
                $brandDd = $xpath->query('following-sibling::dd', $brandDt->item(0));
                if ($brandDd->length > 0) {
                    $brandName = trim($brandDd->item(0)->textContent);
                    if (!empty($brandName)) {
                        writeLog("✅ [ブランド取得成功] {$brandName}", 'SUCCESS');
                        return $brandName;
                    }
                }
            }
        }
        
        writeLog("⚠️ [ブランド未設定] ブランド情報が見つかりません", 'WARNING');
        return null;
        
    } catch (Exception $e) {
        writeLog("⚠️ [ブランド抽出エラー] " . $e->getMessage(), 'WARNING');
        return null;
    }
}

/**
 * オークション詳細情報の取得
 */
function extractAuctionDetailsFromRealHTML($xpath, &$errors, &$quality_score) {
    $details = [
        'auction_id' => null,
        'start_datetime' => null,
        'end_datetime' => null,
        'early_end' => false,
        'auto_extend' => false,
        'return_policy' => null,
        'bid_count' => 0
    ];
    
    try {
        // オークションID
        $auctionIdTh = $xpath->query('//th[contains(text(), "オークションID")]');
        if ($auctionIdTh->length > 0) {
            $auctionIdTd = $xpath->query('following-sibling::td', $auctionIdTh->item(0));
            if ($auctionIdTd->length > 0) {
                $details['auction_id'] = trim($auctionIdTd->item(0)->textContent);
            }
        }
        
        // 終了日時
        $endTimeTh = $xpath->query('//th[contains(text(), "終了日時")]');
        if ($endTimeTh->length > 0) {
            $endTimeTd = $xpath->query('following-sibling::td', $endTimeTh->item(0));
            if ($endTimeTd->length > 0) {
                $endTimeText = trim($endTimeTd->item(0)->textContent);
                // 2025年9月16日（火）22時1分 -> 2025-09-16 22:01:00
                if (preg_match('/(\d{4})年(\d{1,2})月(\d{1,2})日.*?(\d{1,2})時(\d{1,2})分/', $endTimeText, $matches)) {
                    $details['end_datetime'] = sprintf('%04d-%02d-%02d %02d:%02d:00', 
                        $matches[1], $matches[2], $matches[3], $matches[4], $matches[5]);
                }
            }
        }
        
        // 早期終了・自動延長
        $earlyEndTh = $xpath->query('//th[contains(text(), "早期終了")]');
        if ($earlyEndTh->length > 0) {
            $earlyEndTd = $xpath->query('following-sibling::td', $earlyEndTh->item(0));
            if ($earlyEndTd->length > 0) {
                $details['early_end'] = trim($earlyEndTd->item(0)->textContent) === 'あり';
            }
        }
        
        $autoExtendTh = $xpath->query('//th[contains(text(), "自動延長")]');
        if ($autoExtendTh->length > 0) {
            $autoExtendTd = $xpath->query('following-sibling::td', $autoExtendTh->item(0));
            if ($autoExtendTd->length > 0) {
                $details['auto_extend'] = trim($autoExtendTd->item(0)->textContent) === 'あり';
            }
        }
        
        writeLog("📋 [オークション詳細取得] ID: {$details['auction_id']}, 終了: {$details['end_datetime']}", 'SUCCESS');
        
    } catch (Exception $e) {
        writeLog("⚠️ [オークション詳細エラー] " . $e->getMessage(), 'WARNING');
        $quality_score -= 5;
    }
    
    return $details;
}

/**
 * 基本情報の取得
 */
function extractBasicInfoFromRealHTML($xpath, &$errors, &$quality_score) {
    $basic_info = [
        'quantity' => 1,
        'shipping_days' => null,
        'shipping_from' => null,
        'shipping_cost' => null,
        'payment_method' => null
    ];
    
    try {
        // 個数
        $quantityDt = $xpath->query('//dt[text()="個数"]');
        if ($quantityDt->length > 0) {
            $quantityDd = $xpath->query('following-sibling::dd', $quantityDt->item(0));
            if ($quantityDd->length > 0) {
                $quantityText = trim($quantityDd->item(0)->textContent);
                if (preg_match('/(\d+)/', $quantityText, $matches)) {
                    $basic_info['quantity'] = (int)$matches[1];
                }
            }
        }
        
        // 発送までの日数
        $shippingDaysDt = $xpath->query('//dt[contains(text(), "発送までの日数")]');
        if ($shippingDaysDt->length > 0) {
            $shippingDaysDd = $xpath->query('following-sibling::dd', $shippingDaysDt->item(0));
            if ($shippingDaysDd->length > 0) {
                $basic_info['shipping_days'] = trim($shippingDaysDd->item(0)->textContent);
            }
        }
        
        // 発送元の地域
        $shippingFromDt = $xpath->query('//dt[contains(text(), "発送元の地域")]');
        if ($shippingFromDt->length > 0) {
            $shippingFromDd = $xpath->query('following-sibling::dd', $shippingFromDt->item(0));
            if ($shippingFromDd->length > 0) {
                $basic_info['shipping_from'] = trim($shippingFromDd->item(0)->textContent);
            }
        }
        
        // 送料
        $shippingCostDt = $xpath->query('//dt[text()="送料"]');
        if ($shippingCostDt->length > 0) {
            $shippingCostDd = $xpath->query('following-sibling::dd', $shippingCostDt->item(0));
            if ($shippingCostDd->length > 0) {
                $basic_info['shipping_cost'] = trim($shippingCostDd->item(0)->textContent);
            }
        }
        
        // 支払い方法
        $paymentDt = $xpath->query('//dt[contains(text(), "支払い方法")]');
        if ($paymentDt->length > 0) {
            $paymentDd = $xpath->query('following-sibling::dd', $paymentDt->item(0));
            if ($paymentDd->length > 0) {
                $basic_info['payment_method'] = trim($paymentDd->item(0)->textContent);
            }
        }
        
        writeLog("📦 [基本情報取得] 個数: {$basic_info['quantity']}, 発送元: {$basic_info['shipping_from']}", 'SUCCESS');
        
    } catch (Exception $e) {
        writeLog("⚠️ [基本情報エラー] " . $e->getMessage(), 'WARNING');
        $quality_score -= 5;
    }
    
    return $basic_info;
}

/**
 * タイトル抽出（複数パターン対応）
 */
function extractTitleFromRealHTML($dom, $xpath, &$errors, &$quality_score) {
    try {
        // 複数のタイトル抽出パターン
        $title_patterns = [
            '//h1',
            '//title',
            '//*[@class and contains(@class, "ProductTitle")]',
            '//*[@class and contains(@class, "ItemTitle")]'
        ];
        
        foreach ($title_patterns as $pattern) {
            $titleElements = $xpath->query($pattern);
            if ($titleElements->length > 0) {
                $title = trim($titleElements->item(0)->textContent);
                
                // タイトルクリーニング
                $title = str_replace(' - Yahoo!オークション', '', $title);
                $title = preg_replace('/\s+/', ' ', $title);
                
                if (strlen($title) > 5 && strlen($title) < 200) {
                    writeLog("✅ [タイトル取得成功] " . substr($title, 0, 50) . "...", 'SUCCESS');
                    return $title;
                }
            }
        }
        
        $errors[] = "有効なタイトルが取得できません";
        $quality_score -= 20;
        return "タイトル取得失敗";
        
    } catch (Exception $e) {
        $errors[] = "タイトル抽出中にエラー: " . $e->getMessage();
        $quality_score -= 20;
        return "タイトル取得エラー";
    }
}

/**
 * 商用グレードデータ検証
 */
function validateRealHTMLData($data, $errors, $warnings, $quality_score) {
    $critical_errors = [];
    
    // 必須データの検証
    if (empty($data['title']) || $data['title'] === 'タイトル取得失敗') {
        $critical_errors[] = 'タイトルが取得できていません';
        $quality_score -= 30;
    }
    
    // 価格検証
    if (empty($data['price_data']['current_price']) && empty($data['price_data']['immediate_price'])) {
        $critical_errors[] = '価格情報が取得できていません';
        $quality_score -= 40;
    }
    
    // オークション形式の警告
    if ($data['auction_type'] === 'auction_only') {
        $warnings[] = 'オークション形式のため価格変動があります';
        $quality_score -= 15;
    }
    
    // 最終品質判定
    $status = 'valid';
    if (!empty($critical_errors)) {
        $status = 'invalid';
    } elseif ($quality_score < 70) {
        $status = 'warning';
    }
    
    return [
        'status' => $status,
        'quality_score' => max(0, $quality_score),
        'critical_errors' => $critical_errors,
        'is_valid' => empty($critical_errors) && $quality_score >= 50
    ];
}

/**
 * 商用説明文生成
 */
function generateCommercialDescription($title, $category_data, $condition, $brand) {
    $parts = [];
    
    if (!empty($title)) {
        $parts[] = $title;
    }
    
    if (!empty($category_data['final_category'])) {
        $parts[] = "カテゴリ: " . $category_data['final_category'];
    }
    
    if (!empty($condition)) {
        $parts[] = "状態: " . $condition;
    }
    
    if (!empty($brand)) {
        $parts[] = "ブランド: " . $brand;
    }
    
    if (!empty($category_data['category_path'])) {
        $parts[] = "カテゴリパス: " . implode(' > ', $category_data['category_path']);
    }
    
    return implode(" | ", $parts);
}

echo "✅ Real HTML Structure Parser 読み込み完了\n";
?>
