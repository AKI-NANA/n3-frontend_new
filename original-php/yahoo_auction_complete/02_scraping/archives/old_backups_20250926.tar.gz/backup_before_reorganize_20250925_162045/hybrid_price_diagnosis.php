<?php
/**
 * ハイブリッド価格システム診断・修正ツール
 * 現在の問題を特定し、editing.phpの表示を修正
 */

echo "<h1>🔍 ハイブリッド価格システム診断・修正</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. 現在のテーブル構造確認
    echo "<h2>1. yahoo_scraped_products テーブル構造確認</h2>";
    
    $columnSql = "SELECT column_name, data_type, is_nullable, column_default 
                  FROM information_schema.columns 
                  WHERE table_name = 'yahoo_scraped_products' 
                  ORDER BY ordinal_position";
    
    $columnStmt = $pdo->query($columnSql);
    $columns = $columnStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
    echo "<tr><th>カラム名</th><th>データ型</th><th>NULL許可</th><th>デフォルト値</th></tr>";
    
    $has_hybrid_columns = false;
    $required_columns = ['cached_price_usd', 'cache_rate', 'cache_updated_at'];
    $existing_columns = [];
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>{$column['column_name']}</td>";
        echo "<td>{$column['data_type']}</td>";
        echo "<td>{$column['is_nullable']}</td>";
        echo "<td>" . ($column['column_default'] ?: 'なし') . "</td>";
        echo "</tr>";
        
        $existing_columns[] = $column['column_name'];
        if (in_array($column['column_name'], $required_columns)) {
            $has_hybrid_columns = true;
        }
    }
    echo "</table>";
    
    // 不足しているカラムの確認
    $missing_columns = array_diff($required_columns, $existing_columns);
    
    if (!empty($missing_columns)) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
        echo "❌ ハイブリッド価格管理に必要なカラムが不足: " . implode(', ', $missing_columns);
        echo "</div>";
        
        echo "<h3>不足カラムの追加</h3>";
        foreach ($missing_columns as $column) {
            $alterSql = '';
            switch ($column) {
                case 'cached_price_usd':
                    $alterSql = "ALTER TABLE yahoo_scraped_products ADD COLUMN cached_price_usd DECIMAL(10, 2)";
                    break;
                case 'cache_rate':
                    $alterSql = "ALTER TABLE yahoo_scraped_products ADD COLUMN cache_rate DECIMAL(10, 4)";
                    break;
                case 'cache_updated_at':
                    $alterSql = "ALTER TABLE yahoo_scraped_products ADD COLUMN cache_updated_at TIMESTAMP";
                    break;
            }
            
            if ($alterSql) {
                try {
                    $pdo->exec($alterSql);
                    echo "<div style='color: green; padding: 5px;'>✅ {$column} カラム追加完了</div>";
                } catch (PDOException $e) {
                    echo "<div style='color: red; padding: 5px;'>❌ {$column} 追加エラー: " . $e->getMessage() . "</div>";
                }
            }
        }
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ ハイブリッド価格管理カラムは存在します</div>";
    }
    
    // 2. 現在のデータ状況確認
    echo "<h2>2. 現在のデータ状況確認</h2>";
    
    $dataSql = "SELECT 
                    COUNT(*) as total_count,
                    COUNT(CASE WHEN price_jpy > 0 THEN 1 END) as has_jpy_price,
                    COUNT(CASE WHEN cached_price_usd IS NOT NULL THEN 1 END) as has_cached_usd,
                    COUNT(CASE WHEN active_price_usd IS NOT NULL THEN 1 END) as has_active_usd,
                    AVG(price_jpy) as avg_jpy,
                    AVG(cached_price_usd) as avg_cached_usd,
                    AVG(active_price_usd) as avg_active_usd
                FROM yahoo_scraped_products";
    
    $dataStmt = $pdo->query($dataSql);
    $dataStats = $dataStmt->fetch();
    
    echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 5px;'>";
    echo "<h4>データ統計:</h4>";
    echo "<p><strong>総データ数:</strong> {$dataStats['total_count']}件</p>";
    echo "<p><strong>円価格あり:</strong> {$dataStats['has_jpy_price']}件</p>";
    echo "<p><strong>キャッシュUSDあり:</strong> {$dataStats['has_cached_usd']}件</p>";
    echo "<p><strong>アクティブUSDあり:</strong> {$dataStats['has_active_usd']}件</p>";
    echo "<p><strong>平均円価格:</strong> ¥" . number_format($dataStats['avg_jpy'] ?: 0) . "</p>";
    echo "<p><strong>平均キャッシュUSD:</strong> $" . number_format($dataStats['avg_cached_usd'] ?: 0, 2) . "</p>";
    echo "<p><strong>平均アクティブUSD:</strong> $" . number_format($dataStats['avg_active_usd'] ?: 0, 2) . "</p>";
    echo "</div>";
    
    // 3. 問題のあるデータ確認
    echo "<h2>3. 問題のあるデータ確認</h2>";
    
    $problemSql = "SELECT id, source_item_id, active_title, price_jpy, active_price_usd, cached_price_usd, cache_rate
                   FROM yahoo_scraped_products 
                   WHERE price_jpy > 0 
                   ORDER BY id DESC 
                   LIMIT 5";
    
    $problemStmt = $pdo->query($problemSql);
    $problemData = $problemStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($problemData)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
        echo "<tr><th>ID</th><th>source_item_id</th><th>タイトル</th><th>円価格</th><th>アクティブUSD</th><th>キャッシュUSD</th><th>問題</th></tr>";
        
        foreach ($problemData as $row) {
            echo "<tr>";
            echo "<td>{$row['id']}</td>";
            echo "<td>" . substr($row['source_item_id'], 0, 20) . "...</td>";
            echo "<td>" . substr($row['active_title'], 0, 30) . "...</td>";
            echo "<td style='font-weight: bold; color: #2e8b57;'>¥" . number_format($row['price_jpy']) . "</td>";
            echo "<td style='color: #dc143c;'>$" . number_format($row['active_price_usd'] ?: 0, 2) . "</td>";
            echo "<td style='color: #4682b4;'>$" . number_format($row['cached_price_usd'] ?: 0, 2) . "</td>";
            
            $problems = [];
            if ($row['price_jpy'] > 0 && $row['cached_price_usd'] === null) {
                $problems[] = "キャッシュなし";
            }
            if ($row['active_price_usd'] && $row['price_jpy'] > 0) {
                $expected_usd = round($row['price_jpy'] / 150, 2);
                if (abs($row['active_price_usd'] - $expected_usd) > 1) {
                    $problems[] = "USD価格異常";
                }
            }
            
            echo "<td>" . (empty($problems) ? "✅ 正常" : "❌ " . implode(", ", $problems)) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // 4. キャッシュ価格の一括更新
    echo "<h2>4. キャッシュ価格の一括更新</h2>";
    
    $updateCacheSql = "UPDATE yahoo_scraped_products 
                       SET cached_price_usd = ROUND(price_jpy / 150.0, 2),
                           cache_rate = 150.0,
                           cache_updated_at = CURRENT_TIMESTAMP
                       WHERE price_jpy > 0";
    
    $updateResult = $pdo->exec($updateCacheSql);
    echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>🔄 {$updateResult}件のキャッシュ価格を更新しました</div>";
    
    // 5. editing.phpの表示修正
    echo "<h2>5. editing.php表示修正コード生成</h2>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px;'>";
    echo "<h4>editing.phpに追加するSQL修正:</h4>";
    echo "<pre style='background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto;'>";
    echo htmlspecialchars('
// ハイブリッド価格管理対応SQL（円価格を優先表示）
$sql = "SELECT 
            id,
            source_item_id as item_id,
            COALESCE(active_title, \'タイトルなし\') as title,
            price_jpy as price,  -- 円価格を優先
            cached_price_usd as current_price,  -- キャッシュUSD価格
            COALESCE((scraped_yahoo_data->>\'category\')::text, category, \'N/A\') as category_name,
            COALESCE((scraped_yahoo_data->>\'condition\')::text, condition_name, \'N/A\') as condition_name,
            COALESCE(active_image_url, \'https://placehold.co/150x150/725CAD/FFFFFF/png?text=No+Image\') as picture_url,
            (scraped_yahoo_data->>\'url\')::text as source_url,
            updated_at,
            CASE 
                WHEN (scraped_yahoo_data->>\'url\')::text LIKE \'%auctions.yahoo.co.jp%\' THEN \'ヤフオク\'
                WHEN (scraped_yahoo_data->>\'url\')::text LIKE \'%yahoo.co.jp%\' THEN \'Yahoo\'
                ELSE \'Unknown\'
            END as platform,
            sku as master_sku,
            CASE 
                WHEN ebay_item_id IS NULL OR ebay_item_id = \'\' THEN \'not_listed\'
                ELSE \'listed\'
            END as listing_status,
            status,
            current_stock,
            ebay_item_id
        FROM {$actualTable} 
        {$whereClause} 
        ORDER BY updated_at DESC, id DESC 
        LIMIT ? OFFSET ?";
    ');
    echo "</pre>";
    echo "</div>";
    
    // 6. 更新後データ確認
    echo "<h2>6. 更新後データ確認</h2>";
    
    $verifyStmt = $pdo->query($problemSql);
    $verifyData = $verifyStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
    echo "<tr><th>ID</th><th>円価格</th><th>キャッシュUSD</th><th>レート</th><th>更新日時</th><th>状態</th></tr>";
    
    foreach ($verifyData as $row) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td style='font-weight: bold; color: #2e8b57;'>¥" . number_format($row['price_jpy']) . "</td>";
        echo "<td style='color: #4682b4;'>$" . number_format($row['cached_price_usd'] ?: 0, 2) . "</td>";
        echo "<td>{$row['cache_rate']}</td>";
        echo "<td>" . date('Y-m-d H:i', strtotime($row['cache_updated_at'] ?? 'now')) . "</td>";
        echo "<td>" . ($row['cached_price_usd'] ? "✅ 正常" : "❌ 未更新") . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 7. 次のステップ
    echo "<h2>7. 次のステップ</h2>";
    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
    echo "<ol>";
    echo "<li><strong>editing.php修正</strong> - 上記のSQL文を適用</li>";
    echo "<li><strong>価格表示形式修正</strong> - 円価格を優先表示、ドル価格は補助</li>";
    echo "<li><strong>スクレイピング再実行</strong> - ハイブリッド方式での保存確認</li>";
    echo "<li><strong>同一商品上書きテスト</strong> - 重複防止機能確認</li>";
    echo "</ol>";
    echo "</div>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-radius: 5px; margin-top: 15px;'>";
    echo "<h4>⚠️ 重要な修正ポイント:</h4>";
    echo "<ul>";
    echo "<li><strong>price_jpy</strong> を主要価格として表示</li>";
    echo "<li><strong>cached_price_usd</strong> をcurrent_priceとして使用</li>";
    echo "<li><strong>platform判定</strong> をヤフオク優先に修正</li>";
    echo "<li><strong>同一source_item_id</strong> での上書き確認</li>";
    echo "</ul>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p><a href='scraping.php'>← スクレイピングに戻る</a> | <a href='../05_editing/editing.php'>データ編集へ →</a></p>";
?>
