<?php
/**
 * emergency_fix_test.php実行テスト・問題診断
 */

header('Content-Type: text/html; charset=UTF-8');

echo "<h1>Emergency Fix Test 実行診断</h1>";
echo "<h2>基本動作確認</h2>";

// 1. 基本ファイル存在確認
echo "<h3>1. ファイル存在確認</h3>";
$target_file = '/Users/aritahiroaki/NAGANO-3/N3-Development/modules/yahoo_auction_complete/new_structure/02_scraping/emergency_fix_test.php';
$parser_file = '/Users/aritahiroaki/NAGANO-3/N3-Development/modules/yahoo_auction_complete/new_structure/02_scraping/yahoo_parser_emergency.php';

echo "emergency_fix_test.php: " . (file_exists($target_file) ? "✅ 存在" : "❌ 不存在") . "<br>";
echo "yahoo_parser_emergency.php: " . (file_exists($parser_file) ? "✅ 存在" : "❌ 不存在") . "<br>";

// 2. HTMLコンテンツ取得テスト
echo "<h3>2. HTML取得テスト</h3>";
$test_url = 'https://auctions.yahoo.co.jp/jp/auction/l1200404917';

$context = stream_context_create([
    'http' => [
        'header' => "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n",
        'timeout' => 10
    ]
]);

echo "テスト対象URL: $test_url<br>";
$html = @file_get_contents($test_url, false, $context);

if ($html) {
    echo "✅ HTML取得成功: " . strlen($html) . " 文字<br>";
    echo "内容サンプル: " . htmlspecialchars(substr($html, 0, 200)) . "...<br>";
} else {
    echo "❌ HTML取得失敗<br>";
    $error = error_get_last();
    if ($error) {
        echo "エラー: " . htmlspecialchars($error['message']) . "<br>";
    }
}

// 3. パーサー関数存在確認
echo "<h3>3. パーサー関数確認</h3>";
if (file_exists($parser_file)) {
    require_once $parser_file;
    
    if (function_exists('parseYahooAuctionHTML_Fixed_Emergency')) {
        echo "✅ parseYahooAuctionHTML_Fixed_Emergency関数存在<br>";
        
        if ($html) {
            echo "<h4>パーサー実行テスト</h4>";
            try {
                $result = parseYahooAuctionHTML_Fixed_Emergency($html, $test_url, 'l1200404917');
                echo "✅ パーサー実行成功<br>";
                echo "価格: " . ($result['current_price'] ?? 'N/A') . "<br>";
                echo "状態: " . ($result['condition'] ?? 'N/A') . "<br>";
                echo "画像数: " . count($result['images'] ?? []) . "<br>";
                echo "品質スコア: " . ($result['data_quality'] ?? 'N/A') . "%<br>";
            } catch (Exception $e) {
                echo "❌ パーサー実行エラー: " . htmlspecialchars($e->getMessage()) . "<br>";
            }
        }
    } else {
        echo "❌ parseYahooAuctionHTML_Fixed_Emergency関数不存在<br>";
    }
} else {
    echo "❌ yahoo_parser_emergency.php読み込み不可<br>";
}

// 4. データベース接続テスト
echo "<h3>4. データベース接続テスト</h3>";
try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "✅ データベース接続成功<br>";
    
    // テーブル存在確認
    $tables = $pdo->query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")->fetchAll(PDO::FETCH_COLUMN);
    echo "利用可能テーブル: " . implode(', ', $tables) . "<br>";
    
    if (in_array('yahoo_scraped_products', $tables)) {
        $count = $pdo->query("SELECT COUNT(*) FROM yahoo_scraped_products")->fetchColumn();
        echo "yahoo_scraped_products レコード数: $count<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ データベース接続失敗: " . htmlspecialchars($e->getMessage()) . "<br>";
}

// 5. emergency_fix_test.php直接実行
echo "<h3>5. emergency_fix_test.php 内容実行</h3>";
echo "<p>現在のemergency_fix_test.phpを実行してみます...</p>";
echo "<iframe src='emergency_fix_test.php' width='100%' height='600px' style='border:1px solid #ccc;'></iframe>";

echo "<h2>診断完了</h2>";
echo "<p>上記の結果から問題を特定して修正方針を決定します。</p>";
?>
