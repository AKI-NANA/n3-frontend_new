<?php
/**
 * 詳細デバッグ付きUPSERT関数
 * エラーの根本原因を特定するための包括的なログ機能
 */

// 詳細デバッグ付きUPSERT関数
function saveProductToDatabaseDebug($product_data) {
    try {
        writeLog("🚀 [DEBUG UPSERT開始] 詳細デバッグ付きUPSERT開始", 'INFO');
        
        // 接続前ログ
        writeLog("🔌 [接続試行] PostgreSQL接続を開始します", 'INFO');
        
        $dsn = "pgsql:host=localhost;dbname=nagano3_db";
        $user = "postgres";
        $password = "Kn240914";
        
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        writeLog("✅ [接続成功] PostgreSQL接続確立", 'SUCCESS');
        
        // テーブル存在確認
        $tableCheckSql = "SELECT table_name FROM information_schema.tables WHERE table_name = 'yahoo_scraped_products'";
        $tableStmt = $pdo->query($tableCheckSql);
        $tableExists = $tableStmt->fetch();
        
        if (!$tableExists) {
            writeLog("❌ [テーブル不存在] yahoo_scraped_products テーブルが見つかりません", 'ERROR');
            return false;
        }
        
        writeLog("✅ [テーブル確認] yahoo_scraped_products テーブル存在確認", 'SUCCESS');
        
        // 入力データ詳細確認
        if (!$product_data || !is_array($product_data)) {
            writeLog("❌ [入力データエラー] 無効な商品データです", 'ERROR');
            writeLog("🔍 [入力データ] " . gettype($product_data), 'DEBUG');
            return false;
        }
        
        writeLog("✅ [入力データ] 配列形式の商品データを受信", 'SUCCESS');
        writeLog("🔍 [入力データキー] " . implode(', ', array_keys($product_data)), 'DEBUG');
        
        // データ準備
        $source_item_id = $product_data['item_id'] ?? 'SCRAPED_' . time() . '_' . rand(100, 999);
        $price_jpy = (int)($product_data['current_price'] ?? 0);
        $active_title = $product_data['title'] ?? 'タイトル不明';
        $active_description = $product_data['description'] ?? '';
        $active_price_usd = $price_jpy > 0 ? round($price_jpy / 150, 2) : null;
        $active_image_url = (!empty($product_data['images']) && isset($product_data['images'][0])) 
            ? $product_data['images'][0] 
            : 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image';
        $current_stock = 1;
        $status = 'scraped';
        
        // データ準備ログ
        writeLog("📝 [データ準備] source_item_id: {$source_item_id}", 'INFO');
        writeLog("📝 [データ準備] price_jpy: {$price_jpy}", 'INFO');
        writeLog("📝 [データ準備] title: " . substr($active_title, 0, 50) . "...", 'INFO');
        writeLog("📝 [データ準備] image_url: {$active_image_url}", 'INFO');
        
        // 文字列長制限チェック
        if (strlen($active_title) > 5000) {
            $active_title = substr($active_title, 0, 4997) . '...';
            writeLog("⚠️ [文字列制限] タイトルを5000文字に切り詰めました", 'WARNING');
        }
        
        if (strlen($active_description) > 10000) {
            $active_description = substr($active_description, 0, 9997) . '...';
            writeLog("⚠️ [文字列制限] 説明を10000文字に切り詰めました", 'WARNING');
        }
        
        // JSONデータ構築
        $scraped_yahoo_data_array = [
            'category' => $product_data['category'] ?? 'Unknown',
            'condition' => $product_data['condition'] ?? 'Used',
            'url' => $product_data['source_url'] ?? '',
            'seller_name' => $product_data['seller_info']['name'] ?? 'Unknown',
            'bid_count' => $product_data['auction_info']['bid_count'] ?? 0,
            'end_time' => $product_data['auction_info']['end_time'] ?? '',
            'scraped_at' => date('Y-m-d H:i:s'),
            'scraping_method' => $product_data['scraping_method'] ?? 'unknown',
            'data_quality' => $product_data['data_quality'] ?? null,
            'extraction_success' => $product_data['extraction_success'] ?? null
        ];
        
        $scraped_yahoo_data = json_encode($scraped_yahoo_data_array, JSON_UNESCAPED_UNICODE);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            writeLog("❌ [JSONエラー] JSONエンコード失敗: " . json_last_error_msg(), 'ERROR');
            $scraped_yahoo_data = json_encode([
                'error' => 'JSON encoding failed',
                'scraped_at' => date('Y-m-d H:i:s')
            ], JSON_UNESCAPED_UNICODE);
        }
        
        writeLog("✅ [JSON作成] JSONデータ作成完了: " . strlen($scraped_yahoo_data) . "文字", 'SUCCESS');
        
        // テーブル構造確認
        writeLog("🔍 [テーブル構造確認] カラム存在チェック開始", 'INFO');
        $columnCheckSql = "SELECT column_name FROM information_schema.columns WHERE table_name = 'yahoo_scraped_products'";
        $columnStmt = $pdo->query($columnCheckSql);
        $columns = $columnStmt->fetchAll(PDO::FETCH_COLUMN);
        
        $required_columns = ['source_item_id', 'price_jpy', 'scraped_yahoo_data', 'active_title', 'active_description', 'active_price_usd', 'active_image_url', 'current_stock', 'status'];
        $missing_columns = array_diff($required_columns, $columns);
        
        if (!empty($missing_columns)) {
            writeLog("❌ [カラム不足] 必要なカラムが不足: " . implode(', ', $missing_columns), 'ERROR');
            return false;
        }
        
        writeLog("✅ [テーブル構造] 必要なカラムが全て存在", 'SUCCESS');
        
        // ユニーク制約確認
        $constraintCheckSql = "SELECT constraint_name FROM information_schema.table_constraints WHERE table_name = 'yahoo_scraped_products' AND constraint_type = 'UNIQUE'";
        $constraintStmt = $pdo->query($constraintCheckSql);
        $constraints = $constraintStmt->fetchAll(PDO::FETCH_COLUMN);
        
        $has_unique_constraint = !empty($constraints);
        writeLog("🔍 [制約確認] ユニーク制約: " . ($has_unique_constraint ? "存在" : "なし"), $has_unique_constraint ? 'SUCCESS' : 'WARNING');
        
        // UPSERT実行
        writeLog("🔄 [UPSERT実行] SQL実行開始", 'INFO');
        
        if ($has_unique_constraint) {
            // ユニーク制約がある場合：ON CONFLICT使用
            $sql = "INSERT INTO yahoo_scraped_products (
                source_item_id, price_jpy, scraped_yahoo_data, active_title,
                active_description, active_price_usd, active_image_url, current_stock,
                status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ON CONFLICT (source_item_id) DO UPDATE SET
                active_title = EXCLUDED.active_title,
                price_jpy = EXCLUDED.price_jpy,
                scraped_yahoo_data = EXCLUDED.scraped_yahoo_data,
                active_description = EXCLUDED.active_description,
                active_price_usd = EXCLUDED.active_price_usd,
                active_image_url = EXCLUDED.active_image_url,
                current_stock = EXCLUDED.current_stock,
                status = EXCLUDED.status,
                updated_at = CURRENT_TIMESTAMP";
        } else {
            // ユニーク制約がない場合：通常のINSERT
            writeLog("⚠️ [制約なし] ユニーク制約がないため通常のINSERTを使用", 'WARNING');
            $sql = "INSERT INTO yahoo_scraped_products (
                source_item_id, price_jpy, scraped_yahoo_data, active_title,
                active_description, active_price_usd, active_image_url, current_stock,
                status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        }
        
        $params = [
            $source_item_id, $price_jpy, $scraped_yahoo_data, $active_title,
            $active_description, $active_price_usd, $active_image_url, $current_stock, $status
        ];
        
        writeLog("📋 [SQLパラメータ] パラメータ数: " . count($params), 'DEBUG');
        writeLog("📋 [SQLパラメータ] source_item_id: {$source_item_id}, price: {$price_jpy}", 'DEBUG');
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            writeLog("✅ [SQL実行成功] クエリ実行完了", 'SUCCESS');
            
            // 結果確認
            $verifySql = "SELECT id, source_item_id, active_title, price_jpy, created_at, updated_at FROM yahoo_scraped_products WHERE source_item_id = ?";
            $verifyStmt = $pdo->prepare($verifySql);
            $verifyStmt->execute([$source_item_id]);
            $saved = $verifyStmt->fetch();
            
            if ($saved) {
                $action = ($saved['created_at'] === $saved['updated_at']) ? 'INSERT（新規作成）' : 'UPDATE（既存更新）';
                writeLog("✅ [保存確認成功] {$action} - ID: {$saved['id']}", 'SUCCESS');
                writeLog("📊 [保存データ] Title: {$saved['active_title']}, Price: ¥{$saved['price_jpy']}", 'SUCCESS');
                writeLog("📅 [タイムスタンプ] 作成: {$saved['created_at']}, 更新: {$saved['updated_at']}", 'INFO');
                
                return true;
            } else {
                writeLog("❌ [保存確認失敗] 保存されたデータが見つかりません", 'ERROR');
                return false;
            }
        } else {
            writeLog("❌ [SQL実行失敗] クエリ実行に失敗", 'ERROR');
            writeLog("❌ [エラー詳細] " . json_encode($stmt->errorInfo()), 'ERROR');
            return false;
        }
        
    } catch (PDOException $e) {
        writeLog("❌ [PDOエラー] " . $e->getMessage(), 'ERROR');
        writeLog("❌ [SQLState] " . $e->getCode(), 'ERROR');
        writeLog("❌ [ErrorInfo] " . json_encode($e->errorInfo ?? []), 'ERROR');
        
        // エラー種別判定
        $errorMessage = $e->getMessage();
        if (strpos($errorMessage, 'column') !== false && strpos($errorMessage, 'does not exist') !== false) {
            writeLog("🚨 [カラム不存在エラー] 指定されたカラムが存在しません", 'ERROR');
        } elseif (strpos($errorMessage, 'relation') !== false && strpos($errorMessage, 'does not exist') !== false) {
            writeLog("🚨 [テーブル不存在エラー] yahoo_scraped_products テーブルが存在しません", 'ERROR');
        } elseif (strpos($errorMessage, 'duplicate key') !== false) {
            writeLog("🚨 [重複キーエラー] source_item_id が重複しています", 'ERROR');
        } elseif (strpos($errorMessage, 'violates not-null') !== false) {
            writeLog("🚨 [NULL制約エラー] 必須項目にNULLが設定されています", 'ERROR');
        } elseif (strpos($errorMessage, 'value too long') !== false) {
            writeLog("🚨 [文字列長エラー] 文字列が長すぎます", 'ERROR');
        }
        
        return false;
    } catch (Exception $e) {
        writeLog("❌ [予期しないエラー] " . $e->getMessage(), 'ERROR');
        return false;
    }
}

writeLog("✅ [デバッグ関数準備完了] saveProductToDatabaseDebug を定義しました", 'SUCCESS');
?>
