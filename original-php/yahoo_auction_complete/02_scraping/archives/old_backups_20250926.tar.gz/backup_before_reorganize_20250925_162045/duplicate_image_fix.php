<?php
/**
 * 重複データ・画像問題緊急修正ツール
 * ゲンガー重複問題と画像表示問題を解決
 */

echo "<h1>🚨 重複データ・画像問題緊急修正ツール</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. 重複データの詳細確認
    echo "<h2>1. 🔍 重複データの詳細確認</h2>";
    
    $duplicateSql = "SELECT source_item_id, COUNT(*) as count, 
                            array_agg(id ORDER BY created_at DESC) as ids,
                            array_agg(active_title ORDER BY created_at DESC) as titles,
                            array_agg(created_at ORDER BY created_at DESC) as dates
                     FROM yahoo_scraped_products 
                     GROUP BY source_item_id 
                     HAVING COUNT(*) > 1 
                     ORDER BY count DESC";
    
    $duplicateStmt = $pdo->query($duplicateSql);
    $duplicates = $duplicateStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($duplicates)) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ 重複データが発見されました:</div>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
        echo "<tr><th>source_item_id</th><th>重複数</th><th>データベースID</th><th>タイトル</th><th>作成日時</th><th>アクション</th></tr>";
        
        foreach ($duplicates as $duplicate) {
            $ids = explode(',', trim($duplicate['ids'], '{}'));
            $titles = explode(',', trim($duplicate['titles'], '{}'));
            $dates = explode(',', trim($duplicate['dates'], '{}'));
            
            echo "<tr>";
            echo "<td><strong>{$duplicate['source_item_id']}</strong></td>";
            echo "<td style='color: red; font-weight: bold;'>{$duplicate['count']}件</td>";
            echo "<td>";
            for ($i = 0; $i < count($ids); $i++) {
                $color = $i === 0 ? 'green' : 'red';
                $label = $i === 0 ? '保持' : '削除対象';
                echo "<span style='color: {$color};'>ID {$ids[$i]} ({$label})</span><br>";
            }
            echo "</td>";
            echo "<td>";
            for ($i = 0; $i < count($titles); $i++) {
                echo substr($titles[$i], 0, 30) . "...<br>";
            }
            echo "</td>";
            echo "<td>";
            for ($i = 0; $i < count($dates); $i++) {
                echo $dates[$i] . "<br>";
            }
            echo "</td>";
            echo "<td>";
            if (count($ids) > 1) {
                echo "<button onclick=\"deleteDuplicates('" . implode(',', array_slice($ids, 1)) . "')\" style='background: #dc3545; color: white; border: none; padding: 5px 10px; border-radius: 3px;'>重複削除</button>";
            }
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // 自動重複削除実行
        echo "<h3>🔧 自動重複削除実行</h3>";
        $deleteDuplicatesSql = "DELETE FROM yahoo_scraped_products 
                                WHERE id NOT IN (
                                    SELECT DISTINCT ON (source_item_id) id 
                                    FROM yahoo_scraped_products 
                                    ORDER BY source_item_id, updated_at DESC
                                )";
        
        $deleteResult = $pdo->exec($deleteDuplicatesSql);
        echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>🗑️ {$deleteResult}件の重複データを自動削除しました</div>";
        
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ 重複データは見つかりませんでした</div>";
    }
    
    // 2. 画像データの詳細確認
    echo "<h2>2. 🖼️ 画像データの詳細確認</h2>";
    
    $imageSql = "SELECT id, source_item_id, active_title, active_image_url,
                        (scraped_yahoo_data->>'images')::text as scraped_images,
                        (scraped_yahoo_data->>'all_images')::text as all_images,
                        LENGTH(active_image_url) as image_url_length
                 FROM yahoo_scraped_products 
                 ORDER BY id DESC 
                 LIMIT 5";
    
    $imageStmt = $pdo->query($imageSql);
    $imageData = $imageStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
    echo "<tr><th>ID</th><th>タイトル</th><th>active_image_url</th><th>URL長</th><th>scraped画像データ</th><th>問題</th></tr>";
    
    foreach ($imageData as $row) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td>" . substr($row['active_title'], 0, 30) . "...</td>";
        echo "<td>";
        if ($row['active_image_url']) {
            if (strlen($row['active_image_url']) > 50) {
                echo "<span style='color: green;'>✅ " . substr($row['active_image_url'], 0, 50) . "...</span>";
            } else {
                echo "<span style='color: green;'>✅ " . $row['active_image_url'] . "</span>";
            }
        } else {
            echo "<span style='color: red;'>❌ 画像URLなし</span>";
        }
        echo "</td>";
        echo "<td>{$row['image_url_length']}</td>";
        echo "<td>";
        if ($row['scraped_images'] || $row['all_images']) {
            echo "<span style='color: green;'>✅ 画像データあり</span>";
        } else {
            echo "<span style='color: red;'>❌ 画像データなし</span>";
        }
        echo "</td>";
        echo "<td>";
        $problems = [];
        if (!$row['active_image_url']) {
            $problems[] = "active_image_url なし";
        }
        if (!$row['scraped_images'] && !$row['all_images']) {
            $problems[] = "scraped画像データなし";
        }
        if (empty($problems)) {
            echo "✅ 正常";
        } else {
            echo "❌ " . implode(", ", $problems);
        }
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 3. UNIQUE制約の確認と追加
    echo "<h2>3. 🔒 UNIQUE制約の確認と追加</h2>";
    
    $constraintSql = "SELECT constraint_name, constraint_type 
                      FROM information_schema.table_constraints 
                      WHERE table_name = 'yahoo_scraped_products' 
                      AND constraint_type = 'UNIQUE'";
    
    $constraintStmt = $pdo->query($constraintSql);
    $constraints = $constraintStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($constraints)) {
        echo "<div style='color: orange; padding: 10px; background: #fff3cd;'>⚠️ UNIQUE制約が設定されていません</div>";
        
        // UNIQUE制約を追加
        try {
            $addConstraintSql = "ALTER TABLE yahoo_scraped_products ADD CONSTRAINT unique_source_item_id UNIQUE (source_item_id)";
            $pdo->exec($addConstraintSql);
            echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ source_item_id にUNIQUE制約を追加しました</div>";
        } catch (PDOException $e) {
            echo "<div style='color: red; padding: 10px; background: #ffe6e6;'>❌ UNIQUE制約追加エラー: " . $e->getMessage() . "</div>";
            echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>💡 重複データを削除してから制約を追加してください</div>";
        }
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ UNIQUE制約が設定されています:</div>";
        foreach ($constraints as $constraint) {
            echo "<p>- {$constraint['constraint_name']} ({$constraint['constraint_type']})</p>";
        }
    }
    
    // 4. source_item_id正規化
    echo "<h2>4. 🔧 source_item_id正規化</h2>";
    
    $normalizeCheckSql = "SELECT id, source_item_id, 
                                 CASE 
                                     WHEN source_item_id ~ '_[0-9]{14}$' THEN 
                                         SUBSTRING(source_item_id FROM '^(.+)_[0-9]{14}$')
                                     ELSE source_item_id
                                 END as normalized_id
                          FROM yahoo_scraped_products 
                          WHERE source_item_id ~ '_[0-9]{14}$'";
    
    $normalizeStmt = $pdo->query($normalizeCheckSql);
    $normalizeData = $normalizeStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($normalizeData)) {
        echo "<div style='color: orange; padding: 10px; background: #fff3cd;'>⚠️ タイムスタンプ付きsource_item_idが見つかりました:</div>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>現在のsource_item_id</th><th>正規化後</th><th>アクション</th></tr>";
        
        foreach ($normalizeData as $row) {
            echo "<tr>";
            echo "<td>{$row['id']}</td>";
            echo "<td style='color: red;'>{$row['source_item_id']}</td>";
            echo "<td style='color: green;'>{$row['normalized_id']}</td>";
            echo "<td><button onclick=\"normalizeId({$row['id']}, '{$row['normalized_id']}')\" style='background: #007bff; color: white; border: none; padding: 5px 10px;'>正規化</button></td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // 自動正規化実行
        echo "<h3>🔧 自動正規化実行</h3>";
        $normalizeUpdateSql = "UPDATE yahoo_scraped_products 
                               SET source_item_id = SUBSTRING(source_item_id FROM '^(.+)_[0-9]{14}$')
                               WHERE source_item_id ~ '_[0-9]{14}$'";
        
        $normalizeResult = $pdo->exec($normalizeUpdateSql);
        echo "<div style='color: blue; padding: 10px; background: #e3f2fd;'>🔄 {$normalizeResult}件のsource_item_idを正規化しました</div>";
        
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8;'>✅ source_item_idは既に正規化されています</div>";
    }
    
    // 5. 画像表示修正用スクリプト生成
    echo "<h2>5. 🖼️ 画像表示修正用スクリプト</h2>";
    
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>";
    echo "<h4>JavaScript修正コード (editing.js に追加):</h4>";
    echo "<pre style='background: #e9ecef; padding: 10px; border-radius: 3px; overflow-x: auto;'>";
    echo htmlspecialchars('
// 画像表示修正関数
function extractImagesFromData(product) {
    let images = [];
    
    // 1. active_image_url から取得
    if (product.active_image_url && !product.active_image_url.includes("placehold")) {
        images.push(product.active_image_url);
    }
    
    // 2. scraped_yahoo_data から取得
    if (product.scraped_yahoo_data) {
        try {
            const scrapedData = typeof product.scraped_yahoo_data === "string" 
                ? JSON.parse(product.scraped_yahoo_data) 
                : product.scraped_yahoo_data;
            
            if (scrapedData.all_images && Array.isArray(scrapedData.all_images)) {
                images = images.concat(scrapedData.all_images);
            }
            
            if (scrapedData.images && Array.isArray(scrapedData.images)) {
                images = images.concat(scrapedData.images);
            }
        } catch (e) {
            console.log("画像データ解析エラー:", e);
        }
    }
    
    // 重複除去
    images = [...new Set(images)];
    
    return images.length > 0 ? images : ["https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image"];
}

// createProductDetailsModalFromTable 関数を修正
function createProductDetailsModalFromTable(product) {
    const images = extractImagesFromData(product);
    const primaryImage = images[0];
    
    // 画像ギャラリー生成
    const imageGalleryHtml = images.length > 1 ? `
        <div style="margin-top: 15px;">
            <h4 style="margin: 0 0 10px 0; color: #1f2937;">🖼️ 商品画像 (${images.length}枚)</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 8px;">
                ${images.map((img, index) => `
                    <div style="border: 1px solid #ddd; padding: 3px; border-radius: 4px; text-align: center; cursor: pointer;" onclick="openImagePreview(\'${img}\')">
                        <img src="${img}" style="max-width: 100%; height: 80px; object-fit: cover; border-radius: 3px;" alt="商品画像${index + 1}" loading="lazy">
                        <div style="font-size: 10px; color: #666; margin-top: 2px;">画像${index + 1}</div>
                    </div>
                `).join("")}
            </div>
        </div>
    ` : `
        <div style="margin-top: 15px;">
            <h4 style="margin: 0 0 10px 0; color: #1f2937;">🖼️ 商品画像</h4>
            <div style="text-align: center;">
                <img src="${primaryImage}" alt="商品画像" style="max-width: 300px; max-height: 200px; object-fit: cover; border-radius: 8px; border: 1px solid #ddd;" onclick="openImagePreview(\'${primaryImage}\')" style="cursor: pointer;">
            </div>
        </div>
    `;
    
    // 既存のmodal HTMLに imageGalleryHtml を追加
    // ...
}
    ');
    echo "</pre>";
    echo "</div>";
    
    // 6. 修正後の確認
    echo "<h2>6. 📊 修正後のデータ確認</h2>";
    
    $finalCheckSql = "SELECT id, source_item_id, active_title, 
                             CASE WHEN active_image_url IS NOT NULL THEN '✅' ELSE '❌' END as has_image,
                             created_at, updated_at
                      FROM yahoo_scraped_products 
                      ORDER BY updated_at DESC";
    
    $finalStmt = $pdo->query($finalCheckSql);
    $finalData = $finalStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
    echo "<tr><th>ID</th><th>source_item_id</th><th>タイトル</th><th>画像</th><th>作成日時</th><th>状態</th></tr>";
    
    foreach ($finalData as $row) {
        echo "<tr>";
        echo "<td>{$row['id']}</td>";
        echo "<td style='font-family: monospace;'>{$row['source_item_id']}</td>";
        echo "<td>" . substr($row['active_title'], 0, 30) . "...</td>";
        echo "<td style='text-align: center;'>{$row['has_image']}</td>";
        echo "<td style='font-size: 0.7em;'>" . date('Y-m-d H:i', strtotime($row['created_at'])) . "</td>";
        echo "<td>" . ($row['created_at'] === $row['updated_at'] ? '新規' : '更新済み') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 7. 次のアクション
    echo "<h2>7. 📋 次のアクション</h2>";
    echo "<div style='background: #e8f5e8; padding: 15px; border-radius: 5px;'>";
    echo "<h4>✅ 完了した修正:</h4>";
    echo "<ul>";
    echo "<li>重複データの自動削除</li>";
    echo "<li>source_item_id の正規化</li>";
    echo "<li>UNIQUE制約の追加</li>";
    echo "<li>画像データの確認</li>";
    echo "</ul>";
    
    echo "<h4>🔧 手動で実行すべき作業:</h4>";
    echo "<ol>";
    echo "<li><strong>editing.js の修正</strong> - 上記の画像表示修正コードを追加</li>";
    echo "<li><strong>スクレイピング再実行</strong> - 同一商品での上書きテスト</li>";
    echo "<li><strong>モーダル表示確認</strong> - 画像が正しく表示されるかテスト</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p style='text-align: center;'>";
echo "<a href='../05_editing/editing.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>📝 editing.phpで確認</a>";
echo "<a href='scraping.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>🕷️ スクレイピングで上書きテスト</a>";
echo "</p>";

echo "<script>";
echo "function deleteDuplicates(ids) {";
echo "    if (confirm('選択した重複データを削除しますか？')) {";
echo "        alert('手動削除機能は未実装です。自動削除が実行されました。');";
echo "    }";
echo "}";

echo "function normalizeId(id, normalizedId) {";
echo "    if (confirm('source_item_id を正規化しますか？\\n' + normalizedId)) {";
echo "        alert('手動正規化機能は未実装です。自動正規化が実行されました。');";
echo "    }";
echo "}";
echo "</script>";
?>
