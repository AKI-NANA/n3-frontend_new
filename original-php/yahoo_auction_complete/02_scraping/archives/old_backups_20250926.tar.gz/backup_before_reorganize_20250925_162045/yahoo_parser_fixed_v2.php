<?php
/**
 * Yahoo!オークション修正版パーサー（ジェミナイ分析対応）
 * HTML構造変更に強いハイブリッドアプローチ
 * 
 * 作成日: 2025-09-16
 * 分析者: ジェミナイ AI
 * 問題: クラス名変更、JSONデータ抽出失敗、成功判定の誤り
 */

/**
 * Yahoo!オークション商品データを正確に抽出
 * 
 * @param string $html HTMLコンテンツ
 * @param string $url 商品URL
 * @param string $item_id 商品ID
 * @return array|false 抽出されたデータまたは失敗時はfalse
 */
function parseYahooAuctionHTML_Fixed($html, $url, $item_id) {
    $data = [
        'item_id' => $item_id,
        'title' => null,
        'description' => null,
        'current_price' => 0,
        'condition' => 'Unknown',
        'category' => 'Uncategorized',
        'images' => [],
        'seller_info' => [
            'name' => 'Unknown',
            'rating' => 'N/A'
        ],
        'auction_info' => [
            'end_time' => date('Y-m-d H:i:s', strtotime('+7 days')),
            'bid_count' => 0
        ],
        'scraped_at' => date('Y-m-d H:i:s'),
        'source_url' => $url,
        'scraping_method' => 'hybrid_fixed_v2',
        'data_quality' => 0, // データ品質スコア
        'extraction_success' => false
    ];

    try {
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        
        $xpath = new DOMXPath($dom);
        
        logExtraction("🔍 [HTML解析開始] パーサー開始: Fixed V2", 'INFO');
        
        // Phase 1: JSON データ抽出（最優先）
        $json_success = extractFromJSON($html, $data, $xpath);
        
        // Phase 2: JSONに失敗した場合、HTML DOM解析
        if (!$json_success) {
            logExtraction("🔄 [フォールバック開始] HTML DOM解析に切り替え", 'WARNING');
            extractFromHTML($data, $xpath);
        }
        
        // Phase 3: データ品質検証
        $quality_score = validateDataQuality($data);
        $data['data_quality'] = $quality_score;
        $data['extraction_success'] = ($quality_score >= 60); // 60%以上で成功
        
        logExtraction("✅ [解析完了] 品質スコア: {$quality_score}%, 成功: " . ($data['extraction_success'] ? 'YES' : 'NO'), 
                     $data['extraction_success'] ? 'SUCCESS' : 'WARNING');
        
        return $data['extraction_success'] ? $data : false;
        
    } catch (Exception $e) {
        logExtraction("❌ [解析例外] エラー: " . $e->getMessage(), 'ERROR');
        return false;
    }
}

/**
 * JSONデータからの抽出
 */
function extractFromJSON($html, &$data, $xpath) {
    logExtraction("🔍 [JSON抽出開始] スクリプトタグ検索中", 'INFO');
    
    // 複数のJSONパターンを試行
    $json_patterns = [
        '/__NEXT_DATA__\s*=\s*({.*?})\s*(?:;|\n|<\/script>)/s',
        '/window\.__INITIAL_STATE__\s*=\s*({.*?})\s*(?:;|\n)/s',
        '/window\.__APP_DATA__\s*=\s*({.*?})\s*(?:;|\n)/s'
    ];
    
    foreach ($json_patterns as $pattern) {
        if (preg_match($pattern, $html, $matches)) {
            $json_data = json_decode($matches[1], true);
            
            if (json_last_error() === JSON_ERROR_NONE && $json_data) {
                logExtraction("✅ [JSON発見] パターンマッチ成功", 'SUCCESS');
                
                // データパスを試行
                $data_paths = [
                    'props.pageProps.item',
                    'props.pageProps.auctionItem', 
                    'props.pageProps.data.item',
                    'initialState.item',
                    'item'
                ];
                
                foreach ($data_paths as $path) {
                    $item_data = getNestedValue($json_data, $path);
                    if ($item_data) {
                        extractDataFromJSON($item_data, $data);
                        logExtraction("✅ [JSON抽出成功] パス: {$path}", 'SUCCESS');
                        return true;
                    }
                }
            }
        }
    }
    
    logExtraction("❌ [JSON抽出失敗] 全パターン試行済み", 'WARNING');
    return false;
}

/**
 * JSONオブジェクトからデータ抽出
 */
function extractDataFromJSON($json_item, &$data) {
    $data['title'] = $json_item['title'] ?? $json_item['name'] ?? $json_item['itemName'] ?? null;
    $data['current_price'] = $json_item['price'] ?? $json_item['currentPrice'] ?? $json_item['bidPrice'] ?? 0;
    $data['description'] = $json_item['description'] ?? $json_item['itemDescription'] ?? null;
    
    // 状態
    if (isset($json_item['itemCondition'])) {
        $data['condition'] = is_array($json_item['itemCondition']) 
            ? ($json_item['itemCondition']['text'] ?? 'Unknown')
            : $json_item['itemCondition'];
    }
    
    // カテゴリ
    if (isset($json_item['categoryPath']) && is_array($json_item['categoryPath'])) {
        $categories = array_map(function($cat) {
            return is_array($cat) ? ($cat['name'] ?? $cat['title'] ?? '') : $cat;
        }, $json_item['categoryPath']);
        $data['category'] = implode(' > ', array_filter($categories));
    }
    
    // 画像
    if (isset($json_item['images']) && is_array($json_item['images'])) {
        $data['images'] = array_map(function($img) {
            return is_array($img) ? ($img['src'] ?? $img['url'] ?? '') : $img;
        }, $json_item['images']);
    }
    
    // オークション情報
    $data['auction_info']['bid_count'] = $json_item['bidCount'] ?? $json_item['bids'] ?? 0;
    $data['auction_info']['end_time'] = $json_item['endTime'] ?? $json_item['auctionEndTime'] ?? null;
    
    // 出品者情報
    if (isset($json_item['seller'])) {
        $seller = $json_item['seller'];
        $data['seller_info']['name'] = is_array($seller) ? ($seller['name'] ?? 'Unknown') : $seller;
        $data['seller_info']['rating'] = is_array($seller) ? ($seller['rating'] ?? 'N/A') : 'N/A';
    }
}

/**
 * HTML DOMからの抽出（フォールバック）
 */
function extractFromHTML(&$data, $xpath) {
    logExtraction("🔍 [HTML解析開始] DOM要素検索", 'INFO');
    
    // タイトル抽出（複数パターン）
    $title_selectors = [
        '//h1[@data-testid="item-name"]',
        '//div[@id="itemTitle"]//h1',
        '//h1[contains(@class, "ProductTitle")]',
        '//h1[contains(@class, "title")]',
        '//h1'
    ];
    
    $data['title'] = extractWithSelectors($xpath, $title_selectors, 'タイトル');
    
    // 価格抽出（複数パターン）
    $price_selectors = [
        '//span[@data-testid="current-price"]',
        '//dt[contains(text(), "現在")]/following-sibling::dd//span[contains(text(), "円")]',
        '//dt[contains(text(), "即決")]/following-sibling::dd//span[contains(text(), "円")]',
        '//div[contains(@class, "Price")]//span[contains(text(), "円")]',
        '//span[contains(text(), "円")]'
    ];
    
    $price_text = extractWithSelectors($xpath, $price_selectors, '価格');
    if ($price_text) {
        $data['current_price'] = (int)preg_replace('/[^\d]/', '', $price_text);
    }
    
    // 状態抽出
    $condition_selectors = [
        '//div[@data-testid="item-condition"]',
        '//dt[contains(text(), "状態")]/following-sibling::dd',
        '//span[contains(@class, "ItemCondition")]'
    ];
    
    $condition = extractWithSelectors($xpath, $condition_selectors, '商品状態');
    if ($condition) {
        $data['condition'] = mapCondition($condition);
    }
    
    // 画像抽出
    $image_selectors = [
        '//img[@data-testid="item-image"]/@src',
        '//div[contains(@class, "ImageGallery")]//img/@src',
        '//figure//img/@src',
        '//img[contains(@src, "auctions.c.yimg.jp")]/@src'
    ];
    
    $images = [];
    foreach ($image_selectors as $selector) {
        $nodes = $xpath->query($selector);
        foreach ($nodes as $node) {
            $src = $node->nodeValue;
            if ($src && !in_array($src, $images)) {
                $images[] = $src;
            }
        }
        if (count($images) >= 10) break; // 最大10枚
    }
    $data['images'] = $images;
    
    // 入札数抽出
    $bid_selectors = [
        '//span[contains(text(), "件")]/text()[contains(., "入札")]',
        '//dt[contains(text(), "入札")]/following-sibling::dd',
        '//div[contains(@class, "bid")]//*[contains(text(), "件")]'
    ];
    
    $bid_text = extractWithSelectors($xpath, $bid_selectors, '入札数');
    if ($bid_text && preg_match('/(\d+)/', $bid_text, $matches)) {
        $data['auction_info']['bid_count'] = (int)$matches[1];
    }
    
    logExtraction("✅ [HTML解析完了] DOM要素抽出完了", 'SUCCESS');
}

/**
 * 複数セレクターでデータ抽出
 */
function extractWithSelectors($xpath, $selectors, $field_name) {
    foreach ($selectors as $selector) {
        $nodes = $xpath->query($selector);
        if ($nodes && $nodes->length > 0) {
            $value = trim($nodes->item(0)->nodeValue);
            if (!empty($value)) {
                logExtraction("✅ [{$field_name}取得] セレクター成功: " . substr($selector, 0, 50), 'SUCCESS');
                return $value;
            }
        }
    }
    
    logExtraction("❌ [{$field_name}取得失敗] 全セレクター試行済み", 'WARNING');
    return null;
}

/**
 * 商品状態のマッピング
 */
function mapCondition($condition_text) {
    $condition_map = [
        '未使用' => 'New',
        '未開封' => 'New',  
        '新品' => 'New',
        '未使用に近い' => 'Like New',
        '目立った傷や汚れなし' => 'Excellent',
        'やや傷や汚れあり' => 'Good',
        '傷や汚れあり' => 'Fair',
        '全体的に状態が悪い' => 'Poor'
    ];
    
    foreach ($condition_map as $japanese => $english) {
        if (strpos($condition_text, $japanese) !== false) {
            return $english;
        }
    }
    
    return 'Used';
}

/**
 * データ品質検証
 */
function validateDataQuality($data) {
    $quality_checks = [
        'title' => ($data['title'] && strlen($data['title']) > 5) ? 25 : 0,
        'price' => ($data['current_price'] > 0) ? 25 : 0,
        'images' => (count($data['images']) > 0) ? 20 : 0,
        'condition' => ($data['condition'] !== 'Unknown') ? 15 : 0,
        'category' => ($data['category'] !== 'Uncategorized') ? 10 : 0,
        'seller' => ($data['seller_info']['name'] !== 'Unknown') ? 5 : 0
    ];
    
    $total_score = array_sum($quality_checks);
    
    logExtraction("📊 [品質評価] " . json_encode($quality_checks) . " = {$total_score}%", 'INFO');
    
    return $total_score;
}

/**
 * ネストしたデータから値を取得
 */
function getNestedValue($array, $path) {
    $keys = explode('.', $path);
    $current = $array;
    
    foreach ($keys as $key) {
        if (!is_array($current) || !isset($current[$key])) {
            return null;
        }
        $current = $current[$key];
    }
    
    return $current;
}

/**
 * ログ出力関数
 */
function logExtraction($message, $type = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[{$timestamp}] [{$type}] {$message}" . PHP_EOL;
    
    // scraping_logs.txtに追記
    $log_file = __DIR__ . '/scraping_logs.txt';
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

/**
 * メイン呼び出し関数（既存システム互換）
 */
function parseYahooAuctionHTML_GeminiFixed($html, $url, $item_id) {
    return parseYahooAuctionHTML_Fixed($html, $url, $item_id);
}
?>