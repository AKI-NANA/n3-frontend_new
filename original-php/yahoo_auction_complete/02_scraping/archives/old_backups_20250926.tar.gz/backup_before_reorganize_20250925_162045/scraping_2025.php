<?php
/**
 * 2025年版 Yahoo オークション スクレイピングシステム（完全新規）
 * 古いシステムとの競合を回避し、実際の構造に基づいた抽出
 */

// セキュリティチェック
if (!defined('SECURE_ACCESS')) {
    define('SECURE_ACCESS', true);
}

// 新しいログ関数
function writeScrapingLog2025($message, $type = 'INFO') {
    $log_file = __DIR__ . '/scraping_2025.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[{$timestamp}] [{$type}] {$message}" . PHP_EOL;
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

// 2025年版 Yahoo オークション解析（実際のHTML構造対応）
function parseYahooAuction2025($html, $url, $item_id) {
    writeScrapingLog2025("2025年版解析開始: {$item_id}", 'INFO');
    
    try {
        $html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');
        
        // 1. タイトル抽出（h1タグから最長テキスト）
        $title = 'タイトル取得失敗';
        if (preg_match_all('/<h1[^>]*>([^<]+)<\/h1>/i', $html, $title_matches)) {
            foreach ($title_matches[1] as $candidate) {
                $candidate = trim(strip_tags($candidate));
                if (strlen($candidate) > strlen($title) && strlen($candidate) > 10) {
                    $title = $candidate;
                }
            }
        }
        
        // タイトルクリーンアップ
        $title = str_replace([' - Yahoo!オークション', 'Yahoo!オークション - '], '', $title);
        writeScrapingLog2025("タイトル抽出: " . substr($title, 0, 50), 'SUCCESS');
        
        // 2. 価格抽出（構造ベース - 即決価格優先）
        $current_price = 0;
        $price_patterns = [
            '/即決[^0-9]*(\d{1,3}(?:,\d{3})*)[\s]*円/u',
            '/(\d{1,3}(?:,\d{3})*)[\s]*<!--[^>]*-->[\s]*円/u', // HTMLコメント付き
            '/現在価格[^0-9]*(\d{1,3}(?:,\d{3})*)[\s]*円/u',
            '/(\d{1,3}(?:,\d{3})*)[\s]*円[\s]*（税/u',
            '/¥[\s]*(\d{1,3}(?:,\d{3})*)/u',
            '/(\d{1,3}(?:,\d{3})*)[\s]*円/u'
        ];
        
        foreach ($price_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $price_num = (int)str_replace(',', '', $matches[1]);
                if ($price_num > 0) {
                    $current_price = $price_num;
                    writeScrapingLog2025("価格抽出成功: ¥{$current_price}", 'SUCCESS');
                    break;
                }
            }
        }
        
        // 3. 画像URL抽出（Yahoo画像サーバー特化）
        $images = [];
        $image_patterns = [
            '/src="(https:\/\/auctions\.c\.yimg\.jp[^"]+)"/i',
            '/src="(https:\/\/[^"]*yimg\.jp[^"]*auctions[^"]+)"/i',
            '/data-src="(https:\/\/auctions\.c\.yimg\.jp[^"]+)"/i'
        ];
        
        foreach ($image_patterns as $pattern) {
            if (preg_match_all($pattern, $html, $matches)) {
                foreach ($matches[1] as $img_url) {
                    if (!in_array($img_url, $images) && 
                        !strpos($img_url, 'placeholder') &&
                        !strpos($img_url, 'na_170x170') &&
                        strpos($img_url, 'http') === 0) {
                        $images[] = $img_url;
                    }
                }
            }
        }
        
        writeScrapingLog2025("画像抽出: " . count($images) . "枚", count($images) > 0 ? 'SUCCESS' : 'WARNING');
        
        // 4. 入札数抽出
        $bid_count = 0;
        $bid_patterns = [
            '/(\d+)[\s]*<!--[^>]*-->[\s]*件/u',
            '/入札[\s\S]*?(\d+)[\s]*件/u',
            '/(\d+)[\s]*件/u'
        ];
        
        foreach ($bid_patterns as $pattern) {
            if (preg_match($pattern, $html, $matches)) {
                $bid_count = (int)$matches[1];
                writeScrapingLog2025("入札数: {$bid_count}件", 'SUCCESS');
                break;
            }
        }
        
        // 5. カテゴリ・状態抽出
        $category = 'Yahoo Auction';
        if (preg_match('/ポケモンカードゲーム/u', $html)) {
            $category = 'ポケモンカードゲーム';
        } elseif (preg_match('/トレーディングカード/u', $html)) {
            $category = 'トレーディングカード';
        }
        
        $condition = 'Used';
        if (preg_match('/目立った傷や汚れなし/u', $html)) {
            $condition = 'Excellent';
        } elseif (preg_match('/新品|未使用/u', $html)) {
            $condition = 'New';
        }
        
        // 6. 出品者名抽出
        $seller_name = '出品者不明';
        if (preg_match('/>([^<]+)[\s]*さん</', $html, $matches)) {
            $seller_name = trim($matches[1]);
        }
        
        $product_data = [
            'item_id' => $item_id,
            'title' => $title,
            'description' => mb_substr($title, 0, 200, 'UTF-8'),
            'current_price' => $current_price,
            'condition' => $condition,
            'category' => $category,
            'images' => $images,
            'seller_info' => [
                'name' => $seller_name,
                'rating' => 'N/A'
            ],
            'auction_info' => [
                'end_time' => date('Y-m-d H:i:s', strtotime('+7 days')),
                'bid_count' => $bid_count
            ],
            'scraped_at' => date('Y-m-d H:i:s'),
            'source_url' => $url,
            'scraping_method' => 'structure_based_2025'
        ];
        
        writeScrapingLog2025("解析完了: {$title} - ¥{$current_price} (画像" . count($images) . "枚)", 'SUCCESS');
        return $product_data;
        
    } catch (Exception $e) {
        writeScrapingLog2025("解析例外: " . $e->getMessage(), 'ERROR');
        return false;
    }
}

// データベース保存（簡素版）
function saveToDatabase2025($product_data) {
    try {
        $pdo = new PDO("pgsql:host=localhost;dbname=nagano3_db", 'postgres', 'Kn240914');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $source_item_id = $product_data['item_id'];
        $price_jpy = (int)($product_data['current_price'] ?? 0);
        $active_title = $product_data['title'] ?? 'タイトル不明';
        $active_image_url = $product_data['images'][0] ?? 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image';
        
        $scraped_yahoo_data = json_encode([
            'category' => $product_data['category'],
            'condition' => $product_data['condition'],
            'url' => $product_data['source_url'],
            'seller_name' => $product_data['seller_info']['name'],
            'bid_count' => $product_data['auction_info']['bid_count'],
            'scraped_at' => date('Y-m-d H:i:s')
        ], JSON_UNESCAPED_UNICODE);
        
        // 重複チェック
        $checkStmt = $pdo->prepare("SELECT id FROM yahoo_scraped_products WHERE source_item_id = ?");
        $checkStmt->execute([$source_item_id]);
        
        if ($checkStmt->fetch()) {
            // 更新
            $sql = "UPDATE yahoo_scraped_products SET 
                    price_jpy = ?, active_title = ?, active_image_url = ?, 
                    scraped_yahoo_data = ?, updated_at = CURRENT_TIMESTAMP 
                    WHERE source_item_id = ?";
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([$price_jpy, $active_title, $active_image_url, $scraped_yahoo_data, $source_item_id]);
        } else {
            // 新規作成
            $sql = "INSERT INTO yahoo_scraped_products 
                    (source_item_id, sku, price_jpy, active_title, active_image_url, 
                     scraped_yahoo_data, current_stock, status) 
                    VALUES (?, ?, ?, ?, ?, ?, 1, 'scraped')";
            $sku = 'SKU-' . strtoupper(substr($source_item_id, 0, 15));
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([$source_item_id, $sku, $price_jpy, $active_title, $active_image_url, $scraped_yahoo_data]);
        }
        
        if ($result) {
            writeScrapingLog2025("DB保存成功: {$source_item_id}", 'SUCCESS');
            return true;
        }
        
    } catch (Exception $e) {
        writeScrapingLog2025("DB保存失敗: " . $e->getMessage(), 'ERROR');
    }
    
    return false;
}

// 実行部分
if ($_POST['action'] ?? '' === 'scrape_2025') {
    $url = $_POST['url'] ?? '';
    
    if (empty($url)) {
        echo json_encode(['success' => false, 'message' => 'URLが指定されていません']);
        exit;
    }
    
    writeScrapingLog2025("2025年版スクレイピング開始: {$url}", 'INFO');
    
    // Yahoo オークション IDを抽出
    $item_id = 'unknown';
    if (preg_match('/auction\/([a-zA-Z0-9]+)/', $url, $matches)) {
        $item_id = $matches[1];
    }
    
    // HTMLを取得
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $html = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($html && $http_code === 200) {
        writeScrapingLog2025("HTML取得成功: " . strlen($html) . "文字", 'SUCCESS');
        
        $product_data = parseYahooAuction2025($html, $url, $item_id);
        
        if ($product_data && saveToDatabase2025($product_data)) {
            echo json_encode([
                'success' => true,
                'message' => '2025年版スクレイピング成功: 正確なデータを取得しました',
                'data' => [
                    'success_count' => 1,
                    'products' => [$product_data],
                    'status' => 'structure_based_2025'
                ]
            ]);
        } else {
            echo json_encode([
                'success' => false, 
                'message' => 'データ解析または保存に失敗しました'
            ]);
        }
    } else {
        writeScrapingLog2025("HTML取得失敗: HTTP {$http_code}", 'ERROR');
        echo json_encode([
            'success' => false, 
            'message' => "HTML取得失敗: HTTP {$http_code}"
        ]);
    }
    
    exit;
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>2025年版 Yahoo スクレイピング</title>
    <style>
    body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; margin: 20px; }
    .container { max-width: 800px; margin: 0 auto; }
    .success { color: #10b981; font-weight: bold; }
    .error { color: #ef4444; font-weight: bold; }
    input[type="url"] { width: 100%; padding: 10px; margin: 10px 0; }
    button { background: #3b82f6; color: white; padding: 12px 24px; border: none; border-radius: 6px; cursor: pointer; }
    button:hover { background: #2563eb; }
    .result { background: #f9fafb; padding: 20px; margin: 20px 0; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 2025年版 Yahoo スクレイピング（構造ベース）</h1>
        
        <form onsubmit="return executeScraping2025(event)">
            <label>Yahoo オークション URL:</label>
            <input type="url" id="yahooUrl" placeholder="https://auctions.yahoo.co.jp/jp/auction/j1200085520" required>
            <button type="submit">構造ベーススクレイピング実行</button>
        </form>
        
        <div id="result"></div>
        
        <div style="margin-top: 30px; padding: 20px; background: #e0f2fe; border-radius: 8px;">
            <h3>✨ 2025年版の改善点</h3>
            <ul>
                <li><strong>構造ベース抽出:</strong> クラス名に依存しない抽出パターン</li>
                <li><strong>正確な価格:</strong> HTMLコメント付き価格対応</li>
                <li><strong>画像取得:</strong> Yahoo画像サーバーの特徴的パターン検出</li>
                <li><strong>プレースホルダー:</strong> 動作する画像URL使用</li>
                <li><strong>重複防止:</strong> 同じURLの上書き処理</li>
            </ul>
        </div>
    </div>

    <script>
    function executeScraping2025(event) {
        event.preventDefault();
        
        const url = document.getElementById('yahooUrl').value;
        const resultDiv = document.getElementById('result');
        
        resultDiv.innerHTML = '<div style="color: #3b82f6;">🔄 構造ベーススクレイピング実行中...</div>';
        
        fetch('scraping_2025.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `action=scrape_2025&url=${encodeURIComponent(url)}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const product = data.data.products[0];
                resultDiv.innerHTML = `
                    <div class="result">
                        <h3 class="success">✅ 構造ベーススクレイピング成功</h3>
                        <p><strong>タイトル:</strong> ${product.title}</p>
                        <p><strong>価格:</strong> ¥${product.current_price.toLocaleString()}</p>
                        <p><strong>画像:</strong> ${product.images.length}枚取得</p>
                        <p><strong>カテゴリ:</strong> ${product.category}</p>
                        <p><strong>状態:</strong> ${product.condition}</p>
                        <p><strong>出品者:</strong> ${product.seller_info.name}</p>
                        <p><strong>入札数:</strong> ${product.auction_info.bid_count}件</p>
                        <p><em>編集システムで確認してください</em></p>
                    </div>
                `;
            } else {
                resultDiv.innerHTML = `<div class="error">❌ ${data.message}</div>`;
            }
        })
        .catch(error => {
            resultDiv.innerHTML = `<div class="error">❌ エラー: ${error.message}</div>`;
        });
        
        return false;
    }
    </script>
</body>
</html>
