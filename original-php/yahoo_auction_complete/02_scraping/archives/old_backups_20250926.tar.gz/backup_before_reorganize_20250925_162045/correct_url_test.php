<?php
/**
 * 🎯 正しいURL修正版: Ultimate Parserの再検証
 * 正確なURL: https://auctions.yahoo.co.jp/jp/auction/l1200404917
 */

header('Content-Type: text/html; charset=UTF-8');

// 正しいURLとitem_id
$test_url = 'https://auctions.yahoo.co.jp/jp/auction/l1200404917';
$item_id = 'l1200404917'; // 修正されたitem_id

?><!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎯 正しいURL版 - Ultimate Parser テスト</title>
    <style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    .result { margin: 15px 0; padding: 15px; border-radius: 6px; }
    .success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; }
    .error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; }
    .warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; }
    .info { background: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; }
    .comparison { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0; }
    .expected { background: #e8f5e8; padding: 15px; border-left: 4px solid #28a745; }
    .actual { background: #fdf2e8; padding: 15px; border-left: 4px solid #fd7e14; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 4px; overflow-x: auto; font-size: 11px; max-height: 400px; overflow-y: auto; }
    .accuracy-bar { width: 100%; height: 25px; background: #e9ecef; border-radius: 12px; overflow: hidden; margin: 15px 0; position: relative; }
    .accuracy-fill { height: 100%; transition: width 0.5s ease; display: flex; align-items: center; justify-content: center; font-weight: bold; color: white; }
    .accuracy-excellent { background: linear-gradient(45deg, #28a745, #20c997); }
    .accuracy-good { background: linear-gradient(45deg, #ffc107, #fd7e14); }
    .accuracy-poor { background: linear-gradient(45deg, #dc3545, #e83e8c); }
    ul { margin: 5px 0; padding-left: 20px; }
    .extraction-log { background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; padding: 10px; margin: 10px 0; font-family: monospace; font-size: 12px; max-height: 250px; overflow-y: auto; }
    .fix-notice { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 20px; border-radius: 8px; margin: 20px 0; }
    .critical-issues { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; border-radius: 8px; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎯 正しいURL版 - Ultimate Parser 完全テスト</h1>
        
        <div class="result info">
            <strong>✅ 修正されたテスト対象:</strong><br>
            <strong>正しいURL:</strong> <?php echo $test_url; ?><br>
            <strong>正しいitem_id:</strong> <?php echo $item_id; ?><br>
            <strong>実行時刻:</strong> <?php echo date('Y-m-d H:i:s'); ?>
        </div>

        <div class="expected">
            <h3>🎯 期待される完璧な結果（正しいURL版）:</h3>
            <ul>
                <li><strong>タイトル:</strong> マツバのゲンガー VS ポケモンカードe 1ED ポケカ ポケモンカード</li>
                <li><strong>価格:</strong> 37,777円</li>
                <li><strong>状態:</strong> 未使用に近い</li>
                <li><strong>カテゴリ階層:</strong> おもちゃ、ゲーム > ゲーム > トレーディングカードゲーム > ポケモンカードゲーム > シングルカード</li>
                <li><strong>ブランド:</strong> Pokemon</li>
                <li><strong>配送元:</strong> 東京都</li>
                <li><strong>送料:</strong> 全国一律230円（税込）</li>
                <li><strong>オークションID:</strong> l1200404917</li>
            </ul>
        </div>

        <?php
        // HTMLデータ取得
        $context = stream_context_create([
            'http' => [
                'header' => "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n",
                'timeout' => 30
            ]
        ]);
        
        $html = @file_get_contents($test_url, false, $context);
        
        if (!$html) {
            echo '<div class="result error"><strong>❌ HTML取得失敗</strong></div>';
        } else {
            echo '<div class="result success"><strong>✅ HTML取得成功:</strong> ' . strlen($html) . ' 文字</div>';
            
            // Ultimate Parserのテスト
            if (file_exists('yahoo_parser_ultimate.php')) {
                require_once 'yahoo_parser_ultimate.php';
                
                echo '<h2>🚀 正しいURL版 - Ultimate Parser 結果:</h2>';
                
                $start_time = microtime(true);
                $result = parseYahooAuctionHTML_Ultimate($html, $test_url, $item_id);
                $execution_time = round((microtime(true) - $start_time) * 1000, 2);
                
                // より厳密な精度チェック
                $precision_checks = [
                    'タイトル（マツバのゲンガー）' => [
                        'expected' => 'マツバのゲンガー',
                        'actual' => $result['title'] ?? 'null',
                        'match' => stripos($result['title'] ?? '', 'マツバのゲンガー') !== false || 
                                  (stripos($result['title'] ?? '', 'ゲンガー') !== false && stripos($result['title'] ?? '', 'マツバ') !== false)
                    ],
                    '価格（正確に37,777円）' => [
                        'expected' => 37777,
                        'actual' => $result['current_price'] ?? 0,
                        'match' => ($result['current_price'] ?? 0) == 37777
                    ],
                    '状態（未使用に近い）' => [
                        'expected' => '未使用に近い',
                        'actual' => $result['condition'] ?? 'null',
                        'match' => stripos($result['condition'] ?? '', '未使用に近い') !== false
                    ],
                    'カテゴリ（ポケモン含む）' => [
                        'expected' => 'ポケモンカードゲーム',
                        'actual' => $result['category'] ?? 'null',
                        'match' => stripos($result['category'] ?? '', 'ポケモンカードゲーム') !== false || 
                                  stripos($result['category'] ?? '', 'ポケモン') !== false
                    ],
                    'ブランド（Pokemon）' => [
                        'expected' => 'Pokemon',
                        'actual' => $result['brand'] ?? 'null',
                        'match' => stripos($result['brand'] ?? '', 'pokemon') !== false
                    ],
                    '正しいitem_id' => [
                        'expected' => 'l1200404917',
                        'actual' => $result['item_id'] ?? 'null',
                        'match' => ($result['item_id'] ?? '') === 'l1200404917'
                    ]
                ];
                
                $successful_checks = array_sum(array_column($precision_checks, 'match'));
                $accuracy_percentage = round(($successful_checks / count($precision_checks)) * 100, 1);
                
                // 精度表示
                $accuracy_class = $accuracy_percentage >= 85 ? 'accuracy-excellent' : ($accuracy_percentage >= 65 ? 'accuracy-good' : 'accuracy-poor');
                $result_class = $accuracy_percentage >= 85 ? 'success' : ($accuracy_percentage >= 65 ? 'warning' : 'error');
                
                echo "<div class='result $result_class'>";
                echo "<strong>🎯 総合精度: {$accuracy_percentage}% ({$successful_checks}/" . count($precision_checks) . " 項目成功)</strong><br>";
                echo "品質スコア: " . ($result['data_quality'] ?? 'N/A') . "%<br>";
                echo "実行時間: {$execution_time}ms<br>";
                echo "抽出成功: " . ($result['extraction_success'] ? '✅ YES' : '❌ NO') . "<br>";
                echo "</div>";
                
                echo '<div class="accuracy-bar">';
                echo "<div class='accuracy-fill $accuracy_class' style='width: {$accuracy_percentage}%'>{$accuracy_percentage}%</div>";
                echo '</div>';
                
                // 重要な問題の特定
                $critical_issues = [];
                foreach ($precision_checks as $field => $check) {
                    if (!$check['match']) {
                        $critical_issues[] = "{$field}: 期待「{$check['expected']}」→ 実際「{$check['actual']}」";
                    }
                }
                
                if (!empty($critical_issues)) {
                    echo '<div class="critical-issues">';
                    echo '<h4>🚨 重要な問題:</h4>';
                    foreach ($critical_issues as $issue) {
                        echo "<p>❌ {$issue}</p>";
                    }
                    echo '</div>';
                }
                
                // 詳細比較
                echo '<div class="comparison">';
                echo '<div class="expected"><h4>📊 詳細精度チェック:</h4>';
                foreach ($precision_checks as $field => $check) {
                    $icon = $check['match'] ? '✅' : '❌';
                    echo "<p><strong>{$field}:</strong> $icon<br>";
                    echo "<small>期待: {$check['expected']}<br>";
                    echo "実際: {$check['actual']}</small></p>";
                }
                echo '</div>';
                
                echo '<div class="actual"><h4>🔍 抽出されたデータ:</h4>';
                echo "<p><strong>タイトル:</strong> " . ($result['title'] ?? 'null') . "</p>";
                echo "<p><strong>価格:</strong> ¥" . number_format($result['current_price'] ?? 0) . "</p>";
                echo "<p><strong>状態:</strong> " . ($result['condition'] ?? 'null') . "</p>";
                echo "<p><strong>カテゴリ:</strong> " . ($result['category'] ?? 'null') . "</p>";
                echo "<p><strong>階層数:</strong> " . count($result['category_path'] ?? []) . "階層</p>";
                echo "<p><strong>ブランド:</strong> " . ($result['brand'] ?? 'null') . "</p>";
                echo "<p><strong>画像数:</strong> " . count($result['images'] ?? []) . "枚</p>";
                echo "<p><strong>配送情報:</strong> " . ($result['shipping_cost'] ?? 'なし') . "</p>";
                echo "<p><strong>item_id:</strong> " . ($result['item_id'] ?? 'null') . "</p>";
                echo '</div>';
                echo '</div>';
                
                // 抽出ログ表示
                if (isset($result['extraction_log']) && !empty($result['extraction_log'])) {
                    echo '<h3>📋 抽出プロセスログ:</h3>';
                    echo '<div class="extraction-log">';
                    foreach ($result['extraction_log'] as $log_entry) {
                        echo htmlspecialchars($log_entry) . "<br>";
                    }
                    echo '</div>';
                }
                
                // 修正提案
                if ($accuracy_percentage < 85) {
                    echo '<div class="fix-notice">';
                    echo '<h4>🔧 次の修正が必要:</h4>';
                    echo '<ul>';
                    if (($result['current_price'] ?? 0) != 37777) {
                        echo '<li>価格セレクターの改善（37,777円が正確に抽出されていない）</li>';
                    }
                    if (!stripos($result['condition'] ?? '', '未使用に近い')) {
                        echo '<li>商品状態セレクターの改善（「未使用に近い」が抽出されていない）</li>';
                    }
                    if (!stripos($result['category'] ?? '', 'ポケモン')) {
                        echo '<li>カテゴリ階層抽出の改善（ポケモン関連カテゴリが不完全）</li>';
                    }
                    if (!stripos($result['brand'] ?? '', 'pokemon')) {
                        echo '<li>ブランド情報抽出の改善（Pokemonブランドが抽出されていない）</li>';
                    }
                    echo '</ul>';
                    echo '</div>';
                }
                
                // 完全結果（デバッグ用）
                echo '<details><summary><strong>🔍 完全抽出結果（デバッグ用）</strong></summary>';
                echo '<pre>' . htmlspecialchars(json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</pre>';
                echo '</details>';
                
            } else {
                echo '<div class="result error"><strong>❌ Ultimate Parserファイル不存在</strong></div>';
            }
        }
        ?>
        
        <div class="result info">
            <strong>🎯 修正された成功基準:</strong><br>
            • 精度85%以上: 本格運用可能<br>
            • 精度65-84%: 改善必要<br>
            • 精度65%未満: 大幅修正必要
        </div>
    </div>
</body>
</html>
