<?php
/**
 * データベース診断スクリプト - 保存エラーの原因調査
 */

// エラー表示を有効にする
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔍 データベース診断スクリプト</h1>";

try {
    // データベース接続
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; background: #e8f5e8; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
    echo "✅ データベース接続成功";
    echo "</div>";
    
    // 1. テーブル存在確認
    echo "<h2>1. テーブル存在確認</h2>";
    $tableCheckSql = "SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'yahoo_scraped_products')";
    $tableExists = $pdo->query($tableCheckSql)->fetchColumn();
    
    if ($tableExists) {
        echo "<div style='color: green;'>✅ yahoo_scraped_products テーブルは存在します</div>";
    } else {
        echo "<div style='color: red; background: #ffe6e6; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "❌ yahoo_scraped_products テーブルが存在しません！";
        echo "</div>";
        
        // テーブル作成スクリプトを提案
        echo "<h3>テーブル作成スクリプト:</h3>";
        echo "<pre style='background: #f5f5f5; padding: 10px; border-radius: 5px;'>";
        echo "CREATE TABLE yahoo_scraped_products (\n";
        echo "    id SERIAL PRIMARY KEY,\n";
        echo "    source_item_id VARCHAR(255) UNIQUE NOT NULL,\n";
        echo "    sku VARCHAR(255),\n";
        echo "    price_jpy INTEGER DEFAULT 0,\n";
        echo "    scraped_yahoo_data JSONB,\n";
        echo "    active_title TEXT,\n";
        echo "    active_description TEXT,\n";
        echo "    active_price_usd DECIMAL(10,2),\n";
        echo "    active_image_url TEXT,\n";
        echo "    current_stock INTEGER DEFAULT 1,\n";
        echo "    status VARCHAR(50) DEFAULT 'scraped',\n";
        echo "    ebay_item_id VARCHAR(255),\n";
        echo "    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n";
        echo "    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n";
        echo ");";
        echo "</pre>";
        exit;
    }
    
    // 2. テーブル構造確認
    echo "<h2>2. テーブル構造確認</h2>";
    $columnsSql = "SELECT column_name, data_type, is_nullable, column_default, character_maximum_length 
                   FROM information_schema.columns 
                   WHERE table_name = 'yahoo_scraped_products' 
                   ORDER BY ordinal_position";
    $columns = $pdo->query($columnsSql)->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
    echo "<tr style='background: #f0f0f0;'>";
    echo "<th style='padding: 8px;'>カラム名</th>";
    echo "<th style='padding: 8px;'>データ型</th>";
    echo "<th style='padding: 8px;'>NULL許可</th>";
    echo "<th style='padding: 8px;'>デフォルト値</th>";
    echo "<th style='padding: 8px;'>最大長</th>";
    echo "</tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td style='padding: 8px;'>{$column['column_name']}</td>";
        echo "<td style='padding: 8px;'>{$column['data_type']}</td>";
        echo "<td style='padding: 8px;'>{$column['is_nullable']}</td>";
        echo "<td style='padding: 8px;'>" . ($column['column_default'] ?: 'なし') . "</td>";
        echo "<td style='padding: 8px;'>" . ($column['character_maximum_length'] ?: 'なし') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // 3. レコード数確認
    echo "<h2>3. レコード数確認</h2>";
    $countSql = "SELECT COUNT(*) as total FROM yahoo_scraped_products";
    $totalRecords = $pdo->query($countSql)->fetchColumn();
    echo "<div>総レコード数: <strong>{$totalRecords}</strong></div>";
    
    // 最新5件のデータ確認
    if ($totalRecords > 0) {
        echo "<h3>最新5件のデータ:</h3>";
        $recentSql = "SELECT source_item_id, active_title, price_jpy, status, created_at 
                      FROM yahoo_scraped_products 
                      ORDER BY created_at DESC 
                      LIMIT 5";
        $recentData = $pdo->query($recentSql)->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 10px 0;'>";
        echo "<tr style='background: #f0f0f0;'>";
        echo "<th style='padding: 8px;'>Item ID</th>";
        echo "<th style='padding: 8px;'>タイトル</th>";
        echo "<th style='padding: 8px;'>価格</th>";
        echo "<th style='padding: 8px;'>ステータス</th>";
        echo "<th style='padding: 8px;'>作成日時</th>";
        echo "</tr>";
        
        foreach ($recentData as $record) {
            echo "<tr>";
            echo "<td style='padding: 8px;'>{$record['source_item_id']}</td>";
            echo "<td style='padding: 8px;'>" . substr($record['active_title'], 0, 50) . "...</td>";
            echo "<td style='padding: 8px;'>¥" . number_format($record['price_jpy']) . "</td>";
            echo "<td style='padding: 8px;'>{$record['status']}</td>";
            echo "<td style='padding: 8px;'>{$record['created_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    // 4. テストデータ挿入試行
    echo "<h2>4. テストデータ挿入試行</h2>";
    
    $testData = [
        'source_item_id' => 'TEST_DIAGNOSIS_' . time(),
        'sku' => 'SKU-TEST-' . time(),
        'price_jpy' => 1000,
        'scraped_yahoo_data' => json_encode(['test' => 'data', 'diagnosis' => true], JSON_UNESCAPED_UNICODE),
        'active_title' => 'テスト商品 - 診断用',
        'active_description' => 'データベース診断テスト用の商品説明',
        'active_price_usd' => 6.67,
        'active_image_url' => 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=Test+Product',
        'current_stock' => 1,
        'status' => 'test'
    ];
    
    try {
        $insertSql = "INSERT INTO yahoo_scraped_products (
            source_item_id, sku, price_jpy, scraped_yahoo_data, active_title,
            active_description, active_price_usd, active_image_url, current_stock,
            status, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
        
        $stmt = $pdo->prepare($insertSql);
        $result = $stmt->execute([
            $testData['source_item_id'],
            $testData['sku'],
            $testData['price_jpy'],
            $testData['scraped_yahoo_data'],
            $testData['active_title'],
            $testData['active_description'],
            $testData['active_price_usd'],
            $testData['active_image_url'],
            $testData['current_stock'],
            $testData['status']
        ]);
        
        if ($result) {
            $insertId = $pdo->lastInsertId();
            echo "<div style='color: green; background: #e8f5e8; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
            echo "✅ テストデータ挿入成功 - ID: {$insertId}";
            echo "</div>";
            
            // テストデータを削除
            $deleteSql = "DELETE FROM yahoo_scraped_products WHERE id = ?";
            $deleteStmt = $pdo->prepare($deleteSql);
            $deleteStmt->execute([$insertId]);
            echo "<div style='color: blue;'>🗑️ テストデータを削除しました</div>";
            
        } else {
            echo "<div style='color: red; background: #ffe6e6; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
            echo "❌ テストデータ挿入失敗";
            echo "</div>";
        }
        
    } catch (PDOException $e) {
        echo "<div style='color: red; background: #ffe6e6; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
        echo "❌ テストデータ挿入エラー: " . $e->getMessage();
        echo "<br>SQLState: " . $e->getCode();
        echo "<br>ErrorInfo: " . json_encode($e->errorInfo);
        echo "</div>";
    }
    
    // 5. 権限確認
    echo "<h2>5. データベース権限確認</h2>";
    $privilegesSql = "SELECT table_catalog, table_schema, table_name, privilege_type, is_grantable 
                      FROM information_schema.table_privileges 
                      WHERE table_name = 'yahoo_scraped_products' AND grantee = current_user";
    
    $privileges = $pdo->query($privilegesSql)->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($privileges)) {
        echo "<div style='color: green;'>✅ 権限確認:</div>";
        echo "<ul>";
        foreach ($privileges as $privilege) {
            echo "<li>{$privilege['privilege_type']}</li>";
        }
        echo "</ul>";
    } else {
        echo "<div style='color: orange;'>⚠️ 権限情報が取得できませんでした</div>";
    }
    
} catch (PDOException $e) {
    echo "<div style='color: red; background: #ffe6e6; padding: 10px; margin: 10px 0; border-radius: 5px;'>";
    echo "❌ データベース接続エラー: " . $e->getMessage();
    echo "<br>接続文字列: pgsql:host=localhost;dbname=nagano3_db";
    echo "<br>ユーザー: postgres";
    echo "</div>";
    
    echo "<h3>対処法:</h3>";
    echo "<ol>";
    echo "<li>PostgreSQLサービスが起動しているか確認</li>";
    echo "<li>データベース 'nagano3_db' が存在するか確認</li>";
    echo "<li>ユーザー 'postgres' の権限確認</li>";
    echo "<li>パスワードが正しいか確認</li>";
    echo "</ol>";
}

echo "<hr>";
echo "<div style='background: #f0f8ff; padding: 10px; border-radius: 5px; margin-top: 20px;'>";
echo "<h3>📋 診断完了</h3>";
echo "<p>このスクリプトでデータベースの状態を確認しました。</p>";
echo "<p>エラーが見つかった場合は、上記の情報を元に修正してください。</p>";
echo "</div>";
?>
