<?php
/**
 * Yahoo オークション HTML構造ベース最終修正版パーサー
 * 関数名重複を避けるため、すべての関数にHTMLStructure接尾辞を付与
 */

/**
 * HTML構造ベース修正版Yahoo オークション解析（メイン関数）
 */
function parseYahooAuctionHTML_HTMLStructureBased($html, $url, $item_id) {
    try {
        writeLog("🔧 [HTML構造ベース解析開始] HTML Structure Based Parser for: {$item_id}", 'INFO');
        
        // DOMDocument初期化
        $dom = new DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="UTF-8">' . $html);
        libxml_use_internal_errors(false);
        
        $xpath = new DOMXPath($dom);
        
        // エラー・警告追跡
        $errors = [];
        $warnings = [];
        
        // 1. JSONデータの抽出
        $json_data = extractJSONDataHTMLStructure($html, $errors);
        
        // 2. HTML構造ベースのオークション形式判定（最も確実）
        $auction_check = checkAuctionTypeFromHTMLStructure($xpath, $json_data);
        if ($auction_check['is_auction']) {
            writeLog("🚨 [オークション判定] オークション形式のため処理を中断: " . $auction_check['reason'], 'ERROR');
            
            return [
                'success' => false,
                'error' => 'オークション形式のため処理を中断しました',
                'reason' => $auction_check['reason'],
                'auction_details' => $auction_check['details'],
                'business_policy' => '定額出品のみ取扱 - オークション形式は商用リスクのため完全除外'
            ];
        }
        
        writeLog("✅ [定額出品確認] 定額出品として処理を続行", 'SUCCESS');
        
        // 3. JSONデータからの正確なデータ抽出
        $final_category = extractCategoryFromJSONHTMLStructure($json_data, $errors);
        $product_condition = extractConditionFromJSONHTMLStructure($json_data, $errors);
        $current_price = extractPriceFromJSONHTMLStructure($json_data, $errors);
        $brand = extractBrandFromJSONHTMLStructure($json_data, $errors);
        $title = extractTitleFromJSONHTMLStructure($json_data, $xpath, $errors);
        $images = extractImagesFromJSONHTMLStructure($json_data, $errors);
        $basic_info = extractBasicInfoFromJSONHTMLStructure($json_data, $errors);
        
        // 4. 必須データの検証
        $validation_result = validateRequiredDataHTMLStructure([
            'category' => $final_category,
            'condition' => $product_condition,
            'price' => $current_price,
            'title' => $title
        ], $errors);
        
        if (!$validation_result['is_valid']) {
            writeLog("❌ [データ検証失敗] 必須データ不足: " . implode(', ', $validation_result['missing_fields']), 'ERROR');
            
            return [
                'success' => false,
                'error' => '必須データが不足しているため処理を中断しました',
                'missing_fields' => $validation_result['missing_fields'],
                'extracted_data' => [
                    'category' => $final_category,
                    'condition' => $product_condition,
                    'price' => $current_price,
                    'title' => $title
                ]
            ];
        }
        
        // 5. 完全なデータ構築
        $product_data = [
            'item_id' => $item_id,
            'title' => $title,
            'description' => generateDescriptionHTMLStructure($title, $final_category, $product_condition, $brand),
            'current_price' => $current_price,
            'immediate_price' => $current_price, // 定額出品なので即決価格と同じ
            'condition' => $product_condition,
            'category' => $final_category,
            'brand' => $brand,
            'images' => $images,
            'main_image' => $images[0] ?? 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image',
            'basic_info' => $basic_info,
            'seller_info' => [
                'name' => 'Yahoo出品者',
                'rating' => 'N/A'
            ],
            'auction_info' => [
                'auction_type' => 'fixed_price',
                'bid_count' => 0,
                'end_time' => null
            ],
            'scraped_at' => date('Y-m-d H:i:s'),
            'source_url' => $url,
            'scraping_method' => 'html_structure_based',
            'data_quality' => 100,
            'errors' => $errors,
            'warnings' => $warnings,
            'validation_status' => 'validated',
            'commercial_grade' => 'A'
        ];
        
        writeLog("✅ [HTML構造ベース解析完了] Category: {$final_category}, Condition: {$product_condition}, Price: ¥{$current_price}", 'SUCCESS');
        
        return $product_data;
        
    } catch (Exception $e) {
        writeLog("❌ [HTML構造ベース解析例外] " . $e->getMessage(), 'ERROR');
        return false;
    }
}

/**
 * HTML構造からのオークション形式判定（最終決定版）
 */
function checkAuctionTypeFromHTMLStructure($xpath, $json_data) {
    $is_auction = false;
    $reasons = [];
    $details = [];
    
    try {
        // 1. HTML構造による判定（最も確実）
        $current_price_dt = $xpath->query('//dt[text()="現在"]');
        $immediate_price_dt = $xpath->query('//dt[text()="即決"]');
        $bid_button = $xpath->query('//button[contains(text(), "入札")]');
        $buy_now_button = $xpath->query('//button[contains(text(), "今すぐ落札")]');
        
        writeLog("🔍 [HTML構造チェック] 現在価格dt: {$current_price_dt->length}, 即決価格dt: {$immediate_price_dt->length}", 'DEBUG');
        writeLog("🔍 [HTML構造チェック] 入札ボタン: {$bid_button->length}, 今すぐ落札ボタン: {$buy_now_button->length}", 'DEBUG');
        
        if ($current_price_dt->length > 0 && $immediate_price_dt->length > 0) {
            // 「現在」と「即決」の両方がある = オークション形式
            $is_auction = true;
            $reasons[] = "現在価格と即決価格の両方が表示されている";
            $details['has_both_prices'] = true;
        } elseif ($current_price_dt->length > 0 && $immediate_price_dt->length === 0) {
            // 「現在」のみ = 純粋なオークション
            $is_auction = true;
            $reasons[] = "現在価格のみ表示（純粋なオークション）";
            $details['auction_only'] = true;
        } elseif ($current_price_dt->length === 0 && $immediate_price_dt->length > 0) {
            // 「即決」のみ = 定額出品
            $is_auction = false;
            $reasons[] = "即決価格のみ表示（定額出品）";
            $details['fixed_price_only'] = true;
        }
        
        // 2. ボタンによる二重チェック
        if ($bid_button->length > 0) {
            $is_auction = true;
            $reasons[] = "入札ボタンが存在";
            $details['has_bid_button'] = true;
        } elseif ($buy_now_button->length > 0) {
            // 「今すぐ落札」ボタンは定額出品の証拠
            if ($is_auction) {
                // 既にオークション判定されている場合は警告
                writeLog("⚠️ [判定矛盾] オークション判定だが今すぐ落札ボタンが存在", 'WARNING');
            } else {
                $reasons[] = "今すぐ落札ボタンが存在（定額出品確定）";
                $details['has_buy_now_button'] = true;
            }
        }
        
        // 3. JSONデータによる補完チェック
        if ($json_data && isset($json_data['item']['detail']['item'])) {
            $item = $json_data['item']['detail']['item'];
            $bid_count = $item['bids'] ?? 0;
            $bidders_count = $item['biddersNum'] ?? 0;
            
            if ($bid_count > 0 || $bidders_count > 0) {
                $is_auction = true;
                $reasons[] = "実際の入札が存在（入札数: {$bid_count}件、入札者数: {$bidders_count}人）";
                $details['has_actual_bids'] = true;
            }
        }
        
        // 4. 最終判定
        if (empty($reasons)) {
            // 判定不能の場合は安全のためオークション扱い
            $is_auction = true;
            $reasons[] = "判定不能のため安全策としてオークション扱い";
            $details['unknown_type'] = true;
        }
        
        $reason_text = implode(', ', $reasons);
        
        writeLog("🎯 [HTML+JSON オークション判定] 結果: " . ($is_auction ? 'オークション' : '定額出品') . " ({$reason_text})", $is_auction ? 'WARNING' : 'SUCCESS');
        
        return [
            'is_auction' => $is_auction,
            'reason' => $reason_text,
            'details' => $details
        ];
        
    } catch (Exception $e) {
        writeLog("❌ [HTML+JSON判定エラー] " . $e->getMessage(), 'ERROR');
        return [
            'is_auction' => true, // エラー時は安全のためオークション扱い
            'reason' => 'エラーのため安全策としてオークション扱い',
            'details' => ['error' => $e->getMessage()]
        ];
    }
}

/**
 * JSONデータの抽出（HTML構造ベース版）
 */
function extractJSONDataHTMLStructure($html, &$errors) {
    try {
        writeLog("📊 [JSONデータ抽出] ページ内のJSONデータを抽出開始", 'INFO');
        
        if (preg_match('/{"props":.*?"initialState":\s*({.*?})/', $html, $matches)) {
            $json_str = $matches[1];
            $json_data = json_decode($json_str, true);
            
            if (json_last_error() === JSON_ERROR_NONE) {
                writeLog("✅ [JSONデータ取得成功] データサイズ: " . strlen($json_str) . "文字", 'SUCCESS');
                return $json_data;
            }
        }
        
        if (preg_match('/__NEXT_DATA__["\s]*=["\s]*({.*?})["\s]*<\/script>/', $html, $matches)) {
            $json_data = json_decode($matches[1], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                writeLog("⚠️ [JSONフォールバック成功] __NEXT_DATA__から取得", 'WARNING');
                return $json_data;
            }
        }
        
        $errors[] = 'JSONデータの抽出に失敗しました';
        writeLog("❌ [JSONデータ抽出失敗] HTMLからJSONデータを取得できません", 'ERROR');
        return null;
        
    } catch (Exception $e) {
        $errors[] = "JSONデータ抽出中にエラー: " . $e->getMessage();
        writeLog("❌ [JSONデータ抽出例外] " . $e->getMessage(), 'ERROR');
        return null;
    }
}

/**
 * JSONデータからのカテゴリ抽出（HTML構造ベース版）
 */
function extractCategoryFromJSONHTMLStructure($json_data, &$errors) {
    try {
        if (!$json_data || !isset($json_data['item']['detail']['item']['category']['path'])) {
            $errors[] = 'JSONからカテゴリデータが見つかりません';
            return null;
        }
        
        $category_path = $json_data['item']['detail']['item']['category']['path'];
        $final_category = end($category_path)['name'];
        
        writeLog("✅ [JSONカテゴリ抽出] 最終カテゴリ: {$final_category}", 'SUCCESS');
        return $final_category;
        
    } catch (Exception $e) {
        $errors[] = "JSONカテゴリ抽出中にエラー: " . $e->getMessage();
        return null;
    }
}

/**
 * JSONデータからの商品状態抽出（HTML構造ベース版）
 */
function extractConditionFromJSONHTMLStructure($json_data, &$errors) {
    try {
        if (!$json_data || !isset($json_data['item']['detail']['item']['conditionName'])) {
            $errors[] = 'JSONから商品状態データが見つかりません';
            return null;
        }
        
        $japanese_condition = $json_data['item']['detail']['item']['conditionName'];
        
        $condition_map = [
            '新品、未使用' => 'New',
            '未使用に近い' => 'Like New',
            '目立った傷や汚れなし' => 'Excellent',
            'やや傷や汚れあり' => 'Good',
            '傷や汚れあり' => 'Fair',
            '全体的に状態が悪い' => 'Poor',
            'ジャンク品' => 'For Parts'
        ];
        
        $product_condition = $condition_map[$japanese_condition] ?? 'Used';
        
        writeLog("✅ [JSON状態マッピング] {$japanese_condition} -> {$product_condition}", 'SUCCESS');
        return $product_condition;
        
    } catch (Exception $e) {
        $errors[] = "JSON商品状態抽出中にエラー: " . $e->getMessage();
        return null;
    }
}

/**
 * JSONデータからの価格抽出（HTML構造ベース版）
 */
function extractPriceFromJSONHTMLStructure($json_data, &$errors) {
    try {
        if (!$json_data || !isset($json_data['item']['detail']['item'])) {
            $errors[] = 'JSONから価格データが見つかりません';
            return null;
        }
        
        $item = $json_data['item']['detail']['item'];
        $price_fields = ['bidorbuy', 'price', 'initPrice'];
        
        foreach ($price_fields as $field) {
            if (isset($item[$field]) && $item[$field] > 0) {
                $price = (int)$item[$field];
                writeLog("✅ [JSON価格抽出] {$field}から ¥{$price}", 'SUCCESS');
                return $price;
            }
        }
        
        $errors[] = '有効な価格が見つかりません';
        return null;
        
    } catch (Exception $e) {
        $errors[] = "JSON価格抽出中にエラー: " . $e->getMessage();
        return null;
    }
}

/**
 * JSONデータからのブランド抽出（HTML構造ベース版）
 */
function extractBrandFromJSONHTMLStructure($json_data, &$errors) {
    try {
        if (!$json_data || !isset($json_data['item']['detail']['item']['brand']['path'])) {
            writeLog("⚠️ [JSONブランド] ブランド情報がありません", 'WARNING');
            return null;
        }
        
        $brand_path = $json_data['item']['detail']['item']['brand']['path'];
        $brand = end($brand_path)['name'];
        
        writeLog("✅ [JSONブランド抽出] {$brand}", 'SUCCESS');
        return $brand;
        
    } catch (Exception $e) {
        writeLog("⚠️ [JSONブランドエラー] " . $e->getMessage(), 'WARNING');
        return null;
    }
}

/**
 * JSONデータからのタイトル抽出（HTML構造ベース版）
 */
function extractTitleFromJSONHTMLStructure($json_data, $xpath, &$errors) {
    try {
        if ($json_data && isset($json_data['item']['detail']['item']['title'])) {
            $title = trim($json_data['item']['detail']['item']['title']);
            if (strlen($title) > 5 && strlen($title) < 200) {
                writeLog("✅ [JSONタイトル抽出] " . substr($title, 0, 50) . "...", 'SUCCESS');
                return $title;
            }
        }
        
        $h1_elements = $xpath->query('//h1');
        if ($h1_elements->length > 0) {
            $title = trim($h1_elements->item(0)->textContent);
            if (strlen($title) > 5 && strlen($title) < 200) {
                writeLog("⚠️ [h1タイトル抽出] " . substr($title, 0, 50) . "...", 'WARNING');
                return $title;
            }
        }
        
        $errors[] = 'タイトルの抽出に失敗しました';
        return null;
        
    } catch (Exception $e) {
        $errors[] = "タイトル抽出中にエラー: " . $e->getMessage();
        return null;
    }
}

/**
 * JSONデータからの画像抽出（HTML構造ベース版）
 */
function extractImagesFromJSONHTMLStructure($json_data, &$errors) {
    try {
        if (!$json_data || !isset($json_data['item']['detail']['item']['img'])) {
            writeLog("⚠️ [JSON画像] 画像データがありません", 'WARNING');
            return [];
        }
        
        $img_data = $json_data['item']['detail']['item']['img'];
        $images = [];
        
        foreach ($img_data as $img) {
            if (isset($img['image']) && !empty($img['image'])) {
                $images[] = $img['image'];
                if (count($images) >= 5) break;
            }
        }
        
        writeLog("✅ [JSON画像抽出] " . count($images) . "枚の画像を取得", 'SUCCESS');
        return $images;
        
    } catch (Exception $e) {
        writeLog("❌ [JSON画像エラー] " . $e->getMessage(), 'ERROR');
        return [];
    }
}

/**
 * JSONデータからの基本情報抽出（HTML構造ベース版）
 */
function extractBasicInfoFromJSONHTMLStructure($json_data, &$errors) {
    $basic_info = [
        'quantity' => 1,
        'shipping_from' => null,
        'payment_method' => 'Yahoo!かんたん決済'
    ];
    
    try {
        if ($json_data && isset($json_data['item']['detail']['item'])) {
            $item = $json_data['item']['detail']['item'];
            
            if (isset($item['quantity'])) {
                $basic_info['quantity'] = $item['quantity'];
            }
            
            if (isset($item['seller']['location']['prefecture'])) {
                $basic_info['shipping_from'] = $item['seller']['location']['prefecture'];
            }
        }
        
        writeLog("📦 [JSON基本情報] 発送元: " . ($basic_info['shipping_from'] ?? 'N/A'), 'SUCCESS');
        
    } catch (Exception $e) {
        writeLog("⚠️ [JSON基本情報エラー] " . $e->getMessage(), 'WARNING');
    }
    
    return $basic_info;
}

/**
 * 必須データの検証（HTML構造ベース版）
 */
function validateRequiredDataHTMLStructure($data, &$errors) {
    $required_fields = ['category', 'condition', 'price', 'title'];
    $missing_fields = [];
    
    foreach ($required_fields as $field) {
        if (is_null($data[$field]) || empty($data[$field])) {
            $missing_fields[] = $field;
        }
    }
    
    $is_valid = empty($missing_fields);
    
    if ($is_valid) {
        writeLog("✅ [データ検証成功] 全必須フィールドが揃っています", 'SUCCESS');
    } else {
        writeLog("❌ [データ検証失敗] 不足フィールド: " . implode(', ', $missing_fields), 'ERROR');
    }
    
    return [
        'is_valid' => $is_valid,
        'missing_fields' => $missing_fields
    ];
}

/**
 * 説明文生成（HTML構造ベース版）
 */
function generateDescriptionHTMLStructure($title, $category, $condition, $brand) {
    $parts = [];
    
    if ($title) $parts[] = $title;
    if ($category) $parts[] = "カテゴリ: {$category}";
    if ($condition) $parts[] = "状態: {$condition}";
    if ($brand) $parts[] = "ブランド: {$brand}";
    
    return implode(" | ", $parts);
}

echo "✅ HTML Structure Based Yahoo Auction Parser（関数重複回避版） 読み込み完了\n";
?>
