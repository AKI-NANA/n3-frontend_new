<?php
/**
 * データベーススキーマ確認・画像データ修正ツール
 */

echo "<h1>🔍 データベーススキーマ確認・画像データ修正ツール</h1>";

try {
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // 1. テーブル構造確認
    echo "<h2>1. 📊 yahoo_scraped_products テーブル構造</h2>";
    
    $schemaSql = "SELECT column_name, data_type, is_nullable, column_default 
                  FROM information_schema.columns 
                  WHERE table_name = 'yahoo_scraped_products' 
                  AND table_schema = 'public'
                  ORDER BY ordinal_position";
    
    $schemaStmt = $pdo->query($schemaSql);
    $columns = $schemaStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.9em;'>";
    echo "<tr><th>カラム名</th><th>データ型</th><th>NULL許可</th><th>デフォルト値</th></tr>";
    
    $imageColumns = [];
    foreach ($columns as $column) {
        $rowColor = '';
        if (strpos($column['column_name'], 'image') !== false || 
            strpos($column['column_name'], 'picture') !== false ||
            $column['column_name'] === 'scraped_yahoo_data') {
            $rowColor = 'background: #fff3cd;'; // 画像関連は黄色背景
            $imageColumns[] = $column['column_name'];
        }
        
        echo "<tr style='{$rowColor}'>";
        echo "<td><strong>{$column['column_name']}</strong></td>";
        echo "<td>{$column['data_type']}</td>";
        echo "<td>{$column['is_nullable']}</td>";
        echo "<td>" . ($column['column_default'] ?: 'なし') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<div style='margin: 15px 0; padding: 10px; background: #fff3cd; border-radius: 4px;'>";
    echo "<strong>📸 画像関連カラム:</strong> " . implode(', ', $imageColumns);
    echo "</div>";
    
    // 2. 実際のデータサンプル確認
    echo "<h2>2. 📋 実際のデータサンプル（最新3件）</h2>";
    
    // 正しいカラム名でクエリ実行
    $correctImageColumns = [];
    foreach ($imageColumns as $col) {
        $correctImageColumns[] = $col;
    }
    
    $dataSql = "SELECT id, source_item_id, active_title, " . implode(', ', $correctImageColumns) . "
                FROM yahoo_scraped_products 
                ORDER BY updated_at DESC 
                LIMIT 3";
    
    $dataStmt = $pdo->query($dataSql);
    $sampleData = $dataStmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($sampleData as $row) {
        echo "<div style='border: 1px solid #ddd; margin: 15px 0; padding: 15px; border-radius: 8px; background: #f9f9f9;'>";
        echo "<h3 style='color: #2c3e50; margin: 0 0 10px 0;'>ID: {$row['id']} - {$row['source_item_id']}</h3>";
        echo "<p><strong>タイトル:</strong> " . substr($row['active_title'], 0, 60) . "...</p>";
        
        foreach ($imageColumns as $imageCol) {
            if (isset($row[$imageCol])) {
                echo "<h4 style='color: #e74c3c;'>📸 {$imageCol}:</h4>";
                
                if ($imageCol === 'scraped_yahoo_data') {
                    if ($row[$imageCol]) {
                        $dataLength = strlen($row[$imageCol]);
                        echo "<p style='color: green;'>✅ データあり: {$dataLength} 文字</p>";
                        
                        // JSONデータの画像部分を解析
                        try {
                            $jsonData = json_decode($row[$imageCol], true);
                            if ($jsonData) {
                                $imageFields = [];
                                if (isset($jsonData['all_images'])) $imageFields['all_images'] = $jsonData['all_images'];
                                if (isset($jsonData['images'])) $imageFields['images'] = $jsonData['images'];
                                if (isset($jsonData['extraction_results']['images'])) $imageFields['extraction_results.images'] = $jsonData['extraction_results']['images'];
                                
                                if (!empty($imageFields)) {
                                    echo "<div style='background: #e8f5e8; padding: 5px; border-radius: 3px; margin: 5px 0;'>";
                                    foreach ($imageFields as $fieldName => $images) {
                                        if (is_array($images)) {
                                            echo "<p style='margin: 2px 0; font-size: 0.9em;'><strong>{$fieldName}:</strong> {count($images)}件</p>";
                                        }
                                    }
                                    echo "</div>";
                                } else {
                                    echo "<p style='color: orange;'>⚠️ JSON内に画像データなし</p>";
                                }
                            }
                        } catch (Exception $e) {
                            echo "<p style='color: red;'>❌ JSON解析エラー</p>";
                        }
                    } else {
                        echo "<p style='color: red;'>❌ データなし（NULL）</p>";
                    }
                } else {
                    // 画像URL系カラム
                    if ($row[$imageCol]) {
                        echo "<p style='color: green;'>✅ データあり: " . substr($row[$imageCol], 0, 60) . "...</p>";
                        if (filter_var($row[$imageCol], FILTER_VALIDATE_URL)) {
                            echo "<img src='{$row[$imageCol]}' style='max-width: 100px; max-height: 80px; border: 1px solid #ddd; margin: 5px;' alt='{$imageCol}' loading='lazy'>";
                        }
                    } else {
                        echo "<p style='color: red;'>❌ データなし（NULL）</p>";
                    }
                }
            }
        }
        echo "</div>";
    }
    
    // 3. 画像データ統計
    echo "<h2>3. 📊 画像データ統計</h2>";
    
    $statsSql = "SELECT COUNT(*) as total_records";
    foreach ($imageColumns as $imageCol) {
        $statsSql .= ", COUNT({$imageCol}) as has_{$imageCol}";
    }
    $statsSql .= " FROM yahoo_scraped_products";
    
    $statsStmt = $pdo->query($statsSql);
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>項目</th><th>件数</th><th>割合</th></tr>";
    echo "<tr><td>総レコード数</td><td>{$stats['total_records']}</td><td>100%</td></tr>";
    
    foreach ($imageColumns as $imageCol) {
        $count = $stats["has_{$imageCol}"];
        $percentage = $stats['total_records'] > 0 ? round($count / $stats['total_records'] * 100, 1) : 0;
        echo "<tr><td>{$imageCol} あり</td><td>{$count}</td><td>{$percentage}%</td></tr>";
    }
    echo "</table>";
    
    // 4. JavaScript修正コード生成
    echo "<h2>4. 🔧 JavaScript修正コード生成</h2>";
    
    echo "<div style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>";
    echo "<h4>正しいカラム名に基づくJavaScript修正版:</h4>";
    echo "<textarea readonly style='width: 100%; height: 300px; font-family: monospace; font-size: 0.8em;'>";
    
    $jsCode = "// 正しいカラム名に基づく画像データ抽出関数\nfunction extractImagesFromData(product) {\n    let images = [];\n    let debugLog = [];\n    \n    console.log('🔍 画像抽出開始:', product.title || product.active_title);\n    \n";
    
    foreach ($imageColumns as $imageCol) {
        if ($imageCol !== 'scraped_yahoo_data') {
            $jsCode .= "    // {$imageCol} から取得\n";
            $jsCode .= "    if (product.{$imageCol} && !product.{$imageCol}.includes('placehold')) {\n";
            $jsCode .= "        images.push(product.{$imageCol});\n";
            $jsCode .= "        debugLog.push(`✅ {$imageCol}: \${product.{$imageCol}.substring(0, 50)}...`);\n";
            $jsCode .= "    } else {\n";
            $jsCode .= "        debugLog.push(`❌ {$imageCol}: \${product.{$imageCol} || 'なし'}`);\n";
            $jsCode .= "    }\n    \n";
        }
    }
    
    $jsCode .= "    // scraped_yahoo_data から画像を抽出\n";
    $jsCode .= "    if (product.scraped_yahoo_data) {\n";
    $jsCode .= "        try {\n";
    $jsCode .= "            const scrapedData = typeof product.scraped_yahoo_data === 'string' \n";
    $jsCode .= "                ? JSON.parse(product.scraped_yahoo_data) \n";
    $jsCode .= "                : product.scraped_yahoo_data;\n";
    $jsCode .= "            \n";
    $jsCode .= "            if (scrapedData.all_images && Array.isArray(scrapedData.all_images)) {\n";
    $jsCode .= "                images = images.concat(scrapedData.all_images);\n";
    $jsCode .= "                debugLog.push(`✅ all_images: \${scrapedData.all_images.length}件追加`);\n";
    $jsCode .= "            }\n";
    $jsCode .= "            \n";
    $jsCode .= "            if (scrapedData.images && Array.isArray(scrapedData.images)) {\n";
    $jsCode .= "                images = images.concat(scrapedData.images);\n";
    $jsCode .= "                debugLog.push(`✅ images: \${scrapedData.images.length}件追加`);\n";
    $jsCode .= "            }\n";
    $jsCode .= "        } catch (e) {\n";
    $jsCode .= "            debugLog.push(`❌ scraped_yahoo_data 解析エラー: \${e.message}`);\n";
    $jsCode .= "        }\n";
    $jsCode .= "    } else {\n";
    $jsCode .= "        debugLog.push('❌ scraped_yahoo_data: なし');\n";
    $jsCode .= "    }\n";
    $jsCode .= "    \n";
    $jsCode .= "    // 重複除去とフィルタリング\n";
    $jsCode .= "    images = [...new Set(images)].filter(img => \n";
    $jsCode .= "        img && \n";
    $jsCode .= "        typeof img === 'string' && \n";
    $jsCode .= "        img.length > 10 && \n";
    $jsCode .= "        !img.includes('placehold') &&\n";
    $jsCode .= "        (img.startsWith('http') || img.startsWith('//'))\n";
    $jsCode .= "    );\n";
    $jsCode .= "    \n";
    $jsCode .= "    console.log('🖼️ 画像抽出結果:', {\n";
    $jsCode .= "        product_id: product.item_id || product.id,\n";
    $jsCode .= "        total_images: images.length,\n";
    $jsCode .= "        images: images,\n";
    $jsCode .= "        debug_log: debugLog\n";
    $jsCode .= "    });\n";
    $jsCode .= "    \n";
    $jsCode .= "    return images.length > 0 ? images : ['https://placehold.co/300x200/725CAD/FFFFFF/png?text=No+Image'];\n";
    $jsCode .= "}";
    
    echo htmlspecialchars($jsCode);
    echo "</textarea>";
    echo "</div>";
    
    // 5. scraped_yahoo_dataがNULLのレコード確認
    echo "<h2>5. ⚠️ scraped_yahoo_data NULL レコード確認</h2>";
    
    $nullDataSql = "SELECT COUNT(*) as null_count FROM yahoo_scraped_products WHERE scraped_yahoo_data IS NULL";
    $nullStmt = $pdo->query($nullDataSql);
    $nullCount = $nullStmt->fetch(PDO::FETCH_ASSOC)['null_count'];
    
    if ($nullCount > 0) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6; border-radius: 4px;'>";
        echo "⚠️ scraped_yahoo_data が NULL のレコードが {$nullCount} 件あります。";
        echo "</div>";
        
        echo "<p>これらのレコードは再スクレイピングが必要です。</p>";
        
        // NULL レコードの詳細
        $nullDetailSql = "SELECT id, source_item_id, active_title, updated_at 
                          FROM yahoo_scraped_products 
                          WHERE scraped_yahoo_data IS NULL 
                          ORDER BY updated_at DESC 
                          LIMIT 5";
        
        $nullDetailStmt = $pdo->query($nullDetailSql);
        $nullDetails = $nullDetailStmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<h4>NULL データのサンプル:</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%; font-size: 0.8em;'>";
        echo "<tr><th>ID</th><th>source_item_id</th><th>タイトル</th><th>更新日</th></tr>";
        
        foreach ($nullDetails as $nullRow) {
            echo "<tr>";
            echo "<td>{$nullRow['id']}</td>";
            echo "<td>{$nullRow['source_item_id']}</td>";
            echo "<td>" . substr($nullRow['active_title'], 0, 40) . "...</td>";
            echo "<td>{$nullRow['updated_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div style='color: green; padding: 10px; background: #e8f5e8; border-radius: 4px;'>";
        echo "✅ すべてのレコードに scraped_yahoo_data があります。";
        echo "</div>";
    }
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベースエラー: " . $e->getMessage();
    echo "</div>";
}

echo "<hr>";
echo "<p style='text-align: center;'>";
echo "<a href='../05_editing/editing.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>📝 editing.phpで確認</a>";
echo "<a href='../02_scraping/scraping.php' style='background: #28a745; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px;'>🕷️ 再スクレイピング</a>";
echo "</p>";
?>
