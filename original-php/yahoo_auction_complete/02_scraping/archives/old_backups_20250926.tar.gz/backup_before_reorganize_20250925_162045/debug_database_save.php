<?php
/**
 * データベース保存エラー調査・修正スクリプト
 */

echo "<h1>🔧 データベース保存エラー調査・修正</h1>";

try {
    // データベース接続テスト
    $dsn = "pgsql:host=localhost;dbname=nagano3_db";
    $user = "postgres";
    $password = "Kn240914";
    
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ データベース接続成功</div>";
    
    // テーブル構造確認
    echo "<h2>1. テーブル構造確認</h2>";
    $sql = "SELECT column_name, data_type, is_nullable, column_default 
            FROM information_schema.columns 
            WHERE table_name = 'yahoo_scraped_products' 
            ORDER BY ordinal_position";
    
    $stmt = $pdo->query($sql);
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>カラム名</th><th>データ型</th><th>NULL許可</th><th>デフォルト値</th></tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>{$column['column_name']}</td>";
        echo "<td>{$column['data_type']}</td>";
        echo "<td>{$column['is_nullable']}</td>";
        echo "<td>" . ($column['column_default'] ?: 'なし') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // テストデータ挿入
    echo "<h2>2. テストデータ挿入</h2>";
    
    $test_data = [
        'source_item_id' => 'TEST_DEBUG_' . time(),
        'sku' => 'SKU-DEBUG-' . time(),
        'price_jpy' => 1500,
        'scraped_yahoo_data' => json_encode(['test' => 'debug_data'], JSON_UNESCAPED_UNICODE),
        'active_title' => 'デバッグテスト商品',
        'active_description' => 'データベース保存テスト用',
        'active_price_usd' => 10.0,
        'active_image_url' => 'https://placehold.co/300x200/725CAD/FFFFFF/png?text=Debug+Test',
        'current_stock' => 1,
        'status' => 'test'
    ];
    
    $insert_sql = "INSERT INTO yahoo_scraped_products (
        source_item_id, sku, price_jpy, scraped_yahoo_data, active_title,
        active_description, active_price_usd, active_image_url, current_stock,
        status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
    
    try {
        $stmt = $pdo->prepare($insert_sql);
        $result = $stmt->execute([
            $test_data['source_item_id'],
            $test_data['sku'],
            $test_data['price_jpy'],
            $test_data['scraped_yahoo_data'],
            $test_data['active_title'],
            $test_data['active_description'],
            $test_data['active_price_usd'],
            $test_data['active_image_url'],
            $test_data['current_stock'],
            $test_data['status']
        ]);
        
        if ($result) {
            $insert_id = $pdo->lastInsertId();
            echo "<div style='color: green; padding: 10px; background: #e8f5e8; margin: 10px 0;'>✅ テストデータ挿入成功 - ID: {$insert_id}</div>";
            
            // 挿入されたデータ確認
            $check_sql = "SELECT * FROM yahoo_scraped_products WHERE id = ?";
            $check_stmt = $pdo->prepare($check_sql);
            $check_stmt->execute([$insert_id]);
            $inserted = $check_stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($inserted) {
                echo "<h3>挿入されたデータ:</h3>";
                echo "<pre>" . json_encode($inserted, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "</pre>";
                
                // テストデータ削除
                $delete_sql = "DELETE FROM yahoo_scraped_products WHERE id = ?";
                $delete_stmt = $pdo->prepare($delete_sql);
                $delete_stmt->execute([$insert_id]);
                echo "<div style='color: blue; padding: 5px;'>🗑️ テストデータを削除しました</div>";
            }
        } else {
            echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>❌ テストデータ挿入失敗</div>";
            echo "<pre>" . json_encode($stmt->errorInfo(), JSON_PRETTY_PRINT) . "</pre>";
        }
        
    } catch (PDOException $e) {
        echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>❌ 挿入エラー: " . $e->getMessage() . "</div>";
        echo "<pre>SQLState: " . $e->getCode() . "</pre>";
        echo "<pre>ErrorInfo: " . json_encode($e->errorInfo, JSON_PRETTY_PRINT) . "</pre>";
    }
    
    // 最近のレコード確認
    echo "<h2>3. 最近のレコード（5件）</h2>";
    $recent_sql = "SELECT id, source_item_id, active_title, price_jpy, status, created_at 
                   FROM yahoo_scraped_products 
                   ORDER BY created_at DESC 
                   LIMIT 5";
    
    $recent_stmt = $pdo->query($recent_sql);
    $recent_data = $recent_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($recent_data)) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Item ID</th><th>タイトル</th><th>価格</th><th>ステータス</th><th>作成日時</th></tr>";
        
        foreach ($recent_data as $record) {
            echo "<tr>";
            echo "<td>{$record['id']}</td>";
            echo "<td>{$record['source_item_id']}</td>";
            echo "<td>" . substr($record['active_title'], 0, 30) . "...</td>";
            echo "<td>¥" . number_format($record['price_jpy']) . "</td>";
            echo "<td>{$record['status']}</td>";
            echo "<td>{$record['created_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div style='color: orange; padding: 10px;'>📊 レコードがありません</div>";
    }
    
    echo "<h2>4. 推奨対処法</h2>";
    echo "<div style='padding: 10px; background: #f0f8ff; border-radius: 5px;'>";
    echo "<ol>";
    echo "<li><strong>スクレイピング再実行:</strong> scraping.php で詳細ログを確認</li>";
    echo "<li><strong>ログファイル確認:</strong> scraping_logs.txt でエラー詳細を確認</li>";
    echo "<li><strong>Emergency Parser確認:</strong> Emergency Parser が正常動作しているか確認</li>";
    echo "<li><strong>JSON フォーマット確認:</strong> scraped_yahoo_data のフォーマットが正しいか確認</li>";
    echo "</ol>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='color: red; padding: 10px; background: #ffe6e6; margin: 10px 0;'>";
    echo "❌ データベース接続エラー: " . $e->getMessage();
    echo "</div>";
    
    echo "<h3>対処法:</h3>";
    echo "<ul>";
    echo "<li>PostgreSQL サービスが起動しているか確認: <code>brew services list | grep postgres</code></li>";
    echo "<li>データベース 'nagano3_db' が存在するか確認</li>";
    echo "<li>ユーザー 'postgres' の権限確認</li>";
    echo "</ul>";
}

echo "<hr>";
echo "<p><a href='scraping.php'>← スクレイピングに戻る</a> | <a href='../05_editing/editing.php'>データ編集へ →</a></p>";
?>
