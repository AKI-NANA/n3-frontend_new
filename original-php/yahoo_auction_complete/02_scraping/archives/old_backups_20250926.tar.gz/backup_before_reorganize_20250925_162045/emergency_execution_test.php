<?php
/**
 * 🚨 emergency_fix_test.php 実行確認テスト
 */

header('Content-Type: text/html; charset=UTF-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🚨 Emergency Fix Test 実行状況確認</h1>";

// 現在の実行状況
echo "<h2>実行状況</h2>";
echo "<p><strong>現在時刻:</strong> " . date('Y-m-d H:i:s') . "</p>";
echo "<p><strong>PHPバージョン:</strong> " . PHP_VERSION . "</p>";
echo "<p><strong>スクリプトパス:</strong> " . __FILE__ . "</p>";

// ファイル存在チェック
$emergency_file = __DIR__ . '/emergency_fix_test.php';
$parser_file = __DIR__ . '/yahoo_parser_emergency.php';

echo "<h2>ファイル存在確認</h2>";
echo "<p>emergency_fix_test.php: " . ($file_exists_emergency = file_exists($emergency_file) ? "✅ 存在" : "❌ 不存在") . "</p>";
echo "<p>yahoo_parser_emergency.php: " . ($file_exists_parser = file_exists($parser_file) ? "✅ 存在" : "❌ 不存在") . "</p>";

if ($file_exists_emergency) {
    echo "<p>emergency_fix_test.phpサイズ: " . filesize($emergency_file) . " bytes</p>";
    echo "<p>最終更新: " . date('Y-m-d H:i:s', filemtime($emergency_file)) . "</p>";
}

if ($file_exists_parser) {
    echo "<p>yahoo_parser_emergency.phpサイズ: " . filesize($parser_file) . " bytes</p>";
    echo "<p>最終更新: " . date('Y-m-d H:i:s', filemtime($parser_file)) . "</p>";
}

// emergency_fix_test.phpの最初の50行を表示
if ($file_exists_emergency) {
    echo "<h2>emergency_fix_test.php 先頭部分</h2>";
    $lines = file($emergency_file);
    echo "<pre style='background:#f5f5f5; padding:10px; font-size:12px;'>";
    for ($i = 0; $i < min(50, count($lines)); $i++) {
        echo htmlspecialchars(sprintf("%03d: %s", $i + 1, $lines[$i]));
    }
    echo "</pre>";
}

// 実際のテスト実行
echo "<h2>実際の実行テスト</h2>";
echo "<p>emergency_fix_test.php を include して実行します...</p>";

ob_start();
try {
    if ($file_exists_emergency && $file_exists_parser) {
        echo "<p>🔄 emergency_fix_test.php実行開始...</p>";
        
        // バッファリングして実行
        $emergency_output = '';
        ob_start();
        include $emergency_file;
        $emergency_output = ob_get_clean();
        
        echo "<h3>✅ 実行完了 - 出力内容:</h3>";
        echo "<div style='border:1px solid #ccc; padding:10px; max-height:600px; overflow-y:auto; background:white;'>";
        echo $emergency_output;
        echo "</div>";
        
    } else {
        echo "<p>❌ 必要ファイルが不存在のため実行不可</p>";
    }
} catch (Exception $e) {
    echo "<p>❌ 実行エラー: " . htmlspecialchars($e->getMessage()) . "</p>";
} catch (Error $e) {
    echo "<p>❌ PHP Fatal Error: " . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>File: " . $e->getFile() . " Line: " . $e->getLine() . "</p>";
}

$buffered_output = ob_get_clean();
echo $buffered_output;

echo "<hr>";
echo "<h2>🎯 アクセス方法</h2>";
echo "<p>ブラウザで以下のURLにアクセスしてください:</p>";
echo "<ul>";
echo "<li><a href='http://localhost:8000/new_structure/02_scraping/emergency_fix_test.php' target='_blank'>http://localhost:8000/new_structure/02_scraping/emergency_fix_test.php</a></li>";
echo "<li><a href='emergency_fix_test.php' target='_blank'>emergency_fix_test.php (相対パス)</a></li>";
echo "</ul>";

echo "<h2>🔧 診断結果</h2>";
if ($file_exists_emergency && $file_exists_parser) {
    echo "<p>✅ ファイル: OK</p>";
    echo "<p>🔄 実行テスト: 完了（上記参照）</p>";
} else {
    echo "<p>❌ 問題: 必要ファイルが不存在</p>";
}
?>
