<?php
/**
 * 02_scraping/scripts/inventory_test.php
 * 
 * 在庫管理システム統合テストスクリプト
 * 全機能の動作確認とパフォーマンステスト
 */

// CLI実行のみ許可
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    exit('このスクリプトはコマンドラインからのみ実行可能です');
}

require_once __DIR__ . '/../includes/InventoryEngine.php';
require_once __DIR__ . '/../includes/PriceMonitor.php';
require_once __DIR__ . '/../includes/UrlValidator.php';
require_once __DIR__ . '/../includes/InventoryLogger.php';

class InventorySystemTest {
    private $engine;
    private $priceMonitor;
    private $urlValidator;
    private $logger;
    private $testResults;
    
    public function __construct() {
        $this->engine = new InventoryEngine();
        $this->priceMonitor = new PriceMonitor();
        $this->urlValidator = new UrlValidator();
        $this->logger = new InventoryLogger();
        $this->testResults = [];
    }
    
    /**
     * 全テスト実行
     */
    public function runAllTests() {
        echo "======= 在庫管理システム統合テスト開始 =======\n";
        echo "実行時刻: " . date('Y-m-d H:i:s') . "\n\n";
        
        $startTime = microtime(true);
        
        try {
            // 1. 基本機能テスト
            $this->runBasicFunctionTests();
            
            // 2. データベーステスト
            $this->runDatabaseTests();
            
            // 3. APIテスト
            $this->runApiTests();
            
            // 4. 統合テスト
            $this->runIntegrationTests();
            
            // 5. パフォーマンステスト
            $this->runPerformanceTests();
            
            // 6. エラーハンドリングテスト
            $this->runErrorHandlingTests();
            
            $executionTime = microtime(true) - $startTime;
            
            // テスト結果サマリー
            $this->displayTestSummary($executionTime);
            
            return $this->testResults;
            
        } catch (Exception $e) {
            echo "テスト実行エラー: " . $e->getMessage() . "\n";
            return false;
        }
    }
    
    /**
     * 基本機能テスト
     */
    private function runBasicFunctionTests() {
        echo "=== 基本機能テスト ===\n";
        
        // 1. InventoryEngine基本機能
        $this->testBasicFunction('InventoryEngine初期化', function() {
            $engine = new InventoryEngine();
            return $engine instanceof InventoryEngine;
        });
        
        // 2. 出品商品登録テスト
        $this->testBasicFunction('出品商品登録', function() {
            return $this->testProductRegistration();
        });
        
        // 3. 監視ステータス取得
        $this->testBasicFunction('監視ステータス取得', function() {
            $status = $this->engine->getMonitoringStatus();
            return is_array($status);
        });
        
        // 4. 価格変動検知
        $this->testBasicFunction('価格変動検知', function() {
            $changeData = $this->priceMonitor->detectPriceChange(1, 1000, 1100);
            return isset($changeData['change_percent']);
        });
        
        // 5. URL検証
        $this->testBasicFunction('URL検証', function() {
            $result = $this->urlValidator->validateUrl('https://page.auctions.yahoo.co.jp/jp/auction/test123');
            return isset($result['valid']);
        });
        
        echo "\n";
    }
    
    /**
     * データベーステスト
     */
    private function runDatabaseTests() {
        echo "=== データベーステスト ===\n";
        
        // 1. テーブル存在確認
        $this->testDatabase('必要テーブル存在確認', function() {
            $db = Database::getInstance();
            $tables = [
                'inventory_management',
                'stock_history', 
                'listing_platforms',
                'inventory_execution_logs',
                'inventory_errors'
            ];
            
            foreach ($tables as $table) {
                $result = $db->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_name = ?", [$table])->fetch();
                if ($result['count'] == 0) {
                    throw new Exception("テーブル {$table} が存在しません");
                }
            }
            return true;
        });
        
        // 2. インデックス確認
        $this->testDatabase('インデックス確認', function() {
            $db = Database::getInstance();
            $indexes = [
                'idx_inventory_product_monitoring',
                'idx_history_product_time',
                'idx_execution_type_status'
            ];
            
            foreach ($indexes as $index) {
                $result = $db->query("SELECT COUNT(*) FROM pg_indexes WHERE indexname = ?", [$index])->fetch();
                if ($result['count'] == 0) {
                    echo "警告: インデックス {$index} が見つかりません\n";
                }
            }
            return true;
        });
        
        // 3. データ挿入・更新・削除テスト
        $this->testDatabase('CRUD操作テスト', function() {
            return $this->testCrudOperations();
        });
        
        // 4. トランザクションテスト
        $this->testDatabase('トランザクションテスト', function() {
            return $this->testTransactions();
        });
        
        echo "\n";
    }
    
    /**
     * APIテスト
     */
    private function runApiTests() {
        echo "=== APIテスト ===\n";
        
        // 1. API基本通信テスト
        $this->testApi('API基本通信', function() {
            $response = $this->makeApiRequest('get_monitoring_status');
            return isset($response['success']);
        });
        
        // 2. エラーレスポンステスト
        $this->testApi('エラーレスポンス', function() {
            $response = $this->makeApiRequest('invalid_action');
            return !$response['success'] && isset($response['message']);
        });
        
        // 3. パラメータ検証テスト
        $this->testApi('パラメータ検証', function() {
            $response = $this->makeApiRequest('register_listed_product', ['invalid' => 'data']);
            return !$response['success'];
        });
        
        echo "\n";
    }
    
    /**
     * 統合テスト
     */
    private function runIntegrationTests() {
        echo "=== 統合テスト ===\n";
        
        // 1. 08_listing統合テスト
        $this->testIntegration('08_listing統合', function() {
            return $this->testListingIntegration();
        });
        
        // 2. 10_zaiko統合テスト
        $this->testIntegration('10_zaiko統合', function() {
            return $this->testZaikoIntegration();
        });
        
        // 3. エンドツーエンドフロー
        $this->testIntegration('E2Eフロー', function() {
            return $this->testEndToEndFlow();
        });
        
        echo "\n";
    }
    
    /**
     * パフォーマンステスト
     */
    private function runPerformanceTests() {
        echo "=== パフォーマンステスト ===\n";
        
        // 1. 大量データ処理
        $this->testPerformance('大量データ処理', function() {
            $startTime = microtime(true);
            
            // 100件の商品で在庫チェック実行
            $productIds = range(1, 100);
            $this->engine->performInventoryCheck(array_slice($productIds, 0, 10)); // 実際は10件でテスト
            
            $duration = microtime(true) - $startTime;
            return $duration < 30; // 30秒以内
        });
        
        // 2. 同時リクエスト処理
        $this->testPerformance('同時リクエスト処理', function() {
            return $this->testConcurrentRequests();
        });
        
        // 3. メモリ使用量テスト
        $this->testPerformance('メモリ使用量', function() {
            $initialMemory = memory_get_usage();
            
            // メモリ集約的な処理
            for ($i = 0; $i < 1000; $i++) {
                $this->priceMonitor->detectPriceChange($i, 1000, 1100);
            }
            
            $finalMemory = memory_get_usage();
            $memoryIncrease = $finalMemory - $initialMemory;
            
            return $memoryIncrease < 50 * 1024 * 1024; // 50MB以下
        });
        
        echo "\n";
    }
    
    /**
     * エラーハンドリングテスト
     */
    private function runErrorHandlingTests() {
        echo "=== エラーハンドリングテスト ===\n";
        
        // 1. 不正データテスト
        $this->testErrorHandling('不正データ処理', function() {
            try {
                $this->engine->registerListedProduct(-1); // 不正なID
                return false;
            } catch (Exception $e) {
                return true; // 例外が発生することを期待
            }
        });
        
        // 2. ネットワークエラーテスト
        $this->testErrorHandling('ネットワークエラー', function() {
            $result = $this->urlValidator->validateUrl('https://invalid-domain-12345.com');
            return !$result['valid'];
        });
        
        // 3. データベースエラーテスト
        $this->testErrorHandling('データベースエラー', function() {
            try {
                $db = Database::getInstance();
                $db->query("SELECT * FROM non_existent_table");
                return false;
            } catch (Exception $e) {
                return true;
            }
        });
        
        echo "\n";
    }
    
    // ===============================================
    // 個別テスト実装
    // ===============================================
    
    /**
     * 出品商品登録テスト
     */
    private function testProductRegistration() {
        // テスト用の商品データを作成
        $db = Database::getInstance();
        
        // テスト商品作成
        $testProductId = $this->createTestProduct();
        
        try {
            // 在庫管理に登録
            $result = $this->engine->registerListedProduct($testProductId);
            
            // 登録確認
            $registered = $db->query("SELECT * FROM inventory_management WHERE product_id = ?", [$testProductId])->fetch();
            
            return $result['success'] && !empty($registered);
            
        } finally {
            // テストデータクリーンアップ
            $this->cleanupTestProduct($testProductId);
        }
    }
    
    /**
     * CRUD操作テスト
     */
    private function testCrudOperations() {
        $db = Database::getInstance();
        
        try {
            // Insert
            $insertId = $db->insert('inventory_management', [
                'product_id' => 99999,
                'source_platform' => 'test',
                'source_url' => 'https://test.example.com',
                'current_price' => 1000
            ]);
            
            if (!$insertId) return false;
            
            // Select
            $selected = $db->query("SELECT * FROM inventory_management WHERE id = ?", [$insertId])->fetch();
            if (!$selected || $selected['product_id'] != 99999) return false;
            
            // Update
            $updated = $db->update('inventory_management', 
                ['current_price' => 1500], 
                ['id' => $insertId]
            );
            if (!$updated) return false;
            
            // Verify update
            $updated = $db->query("SELECT current_price FROM inventory_management WHERE id = ?", [$insertId])->fetch();
            if ($updated['current_price'] != 1500) return false;
            
            // Delete
            $deleted = $db->delete('inventory_management', ['id' => $insertId]);
            if (!$deleted) return false;
            
            return true;
            
        } catch (Exception $e) {
            echo "CRUD テストエラー: " . $e->getMessage() . "\n";
            return false;
        }
    }
    
    /**
     * トランザクションテスト
     */
    private function testTransactions() {
        $db = Database::getInstance();
        
        try {
            $db->beginTransaction();
            
            // 複数テーブルに挿入
            $inventoryId = $db->insert('inventory_management', [
                'product_id' => 99998,
                'source_platform' => 'test',
                'source_url' => 'https://test.example.com'
            ]);
            
            $historyId = $db->insert('stock_history', [
                'product_id' => 99998,
                'new_price' => 1000,
                'change_type' => 'initial'
            ]);
            
            if (!$inventoryId || !$historyId) {
                throw new Exception("挿入失敗");
            }
            
            // ロールバックテスト
            $db->rollback();
            
            // データが存在しないことを確認
            $inventory = $db->query("SELECT * FROM inventory_management WHERE id = ?", [$inventoryId])->fetch();
            $history = $db->query("SELECT * FROM stock_history WHERE id = ?", [$historyId])->fetch();
            
            return empty($inventory) && empty($history);
            
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
    }
    
    /**
     * APIリクエスト実行
     */
    private function makeApiRequest($action, $data = []) {
        $url = 'http://localhost/02_scraping/api/inventory_monitor.php';
        
        $postData = array_merge(['action' => $action], $data);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200 || !$response) {
            return ['success' => false, 'message' => 'API通信失敗'];
        }
        
        return json_decode($response, true) ?: ['success' => false, 'message' => 'レスポンス解析失敗'];
    }
    
    /**
     * 08_listing統合テスト
     */
    private function testListingIntegration() {
        // 統合クラスの動作確認
        require_once __DIR__ . '/../../../08_listing/scripts/bulk_inventory_registration.php';
        
        try {
            $integration = new EbayListingInventoryIntegration();
            $testProductId = $this->createTestProduct();
            
            $result = $integration->onListingCompleted($testProductId, 'TEST_EBAY_ID');
            
            $this->cleanupTestProduct($testProductId);
            
            return $result['success'];
            
        } catch (Exception $e) {
            echo "08_listing統合エラー: " . $e->getMessage() . "\n";
            return false;
        }
    }
    
    /**
     * 10_zaiko統合テスト
     */
    private function testZaikoIntegration() {
        // JavaScript統合ライブラリのテスト（PHPからはAPI経由）
        try {
            $response = $this->makeApiRequest('get_statistics');
            return $response['success'] && isset($response['statistics']);
            
        } catch (Exception $e) {
            echo "10_zaiko統合エラー: " . $e->getMessage() . "\n";
            return false;
        }
    }
    
    /**
     * エンドツーエンドフローテスト
     */
    private function testEndToEndFlow() {
        try {
            // 1. 商品登録
            $testProductId = $this->createTestProduct();
            
            // 2. 在庫管理登録
            $registerResult = $this->engine->registerListedProduct($testProductId);
            if (!$registerResult['success']) return false;
            
            // 3. 監視開始
            $monitorResult = $this->engine->startMonitoring([$testProductId]);
            if (!$monitorResult['success']) return false;
            
            // 4. 在庫チェック実行
            $checkResult = $this->engine->performInventoryCheck([$testProductId]);
            if (!$checkResult || $checkResult['total'] === 0) return false;
            
            // 5. 監視停止
            $stopResult = $this->engine->stopMonitoring([$testProductId]);
            if (!$stopResult['success']) return false;
            
            $this->cleanupTestProduct($testProductId);
            
            return true;
            
        } catch (Exception $e) {
            echo "E2Eフローエラー: " . $e->getMessage() . "\n";
            return false;
        }
    }
    
    /**
     * 同時リクエストテスト
     */
    private function testConcurrentRequests() {
        // 簡易的な同時実行テスト
        $startTime = microtime(true);
        
        for ($i = 0; $i < 5; $i++) {
            $this->engine->getMonitoringStatus();
        }
        
        $duration = microtime(true) - $startTime;
        
        return $duration < 10; // 10秒以内
    }
    
    // ===============================================
    // テストヘルパーメソッド
    // ===============================================
    
    /**
     * テストデータ作成
     */
    private function createTestProduct() {
        $db = Database::getInstance();
        
        return $db->insert('yahoo_scraped_products', [
            'title' => 'テスト商品',
            'price' => 1000,
            'url' => 'https://page.auctions.yahoo.co.jp/jp/auction/test123',
            'workflow_status' => 'listed',
            'ebay_item_id' => 'TEST_EBAY_123',
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * テストデータクリーンアップ
     */
    private function cleanupTestProduct($productId) {
        $db = Database::getInstance();
        
        $db->delete('inventory_management', ['product_id' => $productId]);
        $db->delete('stock_history', ['product_id' => $productId]);
        $db->delete('listing_platforms', ['product_id' => $productId]);
        $db->delete('yahoo_scraped_products', ['id' => $productId]);
    }
    
    /**
     * テスト実行・結果記録
     */
    private function testBasicFunction($testName, $testFunction) {
        $this->runTest('basic', $testName, $testFunction);
    }
    
    private function testDatabase($testName, $testFunction) {
        $this->runTest('database', $testName, $testFunction);
    }
    
    private function testApi($testName, $testFunction) {
        $this->runTest('api', $testName, $testFunction);
    }
    
    private function testIntegration($testName, $testFunction) {
        $this->runTest('integration', $testName, $testFunction);
    }
    
    private function testPerformance($testName, $testFunction) {
        $this->runTest('performance', $testName, $testFunction);
    }
    
    private function testErrorHandling($testName, $testFunction) {
        $this->runTest('error_handling', $testName, $testFunction);
    }
    
    /**
     * 汎用テスト実行
     */
    private function runTest($category, $testName, $testFunction) {
        echo "テスト実行: {$testName} ... ";
        
        $startTime = microtime(true);
        
        try {
            $result = $testFunction();
            $duration = microtime(true) - $startTime;
            
            if ($result) {
                echo "✓ PASS (" . round($duration, 3) . "s)\n";
                $this->testResults[$category]['passed'][] = $testName;
            } else {
                echo "✗ FAIL (" . round($duration, 3) . "s)\n";
                $this->testResults[$category]['failed'][] = $testName;
            }
            
        } catch (Exception $e) {
            $duration = microtime(true) - $startTime;
            echo "✗ ERROR: " . $e->getMessage() . " (" . round($duration, 3) . "s)\n";
            $this->testResults[$category]['errors'][] = $testName . ': ' . $e->getMessage();
        }
    }
    
    /**
     * テスト結果サマリー表示
     */
    private function displayTestSummary($executionTime) {
        echo "\n======= テスト結果サマリー =======\n";
        echo "総実行時間: " . round($executionTime, 2) . "秒\n\n";
        
        $totalPassed = 0;
        $totalFailed = 0;
        $totalErrors = 0;
        
        foreach ($this->testResults as $category => $results) {
            $passed = count($results['passed'] ?? []);
            $failed = count($results['failed'] ?? []);
            $errors = count($results['errors'] ?? []);
            
            echo ucfirst(str_replace('_', ' ', $category)) . ":\n";
            echo "  ✓ PASS: {$passed}\n";
            echo "  ✗ FAIL: {$failed}\n";
            echo "  ⚠ ERROR: {$errors}\n\n";
            
            $totalPassed += $passed;
            $totalFailed += $failed;
            $totalErrors += $errors;
        }
        
        echo "全体結果:\n";
        echo "  ✓ 成功: {$totalPassed}\n";
        echo "  ✗ 失敗: {$totalFailed}\n";
        echo "  ⚠ エラー: {$totalErrors}\n";
        
        $total = $totalPassed + $totalFailed + $totalErrors;
        $successRate = $total > 0 ? round(($totalPassed / $total) * 100, 1) : 0;
        
        echo "  成功率: {$successRate}%\n\n";
        
        if ($totalFailed > 0 || $totalErrors > 0) {
            echo "⚠ 修正が必要な問題があります\n";
        } else {
            echo "✓ すべてのテストが成功しました\n";
        }
        
        echo "======= テスト完了 =======\n";
    }
}

// メイン実行
if (basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    try {
        $tester = new InventorySystemTest();
        $results = $tester->runAllTests();
        
        exit($results !== false ? 0 : 1);
        
    } catch (Exception $e) {
        echo "テスト実行失敗: " . $e->getMessage() . "\n";
        exit(1);
    }
}
?>