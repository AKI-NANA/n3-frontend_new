<?php
/**
 * 02_scraping/scripts/inventory_report.php
 * 
 * 在庫管理レポート生成スクリプト
 * 日次・週次・月次レポートの自動生成
 */

// CLI実行のみ許可
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    exit('このスクリプトはコマンドラインからのみ実行可能です');
}

require_once __DIR__ . '/../includes/InventoryEngine.php';
require_once __DIR__ . '/../includes/InventoryLogger.php';
require_once __DIR__ . '/../includes/PriceMonitor.php';
require_once __DIR__ . '/../../shared/core/Database.php';

class InventoryReportGenerator {
    private $config;
    private $db;
    private $logger;
    private $priceMonitor;
    private $inventoryLogger;
    
    public function __construct() {
        $this->config = require __DIR__ . '/../config/inventory.php';
        $this->db = Database::getInstance();
        $this->logger = new Logger('inventory_report');
        $this->priceMonitor = new PriceMonitor($this->config);
        $this->inventoryLogger = new InventoryLogger($this->config);
    }
    
    /**
     * メインレポート生成処理
     */
    public function generateReports($reportType = 'daily', $date = null) {
        try {
            $this->logger->info("======= 在庫管理レポート生成開始 =======");
            $this->logger->info("レポートタイプ: {$reportType}");
            
            $date = $date ?: date('Y-m-d');
            $reports = [];
            
            switch ($reportType) {
                case 'daily':
                    $reports['daily'] = $this->generateDailyReport($date);
                    break;
                    
                case 'weekly':
                    $reports['weekly'] = $this->generateWeeklyReport($date);
                    break;
                    
                case 'monthly':
                    $reports['monthly'] = $this->generateMonthlyReport($date);
                    break;
                    
                case 'all':
                    $reports['daily'] = $this->generateDailyReport($date);
                    $reports['weekly'] = $this->generateWeeklyReport($date);
                    $reports['monthly'] = $this->generateMonthlyReport($date);
                    break;
                    
                default:
                    throw new Exception("不明なレポートタイプ: {$reportType}");
            }
            
            // レポート保存
            $savedReports = $this->saveReports($reports);
            
            // 10_zaikoに通知
            $this->notifyReportGeneration($savedReports);
            
            $this->logger->info("======= 在庫管理レポート生成完了 =======");
            
            return $savedReports;
            
        } catch (Exception $e) {
            $this->logger->error("レポート生成エラー: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 日次レポート生成
     */
    private function generateDailyReport($date) {
        $this->logger->info("日次レポート生成開始: {$date}");
        
        $report = [
            'report_type' => 'daily',
            'report_date' => $date,
            'generated_at' => date('Y-m-d H:i:s'),
            'sections' => []
        ];
        
        // 1. エグゼクティブサマリー
        $report['sections']['executive_summary'] = $this->generateExecutiveSummary($date);
        
        // 2. 価格変動分析
        $report['sections']['price_analysis'] = $this->generatePriceAnalysis($date);
        
        // 3. 在庫状況レポート
        $report['sections']['inventory_status'] = $this->generateInventoryStatus($date);
        
        // 4. エラー・問題レポート
        $report['sections']['error_analysis'] = $this->generateErrorAnalysis($date);
        
        // 5. パフォーマンス分析
        $report['sections']['performance_metrics'] = $this->generatePerformanceMetrics($date);
        
        // 6. 重要な商品リスト
        $report['sections']['important_products'] = $this->generateImportantProductsList($date);
        
        // 7. 推奨アクション
        $report['sections']['recommendations'] = $this->generateDailyRecommendations($date);
        
        $this->logger->info("日次レポート生成完了: {$date}");
        
        return $report;
    }
    
    /**
     * 週次レポート生成
     */
    private function generateWeeklyReport($endDate) {
        $startDate = date('Y-m-d', strtotime($endDate . ' -6 days'));
        
        $this->logger->info("週次レポート生成開始: {$startDate} - {$endDate}");
        
        $report = [
            'report_type' => 'weekly',
            'start_date' => $startDate,
            'end_date' => $endDate,
            'generated_at' => date('Y-m-d H:i:s'),
            'sections' => []
        ];
        
        // 1. 週間サマリー
        $report['sections']['weekly_summary'] = $this->generateWeeklySummary($startDate, $endDate);
        
        // 2. トレンド分析
        $report['sections']['trend_analysis'] = $this->generateTrendAnalysis($startDate, $endDate);
        
        // 3. 価格予測
        $report['sections']['price_predictions'] = $this->generatePricePredictions($startDate, $endDate);
        
        // 4. 問題商品詳細分析
        $report['sections']['problem_products'] = $this->generateProblemProductsAnalysis($startDate, $endDate);
        
        // 5. システム効率性分析
        $report['sections']['system_efficiency'] = $this->generateSystemEfficiencyAnalysis($startDate, $endDate);
        
        // 6. 戦略的推奨事項
        $report['sections']['strategic_recommendations'] = $this->generateStrategicRecommendations($startDate, $endDate);
        
        $this->logger->info("週次レポート生成完了: {$startDate} - {$endDate}");
        
        return $report;
    }
    
    /**
     * 月次レポート生成
     */
    private function generateMonthlyReport($date) {
        $year = date('Y', strtotime($date));
        $month = date('n', strtotime($date));
        $startDate = date('Y-m-01', strtotime($date));
        $endDate = date('Y-m-t', strtotime($date));
        
        $this->logger->info("月次レポート生成開始: {$year}年{$month}月");
        
        $report = [
            'report_type' => 'monthly',
            'year' => $year,
            'month' => $month,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'generated_at' => date('Y-m-d H:i:s'),
            'sections' => []
        ];
        
        // 1. 月間業績サマリー
        $report['sections']['monthly_performance'] = $this->generateMonthlyPerformance($startDate, $endDate);
        
        // 2. 市場動向分析
        $report['sections']['market_trends'] = $this->generateMarketTrends($startDate, $endDate);
        
        // 3. 収益性分析
        $report['sections']['profitability_analysis'] = $this->generateProfitabilityAnalysis($startDate, $endDate);
        
        // 4. システム改善提案
        $report['sections']['system_improvements'] = $this->generateSystemImprovements($startDate, $endDate);
        
        // 5. 次月予測
        $report['sections']['next_month_forecast'] = $this->generateNextMonthForecast($endDate);
        
        $this->logger->info("月次レポート生成完了: {$year}年{$month}月");
        
        return $report;
    }
    
    // ===============================================
    // レポートセクション生成メソッド
    // ===============================================
    
    /**
     * エグゼクティブサマリー
     */
    private function generateExecutiveSummary($date) {
        $sql = "
            SELECT 
                COUNT(DISTINCT im.product_id) as total_monitored,
                COUNT(DISTINCT CASE WHEN im.monitoring_enabled = true THEN im.product_id END) as active_monitoring,
                COUNT(DISTINCT CASE WHEN im.url_status = 'dead' THEN im.product_id END) as dead_links,
                COUNT(DISTINCT sh.product_id) as products_with_changes,
                AVG(CAST(sh.change_details->>'change_percent' AS FLOAT)) as avg_price_change
            FROM inventory_management im
            LEFT JOIN stock_history sh ON im.product_id = sh.product_id 
                AND DATE(sh.created_at) = ?
                AND sh.change_type = 'price_change'
        ";
        
        $stats = $this->db->query($sql, [$date])->fetch();
        
        // エラー統計
        $errorStats = $this->db->query("
            SELECT COUNT(*) as error_count, severity
            FROM inventory_errors 
            WHERE DATE(created_at) = ?
            GROUP BY severity
        ", [$date])->fetchAll();
        
        return [
            'monitoring_stats' => $stats,
            'error_stats' => $errorStats,
            'health_score' => $this->calculateHealthScore($date),
            'key_insights' => $this->generateKeyInsights($date)
        ];
    }
    
    /**
     * 価格変動分析
     */
    private function generatePriceAnalysis($date) {
        // 価格変動統計
        $priceStats = $this->db->query("
            SELECT 
                COUNT(*) as total_changes,
                COUNT(CASE WHEN CAST(change_details->>'change_direction' AS TEXT) = 'increase' THEN 1 END) as increases,
                COUNT(CASE WHEN CAST(change_details->>'change_direction' AS TEXT) = 'decrease' THEN 1 END) as decreases,
                AVG(CAST(change_details->>'change_percent' AS FLOAT)) as avg_change,
                MAX(CAST(change_details->>'change_percent' AS FLOAT)) as max_increase,
                MIN(CAST(change_details->>'change_percent' AS FLOAT)) as max_decrease
            FROM stock_history 
            WHERE DATE(created_at) = ?
              AND change_type = 'price_change'
        ", [$date])->fetch();
        
        // 時間帯別分析
        $hourlyAnalysis = $this->db->query("
            SELECT 
                EXTRACT(HOUR FROM created_at) as hour,
                COUNT(*) as changes,
                AVG(CAST(change_details->>'change_percent' AS FLOAT)) as avg_change
            FROM stock_history 
            WHERE DATE(created_at) = ?
              AND change_type = 'price_change'
            GROUP BY EXTRACT(HOUR FROM created_at)
            ORDER BY hour
        ", [$date])->fetchAll();
        
        // 最大変動商品
        $topChanges = $this->db->query("
            SELECT 
                p.id,
                p.title,
                sh.previous_price,
                sh.new_price,
                CAST(sh.change_details->>'change_percent' AS FLOAT) as change_percent
            FROM stock_history sh
            JOIN yahoo_scraped_products p ON sh.product_id = p.id
            WHERE DATE(sh.created_at) = ?
              AND sh.change_type = 'price_change'
            ORDER BY ABS(CAST(sh.change_details->>'change_percent' AS FLOAT)) DESC
            LIMIT 10
        ", [$date])->fetchAll();
        
        return [
            'statistics' => $priceStats,
            'hourly_analysis' => $hourlyAnalysis,
            'top_changes' => $topChanges,
            'market_sentiment' => $this->calculateMarketSentiment($priceStats)
        ];
    }
    
    /**
     * 在庫状況レポート
     */
    private function generateInventoryStatus($date) {
        // ステータス別集計
        $statusBreakdown = $this->db->query("
            SELECT 
                url_status,
                COUNT(*) as count,
                monitoring_enabled
            FROM inventory_management im
            JOIN yahoo_scraped_products p ON im.product_id = p.id
            WHERE p.workflow_status = 'listed'
            GROUP BY url_status, monitoring_enabled
        ")->fetchAll();
        
        // カテゴリ別分析
        $categoryAnalysis = $this->db->query("
            SELECT 
                p.category,
                COUNT(DISTINCT im.product_id) as monitored_count,
                COUNT(DISTINCT CASE WHEN sh.created_at >= ? THEN sh.product_id END) as changed_today
            FROM inventory_management im
            JOIN yahoo_scraped_products p ON im.product_id = p.id
            LEFT JOIN stock_history sh ON im.product_id = sh.product_id 
                AND DATE(sh.created_at) = ?
            GROUP BY p.category
            ORDER BY monitored_count DESC
        ", [$date, $date])->fetchAll();
        
        return [
            'status_breakdown' => $statusBreakdown,
            'category_analysis' => $categoryAnalysis,
            'monitoring_coverage' => $this->calculateMonitoringCoverage()
        ];
    }
    
    /**
     * エラー分析
     */
    private function generateErrorAnalysis($date) {
        // エラータイプ別統計
        $errorTypes = $this->db->query("
            SELECT 
                error_type,
                COUNT(*) as count,
                severity,
                COUNT(DISTINCT product_id) as affected_products
            FROM inventory_errors 
            WHERE DATE(created_at) = ?
            GROUP BY error_type, severity
            ORDER BY count DESC
        ", [$date])->fetchAll();
        
        // 頻繁にエラーが発生する商品
        $problematicProducts = $this->db->query("
            SELECT 
                p.id,
                p.title,
                COUNT(e.id) as error_count,
                STRING_AGG(DISTINCT e.error_type, ', ') as error_types
            FROM inventory_errors e
            JOIN yahoo_scraped_products p ON e.product_id = p.id
            WHERE DATE(e.created_at) = ?
            GROUP BY p.id, p.title
            HAVING COUNT(e.id) > 1
            ORDER BY error_count DESC
            LIMIT 10
        ", [$date])->fetchAll();
        
        return [
            'error_types' => $errorTypes,
            'problematic_products' => $problematicProducts,
            'error_rate' => $this->calculateErrorRate($date),
            'resolution_suggestions' => $this->generateErrorResolutionSuggestions($errorTypes)
        ];
    }
    
    /**
     * パフォーマンス指標
     */
    private function generatePerformanceMetrics($date) {
        // 実行統計
        $executionStats = $this->db->query("
            SELECT 
                process_type,
                COUNT(*) as executions,
                AVG(processed_products) as avg_processed,
                AVG(EXTRACT(EPOCH FROM (execution_end - execution_start))) as avg_duration,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as successful
            FROM inventory_execution_logs 
            WHERE DATE(created_at) = ?
            GROUP BY process_type
        ", [$date])->fetchAll();
        
        // システムリソース使用状況（簡易）
        $resourceUsage = [
            'database_queries' => $this->getQueryCount($date),
            'api_calls' => $this->getApiCallCount($date),
            'memory_usage' => $this->getMemoryUsage($date)
        ];
        
        return [
            'execution_stats' => $executionStats,
            'resource_usage' => $resourceUsage,
            'efficiency_score' => $this->calculateEfficiencyScore($executionStats)
        ];
    }
    
    /**
     * 重要商品リスト
     */
    private function generateImportantProductsList($date) {
        // 高ボラティリティ商品
        $volatileProducts = $this->db->query("
            SELECT 
                p.id,
                p.title,
                p.price as original_price,
                im.current_price,
                COUNT(sh.id) as price_changes,
                STDDEV(sh.new_price) as price_volatility
            FROM yahoo_scraped_products p
            JOIN inventory_management im ON p.id = im.product_id
            LEFT JOIN stock_history sh ON p.id = sh.product_id 
                AND sh.created_at >= ? - INTERVAL '7 days'
                AND sh.change_type = 'price_change'
            GROUP BY p.id, p.title, p.price, im.current_price
            HAVING COUNT(sh.id) > 2
            ORDER BY price_volatility DESC NULLS LAST
            LIMIT 10
        ", [$date])->fetchAll();
        
        // 新規監視開始商品
        $newProducts = $this->db->query("
            SELECT 
                p.id,
                p.title,
                im.created_at as monitoring_started
            FROM yahoo_scraped_products p
            JOIN inventory_management im ON p.id = im.product_id
            WHERE DATE(im.created_at) = ?
            ORDER BY im.created_at DESC
            LIMIT 10
        ", [$date])->fetchAll();
        
        return [
            'volatile_products' => $volatileProducts,
            'new_products' => $newProducts,
            'attention_required' => $this->getProductsNeedingAttention($date)
        ];
    }
    
    /**
     * 推奨アクション生成
     */
    private function generateDailyRecommendations($date) {
        $recommendations = [];
        
        // エラー率が高い場合
        $errorRate = $this->calculateErrorRate($date);
        if ($errorRate > 0.1) {
            $recommendations[] = [
                'priority' => 'high',
                'type' => 'error_mitigation',
                'message' => 'エラー率が高いです（' . round($errorRate * 100, 1) . '%）。エラーの原因調査と対策が必要です。',
                'actions' => ['error_log_analysis', 'system_health_check']
            ];
        }
        
        // デッドリンクが多い場合
        $deadLinks = $this->getDeadLinkCount();
        if ($deadLinks > 10) {
            $recommendations[] = [
                'priority' => 'medium',
                'type' => 'dead_link_cleanup',
                'message' => "デッドリンクが{$deadLinks}件検出されています。監視対象から除外を検討してください。",
                'actions' => ['dead_link_review', 'monitoring_cleanup']
            ];
        }
        
        // 価格変動が激しい場合
        $priceVolatility = $this->calculateDailyVolatility($date);
        if ($priceVolatility > 0.15) {
            $recommendations[] = [
                'priority' => 'medium',
                'type' => 'price_volatility',
                'message' => '価格変動が激しい商品が多数あります。監視間隔の調整を検討してください。',
                'actions' => ['adjust_monitoring_interval', 'volatility_analysis']
            ];
        }
        
        return $recommendations;
    }
    
    // ===============================================
    // レポート保存・通知
    // ===============================================
    
    /**
     * レポート保存
     */
    private function saveReports($reports) {
        $savedReports = [];
        $reportDir = $this->config['reporting']['daily_report']['save_path'];
        
        // ディレクトリ作成
        if (!is_dir($reportDir)) {
            mkdir($reportDir, 0755, true);
        }
        
        foreach ($reports as $type => $report) {
            $filename = $this->generateReportFilename($type, $report);
            $filePath = $reportDir . $filename;
            
            // レポート保存
            $success = file_put_contents($filePath, json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            if ($success) {
                $savedReports[] = [
                    'type' => $type,
                    'filename' => $filename,
                    'path' => $filePath,
                    'size' => filesize($filePath)
                ];
                
                $this->logger->info("レポート保存完了: {$filename}");
            } else {
                $this->logger->error("レポート保存失敗: {$filename}");
            }
        }
        
        return $savedReports;
    }
    
    /**
     * レポートファイル名生成
     */
    private function generateReportFilename($type, $report) {
        switch ($type) {
            case 'daily':
                return "daily_report_{$report['report_date']}.json";
            case 'weekly':
                return "weekly_report_{$report['start_date']}_to_{$report['end_date']}.json";
            case 'monthly':
                return "monthly_report_{$report['year']}_{$report['month']:02d}.json";
            default:
                return "report_{$type}_" . date('Y-m-d_H-i-s') . ".json";
        }
    }
    
    /**
     * 10_zaiko通知
     */
    private function notifyReportGeneration($savedReports) {
        try {
            $notificationData = [
                'event_type' => 'reports_generated',
                'generated_at' => date('Y-m-d H:i:s'),
                'reports' => $savedReports,
                'source' => '02_scraping_report'
            ];
            
            // 非同期通知
            $this->sendAsyncNotification('../10_zaiko/api/webhook.php', $notificationData);
            
        } catch (Exception $e) {
            $this->logger->warning("10_zaiko通知エラー: " . $e->getMessage());
        }
    }
    
    // ===============================================
    // ヘルパーメソッド
    // ===============================================
    
    private function calculateHealthScore($date) {
        // 簡易的なヘルススコア計算
        $errorRate = $this->calculateErrorRate($date);
        $monitoringCoverage = $this->calculateMonitoringCoverage();
        $systemUptime = 0.99; // 仮値
        
        return round((1 - $errorRate) * 0.4 + $monitoringCoverage * 0.3 + $systemUptime * 0.3, 3);
    }
    
    private function generateKeyInsights($date) {
        return [
            'market_activity' => 'high',
            'price_stability' => 'moderate',
            'system_performance' => 'good'
        ];
    }
    
    private function calculateMarketSentiment($priceStats) {
        if ($priceStats['increases'] > $priceStats['decreases']) {
            return 'bullish';
        } elseif ($priceStats['decreases'] > $priceStats['increases']) {
            return 'bearish';
        } else {
            return 'neutral';
        }
    }
    
    private function calculateMonitoringCoverage() {
        $total = $this->db->query("SELECT COUNT(*) as count FROM yahoo_scraped_products WHERE workflow_status = 'listed'")->fetch()['count'];
        $monitored = $this->db->query("SELECT COUNT(*) as count FROM inventory_management")->fetch()['count'];
        
        return $total > 0 ? $monitored / $total : 0;
    }
    
    private function calculateErrorRate($date) {
        $total = $this->db->query("SELECT COUNT(*) as count FROM inventory_execution_logs WHERE DATE(created_at) = ?", [$date])->fetch()['count'];
        $errors = $this->db->query("SELECT COUNT(*) as count FROM inventory_execution_logs WHERE DATE(created_at) = ? AND status IN ('failed', 'partial')", [$date])->fetch()['count'];
        
        return $total > 0 ? $errors / $total : 0;
    }
    
    private function getDeadLinkCount() {
        return $this->db->query("SELECT COUNT(*) as count FROM inventory_management WHERE url_status = 'dead'")->fetch()['count'];
    }
    
    private function calculateDailyVolatility($date) {
        $result = $this->db->query("
            SELECT AVG(ABS(CAST(change_details->>'change_percent' AS FLOAT))) as avg_volatility
            FROM stock_history 
            WHERE DATE(created_at) = ? AND change_type = 'price_change'
        ", [$date])->fetch();
        
        return $result['avg_volatility'] ?? 0;
    }
    
    // その他の統計メソッド（簡易実装）
    private function getQueryCount($date) { return 1500; }
    private function getApiCallCount($date) { return 200; }
    private function getMemoryUsage($date) { return '256MB'; }
    private function calculateEfficiencyScore($stats) { return 0.85; }
    private function getProductsNeedingAttention($date) { return []; }
    private function generateErrorResolutionSuggestions($errorTypes) { return []; }
    
    private function sendAsyncNotification($url, $data) {
        // 非同期通知実装
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_TIMEOUT => 2,
            CURLOPT_NOSIGNAL => true
        ]);
        curl_exec($ch);
        curl_close($ch);
    }
    
    // 週次・月次レポートの詳細実装メソッド（必要に応じて実装）
    private function generateWeeklySummary($start, $end) { return []; }
    private function generateTrendAnalysis($start, $end) { return []; }
    private function generatePricePredictions($start, $end) { return []; }
    private function generateProblemProductsAnalysis($start, $end) { return []; }
    private function generateSystemEfficiencyAnalysis($start, $end) { return []; }
    private function generateStrategicRecommendations($start, $end) { return []; }
    private function generateMonthlyPerformance($start, $end) { return []; }
    private function generateMarketTrends($start, $end) { return []; }
    private function generateProfitabilityAnalysis($start, $end) { return []; }
    private function generateSystemImprovements($start, $end) { return []; }
    private function generateNextMonthForecast($end) { return []; }
}

// コマンドライン引数解析
function parseReportArgs($argv) {
    $options = [
        'type' => 'daily',
        'date' => date('Y-m-d')
    ];
    
    for ($i = 1; $i < count($argv); $i++) {
        $arg = $argv[$i];
        
        if (strpos($arg, '--type=') === 0) {
            $options['type'] = substr($arg, 7);
        } elseif (strpos($arg, '--date=') === 0) {
            $options['date'] = substr($arg, 7);
        }
    }
    
    return $options;
}

// メイン実行
if (basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    try {
        $options = parseReportArgs($argv ?? []);
        
        $generator = new InventoryReportGenerator();
        $reports = $generator->generateReports($options['type'], $options['date']);
        
        echo "レポート生成完了: " . count($reports) . "件\n";
        
        foreach ($reports as $report) {
            echo "- {$report['type']}: {$report['filename']} (" . round($report['size']/1024, 1) . "KB)\n";
        }
        
    } catch (Exception $e) {
        echo "エラー: " . $e->getMessage() . "\n";
        exit(1);
    }
}
?>