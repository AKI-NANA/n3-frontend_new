<?php
/**
 * 02_scraping/includes/InventoryEngine.php
 * 
 * 在庫監視コアエンジン
 * 出品済み商品専用の在庫管理機能
 */

require_once __DIR__ . '/../config/inventory.php';
require_once __DIR__ . '/YahooScraper.php';
require_once __DIR__ . '/../../shared/core/Database.php';
require_once __DIR__ . '/../../shared/core/Logger.php';

class InventoryEngine {
    private $config;
    private $db;
    private $logger;
    private $yahooScraper;
    
    public function __construct() {
        $this->config = require __DIR__ . '/../config/inventory.php';
        $this->db = Database::getInstance();
        $this->logger = new Logger('inventory');
        $this->yahooScraper = new YahooScraper();
    }
    
    /**
     * 出品済み商品を在庫管理に登録
     * 08_listingから呼び出される
     */
    public function registerListedProduct($productId, $options = []) {
        try {
            $this->logger->info("出品商品の在庫管理登録開始: ID {$productId}");
            
            // 出品済み商品情報取得
            $product = $this->getListedProduct($productId);
            if (!$product) {
                throw new Exception("出品済み商品が見つかりません: ID {$productId}");
            }
            
            // 既存登録チェック
            if ($this->isAlreadyRegistered($productId)) {
                $this->logger->warning("商品は既に在庫管理に登録済み: ID {$productId}");
                return ['success' => true, 'message' => '既に登録済み'];
            }
            
            // 在庫管理テーブルに登録
            $inventoryData = [
                'product_id' => $productId,
                'source_platform' => 'yahoo',
                'source_url' => $product['url'],
                'source_product_id' => $this->extractAuctionId($product['url']),
                'current_price' => $product['price'],
                'title_hash' => hash('sha256', $product['title']),
                'url_status' => 'active',
                'monitoring_enabled' => true,
                'check_interval_hours' => $this->config['monitoring']['default_check_interval_hours'],
                'price_alert_threshold' => $this->config['monitoring']['price_change_threshold'],
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $this->db->insert('inventory_management', $inventoryData);
            
            // 出品先情報登録
            if (!empty($product['ebay_item_id'])) {
                $this->registerListingPlatform($productId, [
                    'platform' => 'ebay',
                    'platform_product_id' => $product['ebay_item_id'],
                    'listing_url' => $this->generateEbayUrl($product['ebay_item_id']),
                    'listed_price' => $product['price']
                ]);
            }
            
            // 初期在庫チェック実行
            $this->checkSingleProduct($productId);
            
            $this->logger->success("出品商品の在庫管理登録完了: ID {$productId}");
            
            return [
                'success' => true,
                'message' => '在庫管理登録完了',
                'product_id' => $productId,
                'monitoring_enabled' => true
            ];
            
        } catch (Exception $e) {
            $this->logger->error("在庫管理登録エラー: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 在庫チェック実行（定期監視用）
     */
    public function performInventoryCheck($productIds = null) {
        $executionId = uniqid('inv_check_');
        
        try {
            $this->startExecutionLog($executionId, 'stock_check');
            $this->logger->info("在庫チェック開始: {$executionId}");
            
            // 監視対象商品取得
            $targets = $this->getMonitoringTargets($productIds);
            $results = [
                'total' => count($targets),
                'processed' => 0,
                'updated' => 0,
                'errors' => 0,
                'changes' => []
            ];
            
            foreach ($targets as $target) {
                try {
                    $checkResult = $this->checkSingleProduct($target['product_id']);
                    $results['processed']++;
                    
                    if ($checkResult['has_changes']) {
                        $results['updated']++;
                        $results['changes'][] = [
                            'product_id' => $target['product_id'],
                            'title' => $target['title'],
                            'changes' => $checkResult['changes']
                        ];
                    }
                    
                    // レート制限対策
                    sleep($this->config['batch_processing']['batch_delay_seconds']);
                    
                } catch (Exception $e) {
                    $results['errors']++;
                    $this->logger->error("商品チェックエラー: ID {$target['product_id']} - " . $e->getMessage());
                    
                    // エラーログに記録
                    $this->logError($executionId, $target['product_id'], 'check_failed', $e->getMessage());
                }
                
                // バッチサイズ制御
                if ($results['processed'] % $this->config['batch_processing']['batch_size'] === 0) {
                    $this->logger->info("バッチ処理進捗: {$results['processed']}/{$results['total']}");
                }
            }
            
            $this->completeExecutionLog($executionId, $results);
            $this->logger->info("在庫チェック完了: {$executionId} - {$results['processed']}件処理、{$results['updated']}件更新");
            
            return $results;
            
        } catch (Exception $e) {
            $this->failExecutionLog($executionId, $e->getMessage());
            $this->logger->error("在庫チェック失敗: {$executionId} - " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 単一商品の在庫チェック
     */
    public function checkSingleProduct($productId) {
        try {
            // 在庫管理情報取得
            $inventoryInfo = $this->getInventoryInfo($productId);
            if (!$inventoryInfo) {
                throw new Exception("在庫管理情報が見つかりません: ID {$productId}");
            }
            
            // Yahoo Auctionから最新データ取得
            $latestData = $this->yahooScraper->scrapeProductData($inventoryInfo['source_url']);
            $changes = [];
            $hasChanges = false;
            
            // 価格変動チェック
            if (isset($latestData['price']) && $latestData['price'] > 0) {
                $priceChange = $this->detectPriceChange($inventoryInfo['current_price'], $latestData['price']);
                if ($priceChange['changed']) {
                    $changes[] = $priceChange;
                    $hasChanges = true;
                    
                    // 価格履歴記録
                    $this->recordPriceChange($productId, $priceChange);
                    
                    // 在庫管理テーブル更新
                    $this->updateInventoryInfo($productId, ['current_price' => $latestData['price']]);
                }
            }
            
            // 在庫状況チェック
            $stockStatus = $this->determineStockStatus($latestData);
            if ($stockStatus !== 'in_stock') {
                $stockChange = [
                    'type' => 'stock_change',
                    'old_status' => 'in_stock',
                    'new_status' => $stockStatus,
                    'detected_at' => date('Y-m-d H:i:s')
                ];
                $changes[] = $stockChange;
                $hasChanges = true;
                
                // URL状態更新
                $urlStatus = ($stockStatus === 'dead_link') ? 'dead' : 'changed';
                $this->updateInventoryInfo($productId, ['url_status' => $urlStatus]);
            }
            
            // 最終確認時刻更新
            $this->updateInventoryInfo($productId, ['last_verified_at' => date('Y-m-d H:i:s')]);
            
            return [
                'success' => true,
                'product_id' => $productId,
                'has_changes' => $hasChanges,
                'changes' => $changes,
                'latest_data' => $latestData,
                'checked_at' => date('Y-m-d H:i:s')
            ];
            
        } catch (Exception $e) {
            $this->logger->error("単一商品チェックエラー: ID {$productId} - " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 監視開始
     */
    public function startMonitoring($productIds) {
        try {
            $updated = 0;
            foreach ($productIds as $productId) {
                $result = $this->updateInventoryInfo($productId, ['monitoring_enabled' => true]);
                if ($result) $updated++;
            }
            
            $this->logger->info("監視開始: {$updated}件の商品で監視を有効化");
            
            return [
                'success' => true,
                'message' => "{$updated}件の商品で監視を開始しました",
                'updated_count' => $updated
            ];
            
        } catch (Exception $e) {
            $this->logger->error("監視開始エラー: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 監視停止
     */
    public function stopMonitoring($productIds) {
        try {
            $updated = 0;
            foreach ($productIds as $productId) {
                $result = $this->updateInventoryInfo($productId, ['monitoring_enabled' => false]);
                if ($result) $updated++;
            }
            
            $this->logger->info("監視停止: {$updated}件の商品で監視を無効化");
            
            return [
                'success' => true,
                'message' => "{$updated}件の商品で監視を停止しました",
                'updated_count' => $updated
            ];
            
        } catch (Exception $e) {
            $this->logger->error("監視停止エラー: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 価格履歴取得
     */
    public function getPriceHistory($productId, $days = 30) {
        try {
            $sql = "
                SELECT 
                    previous_price,
                    new_price,
                    change_type,
                    created_at
                FROM stock_history 
                WHERE product_id = ? 
                  AND change_type IN ('price_change', 'both')
                  AND created_at >= NOW() - INTERVAL '{$days} days'
                ORDER BY created_at DESC
                LIMIT 100
            ";
            
            return $this->db->query($sql, [$productId])->fetchAll();
            
        } catch (Exception $e) {
            $this->logger->error("価格履歴取得エラー: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 監視ステータス取得
     */
    public function getMonitoringStatus($productIds = null) {
        try {
            $sql = "
                SELECT 
                    im.product_id,
                    im.monitoring_enabled,
                    im.url_status,
                    im.last_verified_at,
                    im.current_price,
                    ysp.title,
                    ysp.ebay_item_id,
                    lp.listing_status
                FROM inventory_management im
                JOIN yahoo_scraped_products ysp ON im.product_id = ysp.id
                LEFT JOIN listing_platforms lp ON im.product_id = lp.product_id AND lp.platform = 'ebay'
                WHERE ysp.workflow_status = 'listed'
                  AND ysp.ebay_item_id IS NOT NULL
            ";
            
            $params = [];
            if ($productIds) {
                $placeholders = str_repeat('?,', count($productIds) - 1) . '?';
                $sql .= " AND im.product_id IN ({$placeholders})";
                $params = $productIds;
            }
            
            $sql .= " ORDER BY im.updated_at DESC";
            
            return $this->db->query($sql, $params)->fetchAll();
            
        } catch (Exception $e) {
            $this->logger->error("監視ステータス取得エラー: " . $e->getMessage());
            throw $e;
        }
    }
    
    // ===============================================
    // プライベートヘルパーメソッド
    // ===============================================
    
    /**
     * 出品済み商品情報取得
     */
    private function getListedProduct($productId) {
        $sql = "
            SELECT id, title, price, url, ebay_item_id, created_at, updated_at
            FROM yahoo_scraped_products 
            WHERE id = ? 
              AND workflow_status = 'listed' 
              AND ebay_item_id IS NOT NULL
        ";
        
        return $this->db->query($sql, [$productId])->fetch() ?: null;
    }
    
    /**
     * 在庫管理情報取得
     */
    private function getInventoryInfo($productId) {
        $sql = "SELECT * FROM inventory_management WHERE product_id = ?";
        return $this->db->query($sql, [$productId])->fetch() ?: null;
    }
    
    /**
     * 在庫管理情報更新
     */
    private function updateInventoryInfo($productId, $data) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $this->db->update('inventory_management', $data, ['product_id' => $productId]);
    }
    
    /**
     * 出品先プラットフォーム登録
     */
    private function registerListingPlatform($productId, $platformData) {
        $data = array_merge([
            'product_id' => $productId,
            'created_at' => date('Y-m-d H:i:s')
        ], $platformData);
        
        return $this->db->insert('listing_platforms', $data);
    }
    
    /**
     * 価格変動検知
     */
    private function detectPriceChange($oldPrice, $newPrice) {
        $changeAmount = $newPrice - $oldPrice;
        $changePercent = $oldPrice > 0 ? ($changeAmount / $oldPrice) : 0;
        $threshold = $this->config['monitoring']['price_change_threshold'];
        
        return [
            'type' => 'price_change',
            'changed' => abs($changePercent) >= $threshold,
            'old_price' => $oldPrice,
            'new_price' => $newPrice,
            'change_amount' => $changeAmount,
            'change_percent' => $changePercent,
            'detected_at' => date('Y-m-d H:i:s')
        ];
    }
    
    /**
     * 監視対象商品一覧取得
     */
    private function getMonitoringTargets($productIds = null) {
        $sql = "
            SELECT 
                im.product_id,
                im.source_url,
                im.current_price,
                im.url_status,
                im.last_verified_at,
                ysp.title,
                ysp.ebay_item_id
            FROM inventory_management im
            JOIN yahoo_scraped_products ysp ON im.product_id = ysp.id
            WHERE im.monitoring_enabled = true
              AND ysp.workflow_status = 'listed'
              AND ysp.ebay_item_id IS NOT NULL
              AND im.url_status = 'active'
        ";
        
        $params = [];
        if ($productIds) {
            $placeholders = str_repeat('?,', count($productIds) - 1) . '?';
            $sql .= " AND im.product_id IN ({$placeholders})";
            $params = $productIds;
        }
        
        $sql .= " ORDER BY im.last_verified_at ASC NULLS FIRST";
        
        return $this->db->query($sql, $params)->fetchAll();
    }
    
    /**
     * 価格変動履歴記録
     */
    private function recordPriceChange($productId, $change) {
        $this->db->insert('stock_history', [
            'product_id' => $productId,
            'previous_price' => $change['old_price'],
            'new_price' => $change['new_price'],
            'change_type' => 'price_change',
            'change_source' => 'yahoo',
            'change_details' => json_encode($change),
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Yahoo AuctionオークションID抽出
     */
    private function extractAuctionId($url) {
        preg_match('/auction\/([a-zA-Z0-9]+)/', $url, $matches);
        return $matches[1] ?? null;
    }
    
    /**
     * eBay URL生成
     */
    private function generateEbayUrl($itemId) {
        return "https://www.ebay.com/itm/{$itemId}";
    }
    
    /**
     * 既存登録チェック
     */
    private function isAlreadyRegistered($productId) {
        $existing = $this->db->query('SELECT id FROM inventory_management WHERE product_id = ?', [$productId])->fetch();
        return !empty($existing);
    }
    
    /**
     * 在庫状況判定
     */
    private function determineStockStatus($latestData) {
        if (!$latestData || !isset($latestData['accessible'])) return 'unknown';
        if (!$latestData['accessible']) return 'dead_link';
        if (isset($latestData['ended']) && $latestData['ended']) return 'auction_ended';
        if (isset($latestData['available']) && $latestData['available']) return 'in_stock';
        return 'unknown';
    }
    
    /**
     * 実行ログ開始
     */
    private function startExecutionLog($executionId, $processType) {
        $this->db->insert('inventory_execution_logs', [
            'execution_id' => $executionId,
            'process_type' => $processType,
            'status' => 'running',
            'execution_start' => date('Y-m-d H:i:s'),
            'worker_id' => gethostname() . ':' . getmypid()
        ]);
    }
    
    /**
     * 実行ログ完了
     */
    private function completeExecutionLog($executionId, $results) {
        $this->db->update('inventory_execution_logs', [
            'status' => 'completed',
            'execution_end' => date('Y-m-d H:i:s'),
            'total_products' => $results['total'],
            'processed_products' => $results['processed'],
            'updated_products' => $results['updated'],
            'error_products' => $results['errors'],
            'details' => json_encode($results)
        ], ['execution_id' => $executionId]);
    }
    
    /**
     * 実行ログ失敗
     */
    private function failExecutionLog($executionId, $errorMessage) {
        $this->db->update('inventory_execution_logs', [
            'status' => 'failed',
            'execution_end' => date('Y-m-d H:i:s'),
            'error_message' => $errorMessage
        ], ['execution_id' => $executionId]);
    }
    
    /**
     * エラーログ記録
     */
    private function logError($executionId, $productId, $errorType, $errorMessage) {
        $this->db->insert('inventory_errors', [
            'execution_id' => $executionId,
            'product_id' => $productId,
            'error_type' => $errorType,
            'error_message' => $errorMessage,
            'severity' => 'medium',
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
}
?>