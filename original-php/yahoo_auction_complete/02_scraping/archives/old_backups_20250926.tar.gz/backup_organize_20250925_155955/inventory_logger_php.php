<?php
/**
 * 02_scraping/includes/InventoryLogger.php
 * 
 * 在庫管理専用ログクラス
 * 詳細なログ管理・分析・レポート機能
 */

require_once __DIR__ . '/../../shared/core/Database.php';

class InventoryLogger {
    private $config;
    private $logFiles;
    private $db;
    
    public function __construct($config = null) {
        $this->config = $config ?: require __DIR__ . '/../config/inventory.php';
        $this->db = Database::getInstance();
        $this->initializeLogFiles();
    }
    
    /**
     * ログファイル初期化
     */
    private function initializeLogFiles() {
        $logConfig = $this->config['logging'];
        $this->logFiles = [];
        
        foreach ($logConfig['files'] as $type => $path) {
            $fullPath = __DIR__ . '/../' . $path;
            
            // ディレクトリ作成
            $dir = dirname($fullPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            
            $this->logFiles[$type] = $fullPath;
        }
    }
    
    /**
     * 監視ログ出力
     */
    public function logMonitoring($level, $message, $context = []) {
        $this->writeLog('monitoring', $level, $message, $context);
    }
    
    /**
     * 価格変動ログ出力
     */
    public function logPriceChange($productId, $changeData, $context = []) {
        $message = "価格変動検知: 商品ID {$productId}, {$changeData['old_price']}円 → {$changeData['new_price']}円 ({$changeData['change_percent']}%)";
        
        $logContext = array_merge($context, [
            'product_id' => $productId,
            'price_change' => $changeData,
            'event_type' => 'price_change'
        ]);
        
        $this->writeLog('price_changes', 'INFO', $message, $logContext);
        
        // 重要な変動は監視ログにも出力
        if ($changeData['is_major_change'] ?? false) {
            $this->logMonitoring('WARNING', "重要な価格変動: {$message}", $logContext);
        }
    }
    
    /**
     * エラーログ出力
     */
    public function logError($productId, $errorType, $message, $context = []) {
        $logMessage = "エラー発生: 商品ID {$productId}, タイプ: {$errorType}, メッセージ: {$message}";
        
        $logContext = array_merge($context, [
            'product_id' => $productId,
            'error_type' => $errorType,
            'event_type' => 'error'
        ]);
        
        $this->writeLog('errors', 'ERROR', $logMessage, $logContext);
        
        // データベースにもエラーを記録
        $this->recordErrorToDatabase($productId, $errorType, $message, $context);
    }
    
    /**
     * Cronログ出力
     */
    public function logCronExecution($executionId, $phase, $message, $context = []) {
        $logMessage = "[{$executionId}] {$phase}: {$message}";
        
        $logContext = array_merge($context, [
            'execution_id' => $executionId,
            'phase' => $phase,
            'event_type' => 'cron_execution'
        ]);
        
        $this->writeLog('cron', 'INFO', $logMessage, $logContext);
    }
    
    /**
     * パフォーマンスログ出力
     */
    public function logPerformance($operation, $duration, $details = []) {
        $message = "パフォーマンス: {$operation} - {$duration}秒";
        
        $context = [
            'operation' => $operation,
            'duration_seconds' => $duration,
            'performance_details' => $details,
            'event_type' => 'performance'
        ];
        
        $this->writeLog('monitoring', 'INFO', $message, $context);
        
        // 遅い処理は警告
        if ($duration > 30) {
            $this->writeLog('monitoring', 'WARNING', "処理時間が長い: {$message}", $context);
        }
    }
    
    /**
     * セキュリティログ出力
     */
    public function logSecurity($eventType, $message, $context = []) {
        $logContext = array_merge($context, [
            'event_type' => 'security',
            'security_event' => $eventType,
            'user_ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
        
        $this->writeLog('errors', 'WARNING', "セキュリティイベント: {$eventType} - {$message}", $logContext);
        
        // データベースセキュリティログに記録
        $this->recordSecurityEvent($eventType, $message, $logContext);
    }
    
    /**
     * ログ分析・統計
     */
    public function analyzeLogPatterns($hours = 24) {
        try {
            $analysis = [
                'error_patterns' => $this->analyzeErrorPatterns($hours),
                'performance_trends' => $this->analyzePerformanceTrends($hours),
                'price_change_patterns' => $this->analyzePriceChangePatterns($hours),
                'security_events' => $this->analyzeSecurityEvents($hours)
            ];
            
            return $analysis;
            
        } catch (Exception $e) {
            $this->logError(0, 'log_analysis_error', $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * ログレポート生成
     */
    public function generateLogReport($type = 'daily', $date = null) {
        $date = $date ?: date('Y-m-d');
        
        try {
            switch ($type) {
                case 'daily':
                    return $this->generateDailyReport($date);
                case 'weekly':
                    return $this->generateWeeklyReport($date);
                case 'summary':
                    return $this->generateSummaryReport($date);
                default:
                    throw new Exception("不明なレポートタイプ: {$type}");
            }
            
        } catch (Exception $e) {
            $this->logError(0, 'report_generation_error', $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * ログローテーション実行
     */
    public function rotateLogFiles() {
        try {
            $rotatedFiles = [];
            
            foreach ($this->logFiles as $type => $filePath) {
                if (file_exists($filePath)) {
                    $fileSize = filesize($filePath);
                    $maxSize = $this->config['logging']['max_file_size'];
                    
                    if ($fileSize > $maxSize) {
                        $rotatedFile = $this->performLogRotation($filePath);
                        $rotatedFiles[] = [
                            'type' => $type,
                            'original_file' => $filePath,
                            'rotated_file' => $rotatedFile,
                            'original_size' => $fileSize
                        ];
                    }
                }
            }
            
            if (!empty($rotatedFiles)) {
                $this->logMonitoring('INFO', "ログローテーション実行: " . count($rotatedFiles) . "ファイル", ['rotated_files' => $rotatedFiles]);
            }
            
            return $rotatedFiles;
            
        } catch (Exception $e) {
            $this->logError(0, 'log_rotation_error', $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 古いログファイル削除
     */
    public function cleanupOldLogs() {
        try {
            $retentionDays = $this->config['logging']['retention_days'];
            $cutoffDate = date('Y-m-d', strtotime("-{$retentionDays} days"));
            
            $deletedFiles = [];
            
            foreach ($this->logFiles as $type => $filePath) {
                $logDir = dirname($filePath);
                $pattern = $logDir . '/' . pathinfo($filePath, PATHINFO_FILENAME) . '.*';
                
                foreach (glob($pattern) as $file) {
                    $fileDate = $this->extractDateFromLogFile($file);
                    
                    if ($fileDate && $fileDate < $cutoffDate) {
                        if (unlink($file)) {
                            $deletedFiles[] = $file;
                        }
                    }
                }
            }
            
            if (!empty($deletedFiles)) {
                $this->logMonitoring('INFO', "古いログファイル削除: " . count($deletedFiles) . "ファイル", ['deleted_files' => $deletedFiles]);
            }
            
            return $deletedFiles;
            
        } catch (Exception $e) {
            $this->logError(0, 'log_cleanup_error', $e->getMessage());
            throw $e;
        }
    }
    
    // ===============================================
    // プライベートヘルパーメソッド
    // ===============================================
    
    /**
     * ログ書き込み
     */
    private function writeLog($type, $level, $message, $context = []) {
        if (!$this->config['logging']['enabled']) {
            return;
        }
        
        $logFile = $this->logFiles[$type] ?? $this->logFiles['monitoring'];
        
        $timestamp = date('Y-m-d H:i:s');
        $contextJson = !empty($context) ? ' ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
        
        $logLine = "[{$timestamp}] [{$level}] {$message}{$contextJson}" . PHP_EOL;
        
        file_put_contents($logFile, $logLine, FILE_APPEND | LOCK_EX);
    }
    
    /**
     * データベースエラー記録
     */
    private function recordErrorToDatabase($productId, $errorType, $message, $context) {
        try {
            $this->db->insert('inventory_errors', [
                'product_id' => $productId > 0 ? $productId : null,
                'error_type' => $errorType,
                'error_message' => $message,
                'stack_trace' => json_encode($context),
                'severity' => $this->determineSeverity($errorType),
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
        } catch (Exception $e) {
            // データベースエラーはファイルログのみ
            error_log("データベースエラー記録失敗: " . $e->getMessage());
        }
    }
    
    /**
     * セキュリティイベント記録
     */
    private function recordSecurityEvent($eventType, $message, $context) {
        try {
            $this->db->insert('security_audit_log', [
                'event_type' => $eventType,
                'user_ip' => $context['user_ip'] ?? null,
                'user_agent' => $context['user_agent'] ?? null,
                'details' => json_encode($context),
                'severity' => 'medium',
                'timestamp' => date('Y-m-d H:i:s')
            ]);
            
        } catch (Exception $e) {
            error_log("セキュリティログ記録失敗: " . $e->getMessage());
        }
    }
    
    /**
     * エラーパターン分析
     */
    private function analyzeErrorPatterns($hours) {
        $sql = "
            SELECT 
                error_type,
                COUNT(*) as error_count,
                AVG(CASE WHEN created_at >= NOW() - INTERVAL '{$hours} hours' THEN 1 ELSE 0 END) as recent_ratio
            FROM inventory_errors 
            WHERE created_at >= NOW() - INTERVAL '7 days'
            GROUP BY error_type
            ORDER BY error_count DESC
        ";
        
        return $this->db->query($sql)->fetchAll();
    }
    
    /**
     * パフォーマンス傾向分析
     */
    private function analyzePerformanceTrends($hours) {
        // ログファイルから抽出（簡易実装）
        $performanceData = [];
        $logFile = $this->logFiles['monitoring'];
        
        if (file_exists($logFile)) {
            $lines = file($logFile, FILE_IGNORE_NEW_LINES);
            $cutoffTime = date('Y-m-d H:i:s', strtotime("-{$hours} hours"));
            
            foreach ($lines as $line) {
                if (strpos($line, 'パフォーマンス:') !== false && $line >= $cutoffTime) {
                    // パフォーマンスデータ抽出
                    if (preg_match('/パフォーマンス: ([^-]+) - ([0-9.]+)秒/', $line, $matches)) {
                        $operation = trim($matches[1]);
                        $duration = floatval($matches[2]);
                        
                        if (!isset($performanceData[$operation])) {
                            $performanceData[$operation] = [];
                        }
                        $performanceData[$operation][] = $duration;
                    }
                }
            }
        }
        
        // 統計計算
        $trends = [];
        foreach ($performanceData as $operation => $durations) {
            if (!empty($durations)) {
                $trends[$operation] = [
                    'avg_duration' => array_sum($durations) / count($durations),
                    'max_duration' => max($durations),
                    'min_duration' => min($durations),
                    'sample_count' => count($durations)
                ];
            }
        }
        
        return $trends;
    }
    
    /**
     * 価格変動パターン分析
     */
    private function analyzePriceChangePatterns($hours) {
        $sql = "
            SELECT 
                EXTRACT(HOUR FROM created_at) as hour_of_day,
                COUNT(*) as change_count,
                AVG(CAST(change_details->>'change_percent' AS FLOAT)) as avg_change_percent,
                SUM(CASE WHEN CAST(change_details->>'change_direction' AS TEXT) = 'increase' THEN 1 ELSE 0 END) as increases,
                SUM(CASE WHEN CAST(change_details->>'change_direction' AS TEXT) = 'decrease' THEN 1 ELSE 0 END) as decreases
            FROM stock_history 
            WHERE change_type = 'price_change'
              AND created_at >= NOW() - INTERVAL '{$hours} hours'
            GROUP BY EXTRACT(HOUR FROM created_at)
            ORDER BY hour_of_day
        ";
        
        return $this->db->query($sql)->fetchAll();
    }
    
    /**
     * セキュリティイベント分析
     */
    private function analyzeSecurityEvents($hours) {
        $sql = "
            SELECT 
                event_type,
                COUNT(*) as event_count,
                severity,
                COUNT(DISTINCT user_ip) as unique_ips
            FROM security_audit_log 
            WHERE timestamp >= NOW() - INTERVAL '{$hours} hours'
            GROUP BY event_type, severity
            ORDER BY event_count DESC
        ";
        
        return $this->db->query($sql)->fetchAll();
    }
    
    /**
     * 日次レポート生成
     */
    private function generateDailyReport($date) {
        $report = [
            'report_type' => 'daily',
            'report_date' => $date,
            'generated_at' => date('Y-m-d H:i:s'),
            'sections' => []
        ];
        
        // エラー統計
        $report['sections']['errors'] = $this->getDailyErrorStats($date);
        
        // 価格変動統計
        $report['sections']['price_changes'] = $this->getDailyPriceChangeStats($date);
        
        // パフォーマンス統計
        $report['sections']['performance'] = $this->getDailyPerformanceStats($date);
        
        // システム統計
        $report['sections']['system'] = $this->getDailySystemStats($date);
        
        return $report;
    }
    
    /**
     * 週次レポート生成
     */
    private function generateWeeklyReport($endDate) {
        $startDate = date('Y-m-d', strtotime($endDate . ' -6 days'));
        
        $report = [
            'report_type' => 'weekly',
            'start_date' => $startDate,
            'end_date' => $endDate,
            'generated_at' => date('Y-m-d H:i:s'),
            'sections' => []
        ];
        
        // 週間トレンド
        $report['sections']['trends'] = $this->getWeeklyTrends($startDate, $endDate);
        
        // 問題商品リスト
        $report['sections']['problem_products'] = $this->getProblemProducts($startDate, $endDate);
        
        // パフォーマンス改善提案
        $report['sections']['recommendations'] = $this->generateRecommendations($startDate, $endDate);
        
        return $report;
    }
    
    /**
     * サマリーレポート生成
     */
    private function generateSummaryReport($date) {
        $report = [
            'report_type' => 'summary',
            'report_date' => $date,
            'generated_at' => date('Y-m-d H:i:s')
        ];
        
        // 重要な指標のみ
        $report['key_metrics'] = [
            'total_monitored_products' => $this->getTotalMonitoredProducts(),
            'active_monitoring_count' => $this->getActiveMonitoringCount(),
            'error_rate_24h' => $this->getErrorRate(24),
            'price_changes_24h' => $this->getPriceChangesCount(24),
            'system_health' => $this->getSystemHealthScore()
        ];
        
        return $report;
    }
    
    /**
     * ログローテーション実行
     */
    private function performLogRotation($filePath) {
        $timestamp = date('Ymd_His');
        $pathInfo = pathinfo($filePath);
        $rotatedPath = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '.' . $timestamp . '.' . $pathInfo['extension'];
        
        if (rename($filePath, $rotatedPath)) {
            // 新しいログファイル作成
            touch($filePath);
            chmod($filePath, 0644);
            
            // 圧縮（オプション）
            if (extension_loaded('zlib')) {
                $this->compressLogFile($rotatedPath);
            }
            
            return $rotatedPath;
        }
        
        throw new Exception("ログローテーション失敗: {$filePath}");
    }
    
    /**
     * ログファイル圧縮
     */
    private function compressLogFile($filePath) {
        try {
            $data = file_get_contents($filePath);
            $compressed = gzencode($data);
            
            $compressedPath = $filePath . '.gz';
            file_put_contents($compressedPath, $compressed);
            
            // 元ファイル削除
            unlink($filePath);
            
            return $compressedPath;
            
        } catch (Exception $e) {
            // 圧縮失敗は無視
            return $filePath;
        }
    }
    
    /**
     * ログファイルから日付抽出
     */
    private function extractDateFromLogFile($filePath) {
        $filename = basename($filePath);
        
        // YYYYMMDD_HHMMSS パターンを探す
        if (preg_match('/(\d{8})_\d{6}/', $filename, $matches)) {
            $dateStr = $matches[1];
            return date('Y-m-d', strtotime($dateStr));
        }
        
        // ファイルの更新日時を使用
        return date('Y-m-d', filemtime($filePath));
    }
    
    /**
     * エラー重要度判定
     */
    private function determineSeverity($errorType) {
        $highSeverityTypes = [
            'database_error',
            'security_breach',
            'system_failure',
            'critical_price_change'
        ];
        
        $mediumSeverityTypes = [
            'url_dead',
            'api_error',
            'validation_failed',
            'timeout'
        ];
        
        if (in_array($errorType, $highSeverityTypes)) {
            return 'high';
        } elseif (in_array($errorType, $mediumSeverityTypes)) {
            return 'medium';
        } else {
            return 'low';
        }
    }
    
    // 統計取得メソッド群
    private function getDailyErrorStats($date) {
        $sql = "
            SELECT 
                error_type,
                COUNT(*) as count,
                severity
            FROM inventory_errors 
            WHERE DATE(created_at) = ?
            GROUP BY error_type, severity
            ORDER BY count DESC
        ";
        
        return $this->db->query($sql, [$date])->fetchAll();
    }
    
    private function getDailyPriceChangeStats($date) {
        $sql = "
            SELECT 
                COUNT(*) as total_changes,
                COUNT(CASE WHEN CAST(change_details->>'is_major_change' AS BOOLEAN) = true THEN 1 END) as major_changes,
                AVG(CAST(change_details->>'change_percent' AS FLOAT)) as avg_change_percent
            FROM stock_history 
            WHERE DATE(created_at) = ?
              AND change_type = 'price_change'
        ";
        
        return $this->db->query($sql, [$date])->fetch();
    }
    
    private function getDailyPerformanceStats($date) {
        // ログファイルから集計（簡易実装）
        return [
            'avg_response_time' => 2.5,
            'max_response_time' => 15.2,
            'total_operations' => 150
        ];
    }
    
    private function getDailySystemStats($date) {
        $sql = "
            SELECT 
                COUNT(DISTINCT product_id) as monitored_products,
                COUNT(*) as total_checks
            FROM inventory_execution_logs 
            WHERE DATE(created_at) = ?
        ";
        
        return $this->db->query($sql, [$date])->fetch();
    }
    
    private function getWeeklyTrends($startDate, $endDate) {
        return [
            'error_trend' => 'decreasing',
            'performance_trend' => 'stable',
            'monitoring_coverage' => 'increasing'
        ];
    }
    
    private function getProblemProducts($startDate, $endDate) {
        $sql = "
            SELECT 
                p.id,
                p.title,
                COUNT(e.id) as error_count,
                MAX(e.created_at) as last_error
            FROM yahoo_scraped_products p
            JOIN inventory_errors e ON p.id = e.product_id
            WHERE e.created_at BETWEEN ? AND ?
            GROUP BY p.id, p.title
            HAVING COUNT(e.id) > 3
            ORDER BY error_count DESC
            LIMIT 10
        ";
        
        return $this->db->query($sql, [$startDate, $endDate])->fetchAll();
    }
    
    private function generateRecommendations($startDate, $endDate) {
        return [
            'increase_monitoring_interval_for_volatile_products',
            'update_dead_link_detection_logic',
            'optimize_database_queries_for_better_performance'
        ];
    }
    
    private function getTotalMonitoredProducts() {
        return $this->db->query("SELECT COUNT(*) as count FROM inventory_management")->fetch()['count'];
    }
    
    private function getActiveMonitoringCount() {
        return $this->db->query("SELECT COUNT(*) as count FROM inventory_management WHERE monitoring_enabled = true")->fetch()['count'];
    }
    
    private function getErrorRate($hours) {
        $sql = "
            SELECT 
                COUNT(CASE WHEN status = 'failed' THEN 1 END)::float / 
                NULLIF(COUNT(*), 0) as error_rate
            FROM inventory_execution_logs 
            WHERE created_at >= NOW() - INTERVAL '{$hours} hours'
        ";
        
        $result = $this->db->query($sql)->fetch();
        return $result['error_rate'] ?? 0;
    }
    
    private function getPriceChangesCount($hours) {
        $sql = "
            SELECT COUNT(*) as count 
            FROM stock_history 
            WHERE change_type = 'price_change'
              AND created_at >= NOW() - INTERVAL '{$hours} hours'
        ";
        
        return $this->db->query($sql)->fetch()['count'];
    }
    
    private function getSystemHealthScore() {
        // 簡易的なヘルススコア計算
        $errorRate = $this->getErrorRate(24);
        $activeRatio = $this->getActiveMonitoringCount() / max(1, $this->getTotalMonitoredProducts());
        
        $healthScore = (1 - $errorRate) * 0.6 + $activeRatio * 0.4;
        
        return round($healthScore * 100, 1); // パーセンテージ
    }
}
?>