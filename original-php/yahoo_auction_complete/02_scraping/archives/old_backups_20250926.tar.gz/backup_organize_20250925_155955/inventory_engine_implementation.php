<?php
/**
 * 02_scraping/includes/InventoryEngine.php
 * 
 * 出品済み商品専用在庫監視エンジン
 * 08_listing出品完了商品のみを監視対象とする
 */

require_once __DIR__ . '/YahooScraper.php';
require_once __DIR__ . '/../../shared/core/Database.php';
require_once __DIR__ . '/InventoryLogger.php';

class InventoryEngine {
    private $yahooscraper;
    private $db;
    private $logger;
    private $config;
    
    public function __construct() {
        $this->yahooscraper = new YahooScraper();
        $this->db = Database::getInstance();
        $this->logger = new InventoryLogger();
        $this->config = require __DIR__ . '/../config/inventory.php';
    }
    
    /**
     * 出品済み商品を在庫管理に自動登録
     * 08_listing出品完了時に呼び出される
     */
    public function registerListedProduct($productId) {
        try {
            // 出品済み商品データ取得
            $product = $this->getListedProduct($productId);
            
            if (!$product) {
                throw new Exception("商品ID {$productId} は出品済み商品ではありません");
            }
            
            // 既存チェック
            if ($this->isAlreadyRegistered($productId)) {
                $this->logger->info("商品ID {$productId} は既に在庫管理登録済み");
                return false;
            }
            
            // inventory_managementテーブルに登録
            $inventoryData = [
                'product_id' => $productId,
                'source_platform' => 'yahoo',
                'source_url' => $product['url'],
                'source_product_id' => $this->extractAuctionId($product['url']),
                'current_stock' => 1, // 出品済み = 在庫あり状態
                'current_price' => $product['price'],
                'title_hash' => hash('sha256', $product['title']),
                'url_status' => 'active',
                'monitoring_enabled' => true,
                'last_verified_at' => date('Y-m-d H:i:s'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            $inventoryId = $this->db->insert('inventory_management', $inventoryData);
            
            // listing_platformsテーブルにも登録
            $listingData = [
                'product_id' => $productId,
                'platform' => 'ebay',
                'platform_product_id' => $product['ebay_item_id'],
                'listing_url' => $this->generateEbayUrl($product['ebay_item_id']),
                'listing_status' => 'active',
                'current_quantity' => 1,
                'listed_price' => $product['price'],
                'auto_sync_enabled' => true,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $this->db->insert('listing_platforms', $listingData);
            
            $this->logger->info("出品済み商品を在庫管理に登録", [
                'product_id' => $productId,
                'inventory_id' => $inventoryId,
                'title' => $product['title']
            ]);
            
            return true;
            
        } catch (Exception $e) {
            $this->logger->error("在庫管理登録エラー", [
                'product_id' => $productId,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }
    
    /**
     * 監視対象商品の定期チェック実行
     */
    public function performInventoryCheck($productIds = null) {
        $executionId = uniqid('inv_check_');
        
        try {
            // 実行ログ開始
            $this->startExecutionLog($executionId, 'inventory_check');
            
            // 監視対象商品取得
            $targets = $this->getMonitoringTargets($productIds);
            
            $results = [
                'total' => count($targets),
                'checked' => 0,
                'updated' => 0,
                'errors' => 0,
                'changes' => []
            ];
            
            foreach ($targets as $target) {
                try {
                    $checkResult = $this->checkSingleProduct($target);
                    $results['checked']++;
                    
                    if ($checkResult['changed']) {
                        $results['updated']++;
                        $results['changes'][] = $checkResult;
                    }
                    
                    // レート制限対応
                    sleep($this->config['check_interval_seconds']);
                    
                } catch (Exception $e) {
                    $results['errors']++;
                    $this->logger->error("個別商品チェックエラー", [
                        'product_id' => $target['product_id'],
                        'error' => $e->getMessage()
                    ]);
                }
            }
            
            // 実行ログ完了
            $this->completeExecutionLog($executionId, $results);
            
            return $results;
            
        } catch (Exception $e) {
            $this->failExecutionLog($executionId, $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 単一商品の在庫・価格チェック
     */
    private function checkSingleProduct($target) {
        $productId = $target['product_id'];
        $yahooUrl = $target['yahoo_url'];
        $currentPrice = $target['current_price'];
        
        // Yahoo Auctionから最新情報取得
        $latestData = $this->yahooscraper->scrapeProductData($yahooUrl);
        
        $changes = [];
        $hasChanges = false;
        
        // 価格変動検知
        if ($latestData['price'] != $currentPrice) {
            $priceChange = [
                'type' => 'price_change',
                'old_price' => $currentPrice,
                'new_price' => $latestData['price'],
                'change_percent' => (($latestData['price'] - $currentPrice) / $currentPrice) * 100
            ];
            $changes[] = $priceChange;
            $hasChanges = true;
            
            // 価格変動履歴記録
            $this->recordPriceChange($productId, $priceChange);
        }
        
        // 在庫状況変動検知
        $stockStatus = $this->determineStockStatus($latestData);
        if ($stockStatus != $target['current_stock_status']) {
            $stockChange = [
                'type' => 'stock_change',
                'old_status' => $target['current_stock_status'],
                'new_status' => $stockStatus
            ];
            $changes[] = $stockChange;
            $hasChanges = true;
            
            // 在庫変動履歴記録
            $this->recordStockChange($productId, $stockChange);
        }
        
        // URL生存状況確認
        if (!$latestData['accessible']) {
            $urlChange = [
                'type' => 'url_dead',
                'url' => $yahooUrl,
                'detected_at' => date('Y-m-d H:i:s')
            ];
            $changes[] = $urlChange;
            $hasChanges = true;
            
            // URL状態更新
            $this->updateUrlStatus($productId, 'dead');
        }
        
        // inventory_managementテーブル更新
        if ($hasChanges) {
            $updateData = [
                'current_price' => $latestData['price'],
                'url_status' => $latestData['accessible'] ? 'active' : 'dead',
                'last_verified_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            $this->db->update('inventory_management', $updateData, ['product_id' => $productId]);
        }
        
        return [
            'product_id' => $productId,
            'changed' => $hasChanges,
            'changes' => $changes,
            'latest_data' => $latestData
        ];
    }
    
    /**
     * 出品済み商品データ取得
     */
    private function getListedProduct($productId) {
        return $this->db->select('yahoo_scraped_products', [
            'id' => $productId,
            'workflow_status' => 'listed'
        ], ['limit' => 1])[0] ?? null;
    }
    
    /**
     * 監視対象商品一覧取得
     */
    private function getMonitoringTargets($productIds = null) {
        $sql = "
            SELECT 
                im.product_id,
                im.source_url as yahoo_url,
                im.current_price,
                im.url_status,
                im.last_verified_at,
                ysp.title,
                ysp.ebay_item_id
            FROM inventory_management im
            JOIN yahoo_scraped_products ysp ON im.product_id = ysp.id
            WHERE im.monitoring_enabled = true
              AND ysp.workflow_status = 'listed'
              AND ysp.ebay_item_id IS NOT NULL
        ";
        
        $params = [];
        if ($productIds) {
            $placeholders = str_repeat('?,', count($productIds) - 1) . '?';
            $sql .= " AND im.product_id IN ({$placeholders})";
            $params = $productIds;
        }
        
        $sql .= " ORDER BY im.last_verified_at ASC NULLS FIRST";
        
        return $this->db->query($sql, $params)->fetchAll();
    }
    
    /**
     * 価格変動履歴記録
     */
    private function recordPriceChange($productId, $change) {
        $this->db->insert('stock_history', [
            'product_id' => $productId,
            'previous_price' => $change['old_price'],
            'new_price' => $change['new_price'],
            'change_type' => 'price_change',
            'change_source' => 'yahoo',
            'created_at' => date('Y-m-d H:i:s')
        ]);
    }
    
    /**
     * Yahoo AuctionオークションID抽出
     */
    private function extractAuctionId($url) {
        preg_match('/auction\/([a-zA-Z0-9]+)/', $url, $matches);
        return $matches[1] ?? null;
    }
    
    /**
     * eBay URL生成
     */
    private function generateEbayUrl($itemId) {
        return "https://www.ebay.com/itm/{$itemId}";
    }
    
    /**
     * 既存登録チェック
     */
    private function isAlreadyRegistered($productId) {
        $existing = $this->db->select('inventory_management', ['product_id' => $productId]);
        return !empty($existing);
    }
    
    /**
     * 在庫状況判定
     */
    private function determineStockStatus($latestData) {
        if (!$latestData['accessible']) return 'dead_link';
        if ($latestData['ended']) return 'auction_ended';
        if ($latestData['available']) return 'in_stock';
        return 'unknown';
    }
    
    // 実行ログ関連メソッド...
    private function startExecutionLog($executionId, $processType) {
        // inventory_execution_logsテーブルに開始ログ
    }
    
    private function completeExecutionLog($executionId, $results) {
        // 実行完了ログ更新
    }
    
    private function failExecutionLog($executionId, $errorMessage) {
        // 実行失敗ログ更新
    }
}
?>