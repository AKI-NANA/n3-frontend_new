<?php
/**
 * 02_scraping/scripts/inventory_cron.php
 * 
 * 在庫管理定期実行スクリプト
 * cron経由で2時間毎に実行される
 */

// CLI実行のみ許可
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    exit('このスクリプトはコマンドラインからのみ実行可能です');
}

require_once __DIR__ . '/../includes/InventoryEngine.php';
require_once __DIR__ . '/../config/inventory.php';
require_once __DIR__ . '/../../shared/core/ProcessLock.php';

class InventoryCronManager {
    private $config;
    private $engine;
    private $logger;
    private $processLock;
    private $options;
    
    public function __construct($options = []) {
        $this->config = require __DIR__ . '/../config/inventory.php';
        $this->engine = new InventoryEngine();
        $this->logger = new Logger('inventory_cron');
        $this->processLock = new ProcessLock('inventory_check');
        $this->options = $options;
        
        // メモリ制限設定
        ini_set('memory_limit', $this->config['batch_processing']['memory_limit']);
        
        // 実行時間制限設定
        set_time_limit($this->config['batch_processing']['max_execution_time']);
    }
    
    public function run() {
        try {
            $this->logger->info("======= 在庫管理定期実行開始 =======");
            $this->logger->info("実行時刻: " . date('Y-m-d H:i:s'));
            $this->logger->info("実行オプション: " . json_encode($this->options));
            
            // プロセス排他制御
            if (!$this->processLock->acquire(3600)) { // 1時間でタイムアウト
                $this->logger->warning("別のプロセスが実行中のため終了");
                exit(1);
            }
            
            // パフォーマンス監視開始
            $startTime = microtime(true);
            $startMemory = memory_get_usage();
            
            // メイン処理実行
            $results = $this->executeMainProcess();
            
            // パフォーマンス計測
            $executionTime = microtime(true) - $startTime;
            $memoryUsage = memory_get_peak_usage() - $startMemory;
            
            // 実行結果ログ
            $this->logExecutionResults($results, $executionTime, $memoryUsage);
            
            // 後処理
            $this->executePostProcess($results);
            
            $this->logger->info("======= 在庫管理定期実行完了 =======");
            
            // 正常終了
            exit(0);
            
        } catch (Exception $e) {
            $this->logger->error("定期実行エラー: " . $e->getMessage());
            $this->logger->error("スタックトレース: " . $e->getTraceAsString());
            
            // エラー通知
            $this->sendErrorNotification($e);
            
            exit(1);
            
        } finally {
            // プロセスロック解放
            $this->processLock->release();
        }
    }
    
    /**
     * メイン処理実行
     */
    private function executeMainProcess() {
        $results = [
            'inventory_check' => null,
            'health_check' => null,
            'cleanup' => null
        ];
        
        // 1. 在庫チェック実行
        if ($this->shouldRunInventoryCheck()) {
            $this->logger->info("在庫チェック開始");
            $results['inventory_check'] = $this->runInventoryCheck();
            $this->logger->info("在庫チェック完了");
        }
        
        // 2. ヘルスチェック実行
        if ($this->shouldRunHealthCheck()) {
            $this->logger->info("ヘルスチェック開始");
            $results['health_check'] = $this->runHealthCheck();
            $this->logger->info("ヘルスチェック完了");
        }
        
        // 3. クリーンアップ実行
        if ($this->shouldRunCleanup()) {
            $this->logger->info("クリーンアップ開始");
            $results['cleanup'] = $this->runCleanup();
            $this->logger->info("クリーンアップ完了");
        }
        
        return $results;
    }
    
    /**
     * 在庫チェック実行
     */
    private function runInventoryCheck() {
        try {
            // 優先度別処理
            if ($this->options['priority_only'] ?? false) {
                return $this->runPriorityInventoryCheck();
            }
            
            // 通常処理
            $productIds = $this->options['product_ids'] ?? null;
            $forceFullScan = $this->options['force_full_scan'] ?? false;
            
            if ($productIds) {
                $productIds = explode(',', $productIds);
                $productIds = array_map('intval', $productIds);
            }
            
            return $this->engine->performInventoryCheck($productIds);
            
        } catch (Exception $e) {
            $this->logger->error("在庫チェック実行エラー: " . $e->getMessage());
            throw $e;
        }
    }
    
    /**
     * 優先商品のみチェック
     */
    private function runPriorityInventoryCheck() {
        // 最近チェックされていない商品を優先
        $db = Database::getInstance();
        $sql = "
            SELECT product_id 
            FROM inventory_management im
            JOIN yahoo_scraped_products ysp ON im.product_id = ysp.id
            WHERE im.monitoring_enabled = true
              AND ysp.workflow_status = 'listed'
              AND ysp.ebay_item_id IS NOT NULL
              AND (im.last_verified_at IS NULL OR im.last_verified_at < NOW() - INTERVAL '4 hours')
            ORDER BY im.last_verified_at ASC NULLS FIRST
            LIMIT 20
        ";
        
        $priorityProducts = $db->query($sql)->fetchAll(PDO::FETCH_COLUMN);
        
        if (empty($priorityProducts)) {
            $this->logger->info("優先チェック対象商品なし");
            return ['total' => 0, 'processed' => 0, 'updated' => 0, 'errors' => 0];
        }
        
        $this->logger->info("優先商品チェック: " . count($priorityProducts) . "件");
        return $this->engine->performInventoryCheck($priorityProducts);
    }
    
    /**
     * ヘルスチェック実行
     */
    private function runHealthCheck() {
        $results = [
            'dead_links_found' => 0,
            'inactive_products' => 0,
            'database_issues' => 0
        ];
        
        try {
            $db = Database::getInstance();
            
            // デッドリンクチェック
            $deadLinks = $db->query("
                SELECT COUNT(*) as count 
                FROM inventory_management 
                WHERE url_status = 'dead'
            ")->fetch()['count'];
            $results['dead_links_found'] = $deadLinks;
            
            // 長期間更新されていない商品
            $inactiveProducts = $db->query("
                SELECT COUNT(*) as count 
                FROM inventory_management 
                WHERE last_verified_at < NOW() - INTERVAL '1 week'
                  AND monitoring_enabled = true
            ")->fetch()['count'];
            $results['inactive_products'] = $inactiveProducts;
            
            // データベース整合性チェック
            $orphanedRecords = $db->query("
                SELECT COUNT(*) as count 
                FROM inventory_management im
                LEFT JOIN yahoo_scraped_products ysp ON im.product_id = ysp.id
                WHERE ysp.id IS NULL
            ")->fetch()['count'];
            $results['database_issues'] = $orphanedRecords;
            
            // 問題があれば警告
            if ($deadLinks > 10) {
                $this->logger->warning("デッドリンクが多数検出: {$deadLinks}件");
            }
            
            if ($inactiveProducts > 20) {
                $this->logger->warning("長期間未チェック商品: {$inactiveProducts}件");
            }
            
            if ($orphanedRecords > 0) {
                $this->logger->error("データベース不整合: {$orphanedRecords}件");
            }
            
            return $results;
            
        } catch (Exception $e) {
            $this->logger->error("ヘルスチェックエラー: " . $e->getMessage());
            return $results;
        }
    }
    
    /**
     * クリーンアップ実行
     */
    private function runCleanup() {
        $results = [
            'deleted_history' => 0,
            'deleted_logs' => 0,
            'deleted_errors' => 0
        ];
        
        try {
            $db = Database::getInstance();
            
            if (!$this->config['cleanup']['auto_cleanup']) {
                $this->logger->info("自動クリーンアップは無効化されています");
                return $results;
            }
            
            // 古い履歴データ削除
            $historyRetention = $this->config['cleanup']['stock_history_retention_days'];
            $deletedHistory = $db->query("
                DELETE FROM stock_history 
                WHERE created_at < NOW() - INTERVAL '{$historyRetention} days'
            ")->rowCount();
            $results['deleted_history'] = $deletedHistory;
            
            // 古い実行ログ削除
            $logsRetention = $this->config['cleanup']['execution_logs_retention_days'];
            $deletedLogs = $db->query("
                DELETE FROM inventory_execution_logs 
                WHERE created_at < NOW() - INTERVAL '{$logsRetention} days'
            ")->rowCount();
            $results['deleted_logs'] = $deletedLogs;
            
            // 解決済みエラーログ削除
            $errorsRetention = $this->config['cleanup']['error_logs_retention_days'];
            $deletedErrors = $db->query("
                DELETE FROM inventory_errors 
                WHERE resolved = true 
                  AND created_at < NOW() - INTERVAL '{$errorsRetention} days'
            ")->rowCount();
            $results['deleted_errors'] = $deletedErrors;
            
            if ($deletedHistory + $deletedLogs + $deletedErrors > 0) {
                $this->logger->info("クリーンアップ完了: 履歴{$deletedHistory}件、ログ{$deletedLogs}件、エラー{$deletedErrors}件削除");
            }
            
            // データベース最適化
            if ($this->config['cleanup']['auto_optimize']) {
                $this->optimizeDatabase();
            }
            
            return $results;
            
        } catch (Exception $e) {
            $this->logger->error("クリーンアップエラー: " . $e->getMessage());
            return $results;
        }
    }
    
    /**
     * データベース最適化
     */
    private function optimizeDatabase() {
        try {
            $db = Database::getInstance();
            
            // PostgreSQL用の最適化
            $tables = [
                'inventory_management',
                'stock_history',
                'inventory_execution_logs',
                'inventory_errors'
            ];
            
            foreach ($tables as $table) {
                $db->query("VACUUM ANALYZE {$table}");
            }
            
            $this->logger->info("データベース最適化完了");
            
        } catch (Exception $e) {
            $this->logger->warning("データベース最適化エラー: " . $e->getMessage());
        }
    }
    
    /**
     * 実行条件判定
     */
    private function shouldRunInventoryCheck() {
        return !isset($this->options['skip_inventory']);
    }
    
    private function shouldRunHealthCheck() {
        // 6時間に1回実行
        $hour = date('H');
        return $hour % 6 === 0 && !isset($this->options['skip_health']);
    }
    
    private function shouldRunCleanup() {
        // 1日に1回実行（深夜2時）
        $hour = date('H');
        return $hour === 2 && !isset($this->options['skip_cleanup']);
    }
    
    /**
     * 実行結果ログ出力
     */
    private function logExecutionResults($results, $executionTime, $memoryUsage) {
        $this->logger->info("実行時間: " . round($executionTime, 2) . "秒");
        $this->logger->info("メモリ使用量: " . $this->formatBytes($memoryUsage));
        
        if ($results['inventory_check']) {
            $check = $results['inventory_check'];
            $this->logger->info("在庫チェック結果: {$check['processed']}/{$check['total']}件処理、{$check['updated']}件更新、{$check['errors']}件エラー");
        }
        
        if ($results['health_check']) {
            $health = $results['health_check'];
            $this->logger->info("ヘルスチェック結果: デッドリンク{$health['dead_links_found']}件、非アクティブ{$health['inactive_products']}件");
        }
        
        if ($results['cleanup']) {
            $cleanup = $results['cleanup'];
            $total = $cleanup['deleted_history'] + $cleanup['deleted_logs'] + $cleanup['deleted_errors'];
            if ($total > 0) {
                $this->logger->info("クリーンアップ結果: {$total}件削除");
            }
        }
    }
    
    /**
     * 後処理実行
     */
    private function executePostProcess($results) {
        try {
            // 統計レポート生成
            $this->generateDailyReport($results);
            
            // 10_zaikoに実行完了通知
            $this->notifyZaikoSystem($results);
            
        } catch (Exception $e) {
            $this->logger->warning("後処理エラー: " . $e->getMessage());
        }
    }
    
    /**
     * 日次レポート生成
     */
    private function generateDailyReport($results) {
        if (!$this->config['reporting']['daily_report']['enabled']) {
            return;
        }
        
        $reportTime = date('Y-m-d H:i:s');
        $reportDir = $this->config['reporting']['daily_report']['save_path'];
        
        // ディレクトリ作成
        if (!is_dir($reportDir)) {
            mkdir($reportDir, 0755, true);
        }
        
        $reportData = [
            'generated_at' => $reportTime,
            'execution_results' => $results,
            'system_stats' => $this->getSystemStats()
        ];
        
        $filename = $reportDir . 'inventory_report_' . date('Y-m-d') . '.json';
        file_put_contents($filename, json_encode($reportData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        $this->logger->info("日次レポート生成: {$filename}");
    }
    
    /**
     * システム統計取得
     */
    private function getSystemStats() {
        try {
            $db = Database::getInstance();
            
            return [
                'total_products' => $db->query("SELECT COUNT(*) as count FROM inventory_management")->fetch()['count'],
                'active_monitoring' => $db->query("SELECT COUNT(*) as count FROM inventory_management WHERE monitoring_enabled = true")->fetch()['count'],
                'price_changes_today' => $db->query("SELECT COUNT(*) as count FROM stock_history WHERE created_at >= CURRENT_DATE AND change_type IN ('price_change', 'both')")->fetch()['count'],
                'errors_today' => $db->query("SELECT COUNT(*) as count FROM inventory_errors WHERE created_at >= CURRENT_DATE AND resolved = false")->fetch()['count']
            ];
            
        } catch (Exception $e) {
            $this->logger->warning("システム統計取得エラー: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * 10_zaikoシステム通知
     */
    private function notifyZaikoSystem($results) {
        try {
            $notificationData = [
                'event_type' => 'cron_execution_completed',
                'execution_time' => date('Y-m-d H:i:s'),
                'results' => $results,
                'source' => '02_scraping_cron'
            ];
            
            // 非同期通知
            $this->sendAsyncNotification('../10_zaiko/api/webhook.php', $notificationData);
            
        } catch (Exception $e) {
            $this->logger->warning("10_zaiko通知エラー: " . $e->getMessage());
        }
    }
    
    /**
     * エラー通知送信
     */
    private function sendErrorNotification($exception) {
        try {
            $alertData = [
                'type' => 'cron_error',
                'message' => $exception->getMessage(),
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
                'time' => date('Y-m-d H:i:s')
            ];
            
            // アラート設定に基づく通知
            if ($this->config['alerts']['enabled']) {
                $this->sendAlert($alertData);
            }
            
        } catch (Exception $e) {
            error_log("エラー通知送信失敗: " . $e->getMessage());
        }
    }
    
    /**
     * ヘルパーメソッド
     */
    private function formatBytes($bytes) {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        return round($bytes, 2) . ' ' . $units[$pow];
    }
    
    private function sendAsyncNotification($url, $data) {
        // 非ブロッキング通信実装
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_TIMEOUT => 2,
            CURLOPT_NOSIGNAL => true
        ]);
        curl_exec($ch);
        curl_close($ch);
    }
    
    private function sendAlert($alertData) {
        // アラート送信実装（ログ出力のみ）
        $this->logger->error("アラート: " . json_encode($alertData, JSON_UNESCAPED_UNICODE));
    }
}

// コマンドライン引数解析
function parseCommandLineArgs($argv) {
    $options = [];
    
    for ($i = 1; $i < count($argv); $i++) {
        $arg = $argv[$i];
        
        if (strpos($arg, '--') === 0) {
            $key = substr($arg, 2);
            
            if (strpos($key, '=') !== false) {
                list($key, $value) = explode('=', $key, 2);
                $options[$key] = $value;
            } else {
                $options[$key] = true;
            }
        }
    }
    
    return $options;
}

// メイン実行
if (basename(__FILE__) === basename($_SERVER['SCRIPT_NAME'])) {
    try {
        $options = parseCommandLineArgs($argv ?? []);
        
        $manager = new InventoryCronManager($options);
        $manager->run();
        
    } catch (Exception $e) {
        error_log("Cron実行エラー: " . $e->getMessage());
        exit(1);
    }
}
?>