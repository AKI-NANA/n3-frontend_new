<?php
// 02_scraping フォルダのインデックス - メインファイルにリダイレクト
header('Location: scraping.php');
exit;
?>